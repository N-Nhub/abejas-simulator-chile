#!/usr/bin/env fish
# Run the same landscape under different interventions (same seed) and compare.
# Usage: ./compare.fish <zone> <habitat> [days]
#   ./compare.fish biobio_costa nativo 240
cd (dirname (status filename))
set -l zone $argv[1]; set -l hab $argv[2]
set -l days 240; test (count $argv) -ge 3; and set days $argv[3]
set -l out results/compare_{$zone}_{$hab}
set -l scenarios \
    "base:" \
    "franjas:--strips" \
    "hoteles:--nesting alto" \
    "sin_terrestris:--terrestris ausente" \
    "pesticidas:--pesticide alto" \
    "todo_bien:--strips --nesting alto --pesticide ninguno"
for s in $scenarios
    set -l name (string split -m1 : $s)[1]
    set -l rest (string split -m1 : $s)[2]
    set -l args
    test -n "$rest"; and set args (string split ' ' -- $rest)
    echo "== $name =="
    python run.py --zone $zone --habitat $hab --days $days --headless --out $out/$name $args | tail -n 22
end
echo "Results in $out/"
