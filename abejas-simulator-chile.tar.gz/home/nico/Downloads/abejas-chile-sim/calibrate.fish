#!/usr/bin/env fish
# Re-derive the feeding curve from the FlyWire connectome (~5 min on CPU).
#   sudo pacman -S --needed python-pandas python-pyarrow python-scipy git
cd (dirname (status filename))
if not test -d Drosophila_brain_model
    git clone --depth 1 https://github.com/philshiu/Drosophila_brain_model.git; or exit 1
end
python flywire_calibrate.py --data Drosophila_brain_model $argv
