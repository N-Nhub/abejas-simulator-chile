#!/usr/bin/env fish
# Launch the simulator. Extra args go to run.py, e.g.:
#   ./run.fish                 (menu + live window)
#   ./run.fish --headless      (menu, no window)
#   ./run.fish --list          (zones and habitats)
cd (dirname (status filename))
set -gx PYGAME_HIDE_SUPPORT_PROMPT 1
set -l missing
for mod in numpy pygame matplotlib
    python -c "import $mod" 2>/dev/null; or set -a missing $mod
end
if test (count $missing) -gt 0
    echo "Missing Python modules: $missing"
    echo "  sudo pacman -S --needed python-numpy python-pygame python-matplotlib"
    exit 1
end
python run.py $argv
