#!/usr/bin/env python3
"""Abejas de Chile central — run the bee/landscape simulation.

    python run.py                       # interactive menu + live window
    python run.py --headless            # menu, then run without a window
    python run.py --zone araucania --habitat templado --year normal --headless
    python run.py --list                # show zones and habitats
"""
import argparse
import csv
import datetime as dt
import sys
import time
from pathlib import Path

from beesim.climate import ZONES, YEAR_TYPES
from beesim.flora import HABITATS
from beesim.world import World, Scenario
from beesim.bees import SPECIES


def parse():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--zone", choices=list(ZONES))
    ap.add_argument("--habitat")
    ap.add_argument("--year", choices=list(YEAR_TYPES), default="normal")
    ap.add_argument("--hives", type=int, default=4)
    ap.add_argument("--pesticide", choices=["ninguno", "moderado", "alto"], default="ninguno")
    ap.add_argument("--nesting", choices=["bajo", "medio", "alto"], default="medio")
    ap.add_argument("--terrestris", choices=["auto", "ausente", "presente"], default="auto")
    ap.add_argument("--strips", action="store_true", help="add native flower strips")
    ap.add_argument("--days", type=int, default=240)
    ap.add_argument("--size", type=int, choices=[3, 6, 12], default=3, help="map width in km (3, 6 or 12)")
    ap.add_argument("--start", default="01-08", help="start date DD-MM (default 01-08)")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--headless", action="store_true", help="no window, just results")
    ap.add_argument("--out", type=Path, default=Path("results"))
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--team", default="", help='name shown above the map title, e.g. --team "Buzz Team"')
    ap.add_argument("--classic", action="store_true", help="use the old, simpler viewer")
    return ap.parse_args()


def start_doy(ddmm):
    d, m = (int(x) for x in ddmm.split("-"))
    return dt.date(2025, m, d).timetuple().tm_yday


def save_results(world, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    if world.daily:
        with open(out_dir / "diario.csv", "w", newline="") as f:
            wr = csv.DictWriter(f, fieldnames=list(world.daily[0]))
            wr.writeheader()
            wr.writerows(world.daily)
    summary = world.summary()
    (out_dir / "resumen.txt").write_text(summary + "\n")
    try:
        plot(world, out_dir / "graficos.png")
    except ImportError:
        print("(matplotlib not installed: skipping plots)")
    return summary


def plot(world, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    d = world.daily
    x = [r["day"] for r in d]
    labels = [r["date"] for r in d]
    fig, ax = plt.subplots(4, 1, figsize=(11, 12), sharex=True)
    ax[0].fill_between(x, [r["tmin"] for r in d], [r["tmax"] for r in d], color="#d9a441", alpha=.5, label="T mín–máx (°C)")
    ax0b = ax[0].twinx()
    ax0b.bar(x, [r["rain_mm"] for r in d], color="#4a6fa5", alpha=.6, label="lluvia (mm)")
    ax[0].set_ylabel("°C"); ax0b.set_ylabel("mm")
    ax[0].set_title(f"{world.zone.name} — {world.habitat.name}")
    for s in SPECIES:
        col = [c / 255 for c in s.color]
        ax[1].plot(x, [max(r[f"{s.key}_obreras"], .1) for r in d], color=col, label=s.name.split(" (")[0])
        ax[2].plot(x, [max(r[f"{s.key}_visitas"], .1) for r in d], color=col)
    ax[1].set_yscale("log"); ax[1].set_ylabel("obreras activas"); ax[1].legend(fontsize=8)
    ax[2].set_yscale("log"); ax[2].set_ylabel("visitas florales / día")
    ax[3].plot(x, [r["visitas_nativas_pct"] for r in d], color="#2f7d4f", label="% visitas por nativas")
    ax3b = ax[3].twinx()
    ax3b.plot(x, [r["dahlbomii_infeccion_media"] for r in d], color="#b5452b", label="infección B. dahlbomii")
    ax[3].set_ylabel("% nativas"); ax3b.set_ylabel("infección (0–1)")
    step = max(1, len(x) // 12)
    ax[3].set_xticks(x[::step]); ax[3].set_xticklabels(labels[::step], rotation=45)
    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)


def main():
    a = parse()
    if a.list:
        for k, z in ZONES.items():
            print(f"{k:16s} {z.name}")
            for h in HABITATS[k]:
                print(f"    --habitat {h.key:10s} {h.name}")
        return
    if a.zone:
        habs = {h.key for h in HABITATS[a.zone]}
        hab = a.habitat or next(iter(habs))
        if hab not in habs:
            sys.exit(f"Habitat '{hab}' not in {a.zone}. Options: {', '.join(sorted(habs))}")
        sc = Scenario(zone=a.zone, habitat=hab, year=a.year, hives=a.hives, pesticide=a.pesticide,
                      nesting=a.nesting, terrestris=a.terrestris, flower_strips=a.strips,
                      days=a.days, start_doy=start_doy(a.start), seed=a.seed, size_km=a.size)
    else:
        from beesim.menu import interactive
        sc = interactive()
        sc.start_doy, sc.seed = start_doy(a.start), a.seed

    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = a.out / f"{sc.zone}_{sc.habitat}_{sc.year}_{stamp}"
    print("\nBuilding landscape…")
    world = World(sc)
    print(f"  {len(world.colonies)} nests, feeding circuit: {world.feeding.source}")

    if a.headless:
        t0 = time.time()
        while not world.finished:
            world.run_day_fast()
            r = world.daily[-1]
            print(f"\r  día {r['day'] + 1:3d}/{sc.days}  {r['date']}  {r['tmax']:5.1f}°C  "
                  f"plantas en flor {r['plantas_en_flor']:2d}  nativas {r['visitas_nativas_pct']:5.1f}%   ",
                  end="", flush=True)
        print(f"\n  done in {time.time() - t0:.0f}s")
    else:
        if a.classic and sc.size_km != 3:
            sys.exit("--classic only supports the 3 km map; drop --classic or use --size 3")
        if a.classic:
            from beesim.viewer_classic import Viewer
            Viewer(world, out_dir).run()
        else:
            from beesim.viewer import Viewer
            Viewer(world, out_dir, team=a.team).run()

    summary = save_results(world, out_dir)
    print("\n" + summary)
    print(f"\nResults in {out_dir}/ (diario.csv, resumen.txt, graficos.png)")


if __name__ == "__main__":
    main()
