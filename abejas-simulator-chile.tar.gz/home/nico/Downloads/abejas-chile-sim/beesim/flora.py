"""Plants and habitat presets.

Bloom windows are day-of-year (southern hemisphere: Jan = midsummer) and are
approximate, from general botanical knowledge of central-southern Chile.
`nectar` and `pollen` are relative 0..1 rewards, `sugar` is nectar sugar
concentration (0..1), `corolla` is flower tube depth in mm (0 = open flower).
Treat every number as a tunable starting point, not field data.
"""
from dataclasses import dataclass
import math

# day-of-year helpers
JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC = (
    1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335)


@dataclass(frozen=True)
class Plant:
    key: str
    name: str
    native: bool
    start: int
    end: int
    nectar: float
    sugar: float
    pollen: float
    corolla: float
    color: tuple
    crop: bool = False
    irrigated: bool = False
    ephemeral: bool = False   # desert annuals: need winter rain to bloom
    buzz: bool = False        # benefits from buzz pollination (bumblebees)


P = Plant
PLANTS = {p.key: p for p in [
    # --- native sclerophyll / temperate forest ---
    P("quillay", "Quillay (Quillaja saponaria)", True, OCT + 15, JAN + 10, .90, .45, .5, 0, (226, 222, 150)),
    P("litre", "Litre (Lithraea caustica)", True, SEP + 15, NOV + 30, .45, .35, .4, 0, (186, 196, 120)),
    P("boldo", "Boldo (Peumus boldus)", True, JUN + 15, SEP + 15, .40, .35, .4, 0, (214, 226, 170)),
    P("peumo", "Peumo (Cryptocarya alba)", True, NOV + 1, JAN + 31, .35, .30, .3, 0, (170, 190, 130)),
    P("maqui", "Maqui (Aristotelia chilensis)", True, SEP + 1, NOV + 30, .50, .30, .6, 0, (200, 170, 200)),
    P("ulmo", "Ulmo (Eucryphia cordifolia)", True, JAN + 1, MAR + 15, 1.0, .45, .6, 0, (245, 245, 235)),
    P("canelo", "Canelo (Drimys winteri)", True, SEP + 1, DEC + 15, .45, .30, .5, 0, (235, 235, 210)),
    P("avellano", "Avellano chileno (Gevuina avellana)", True, DEC + 1, MAR + 31, .50, .30, .4, 4, (230, 220, 190)),
    P("chilco", "Chilco (Fuchsia magellanica)", True, DEC + 1, MAR + 31, .60, .30, .3, 10, (190, 40, 90)),
    P("franja", "Franja floral nativa (mezcla)", True, SEP + 1, MAR + 15, .60, .40, .7, 2, (240, 170, 60)),
    # --- exotic / agricultural ---
    P("eucalipto", "Eucalipto (Eucalyptus globulus)", False, JUN + 1, OCT + 31, .70, .35, .5, 0, (150, 175, 160)),
    P("pino", "Pino radiata (sin néctar)", False, 1, 1, 0.0, 0.0, 0.0, 0, (52, 82, 58)),
    P("cerezo", "Cerezo (huerto)", False, SEP + 1, OCT + 10, .60, .30, .6, 0, (250, 210, 225), crop=True, irrigated=True),
    P("almendro", "Almendro (huerto)", False, JUL + 20, AUG + 31, .60, .30, .7, 0, (250, 230, 240), crop=True, irrigated=True),
    P("palto", "Palto (huerto)", False, SEP + 1, NOV + 15, .40, .25, .3, 0, (170, 200, 90), crop=True, irrigated=True),
    P("arandano", "Arándano (huerto)", False, SEP + 10, NOV + 10, .50, .30, .5, 7, (120, 140, 200), crop=True, irrigated=True, buzz=True),
    P("raps", "Raps / canola", False, SEP + 1, OCT + 31, .70, .40, .8, 0, (245, 225, 40), crop=True),
    P("trebol", "Pradera de trébol / alfalfa", False, NOV + 1, MAR + 31, .55, .35, .5, 6, (200, 140, 190), crop=True),
    P("yuyo", "Yuyo / mostaza silvestre", False, AUG + 1, NOV + 30, .45, .30, .6, 0, (230, 220, 60)),
    P("lavanda", "Lavanda (jardín)", False, NOV + 1, MAR + 15, .60, .35, .3, 5, (150, 120, 210), irrigated=True),
    P("maleza", "Maleza urbana (diente de león, trébol)", False, SEP + 1, APR + 15, .30, .30, .5, 2, (190, 200, 110)),
    # --- desert ---
    P("pata_guanaco", "Pata de guanaco (Cistanthe grandiflora)", True, SEP + 1, NOV + 15, .70, .35, .6, 0, (220, 60, 160), ephemeral=True),
    P("ananuca", "Añañuca (Rhodophiala)", True, SEP + 1, OCT + 31, .60, .35, .4, 8, (210, 40, 50), ephemeral=True),
    P("suspiro", "Suspiro de campo (Nolana)", True, SEP + 1, NOV + 30, .55, .35, .5, 4, (110, 130, 230), ephemeral=True),
    P("chanar", "Chañar (Geoffroea decorticans)", True, SEP + 15, NOV + 30, .50, .35, .5, 3, (240, 190, 40)),
    P("olivo", "Olivo (valle, viento)", False, OCT + 1, NOV + 15, .05, .10, .5, 0, (140, 150, 110), crop=True, irrigated=True),
]}

# background ("nothing blooming") colours per zone feel
BG_COLOR = {"default": (118, 140, 92), "desierto": (196, 172, 128)}


def in_window(doy, start, end):
    if start <= end:
        return start <= doy <= end
    return doy >= start or doy <= end      # wraps over New Year


def bloom_intensity(p: Plant, doy: int, soil: float, winter_rain: float) -> float:
    """0..1 flowering intensity: smooth bump over the window, modulated by water."""
    if p.nectar <= 0 and p.pollen <= 0:
        return 0.0
    if not in_window(doy, p.start, p.end):
        return 0.0
    length = (p.end - p.start) % 365 or 365
    pos = ((doy - p.start) % 365) / length
    shape = math.sin(math.pi * pos) ** 0.8
    if p.ephemeral:
        water = min(max((winter_rain - 10) / 25, 0.0), 1.0)   # desierto florido trigger
    elif p.irrigated:
        water = 1.0
    else:
        water = 0.45 + 0.55 * soil
    return shape * water


@dataclass(frozen=True)
class Habitat:
    key: str
    name: str
    mix: dict             # plant key -> fraction of the landscape
    fields: tuple = ()    # plant keys placed as rectangular blocks (orchards/crops)
    note: str = ""


H = Habitat
_SCLEROPHYLL = {"quillay": .10, "litre": .10, "boldo": .07, "peumo": .07, "maqui": .03, "yuyo": .05}
_URBAN = {"lavanda": .07, "maleza": .18, "cerezo": .02, "eucalipto": .04}
_FOREST = {"pino": .50, "eucalipto": .22, "maqui": .03, "yuyo": .03}

HABITATS = {
    "ohiggins": [
        H("escl", "Matorral y bosque esclerófilo", _SCLEROPHYLL, note="Cerros con quillay, litre y boldo"),
        H("agro", "Valle agrícola (cerezos, almendros, paltos)",
          {"cerezo": .22, "almendro": .14, "palto": .10, "yuyo": .07, "quillay": .02},
          ("cerezo", "almendro", "palto")),
        H("mosaico", "Mosaico: huertos + quebradas nativas",
          {"cerezo": .12, "almendro": .07, "quillay": .07, "litre": .06, "boldo": .05, "yuyo": .06},
          ("cerezo", "almendro")),
        H("urbano", "Ciudad / periurbano (Rancagua)", _URBAN),
    ],
    "maule": [
        H("escl", "Secano: matorral esclerófilo", _SCLEROPHYLL),
        H("agro", "Huertos (cerezos, arándanos)",
          {"cerezo": .20, "arandano": .15, "yuyo": .08, "maqui": .02}, ("cerezo", "arandano")),
        H("forestal", "Plantación forestal (pino/eucalipto)", _FOREST, ("pino",)),
        H("urbano", "Ciudad / periurbano (Talca)", _URBAN),
    ],
    "nuble": [
        H("berries", "Zona de berries (arándanos)",
          {"arandano": .28, "cerezo": .06, "yuyo": .08, "maqui": .03}, ("arandano", "cerezo")),
        H("escl", "Secano interior esclerófilo", _SCLEROPHYLL),
        H("forestal", "Plantación forestal", _FOREST, ("pino",)),
        H("mosaico", "Mosaico rural (praderas + maqui)",
          {"trebol": .20, "maqui": .08, "yuyo": .08, "litre": .04}, ("trebol",)),
    ],
    "biobio_costa": [
        H("nativo", "Bosque nativo costero remanente",
          {"peumo": .10, "boldo": .08, "maqui": .08, "litre": .05, "quillay": .03, "canelo": .04}),
        H("forestal", "Plantación forestal (pino/eucalipto)", _FOREST, ("pino",)),
        H("urbano", "Ciudad / periurbano (Gran Concepción)", _URBAN),
        H("humedal", "Humedal y dunas con matorral",
          {"maleza": .12, "maqui": .05, "chilco": .03, "yuyo": .06, "eucalipto": .04}),
    ],
    "biobio_interior": [
        H("raps", "Raps y praderas",
          {"raps": .25, "trebol": .15, "yuyo": .06}, ("raps", "trebol")),
        H("berries", "Berries (arándanos)",
          {"arandano": .25, "cerezo": .05, "yuyo": .07}, ("arandano", "cerezo")),
        H("forestal", "Plantación forestal", _FOREST, ("pino",)),
        H("precord", "Precordillera con bosque nativo",
          {"canelo": .07, "maqui": .08, "avellano": .05, "chilco": .03, "ulmo": .03}),
    ],
    "araucania": [
        H("templado", "Bosque templado (ulmo, canelo, avellano)",
          {"ulmo": .10, "canelo": .07, "avellano": .06, "chilco": .04, "maqui": .06}),
        H("raps", "Raps y praderas",
          {"raps": .25, "trebol": .18, "yuyo": .05}, ("raps", "trebol")),
        H("forestal", "Plantación forestal", _FOREST, ("pino",)),
        H("rural", "Mosaico rural (praderas, maqui, quila)",
          {"trebol": .18, "maqui": .08, "ulmo": .03, "yuyo": .06}, ("trebol",)),
    ],
    "desierto": [
        H("florido", "Desierto florido (llanos costeros)",
          {"pata_guanaco": .22, "suspiro": .12, "ananuca": .06, "chanar": .02},
          note="Solo florece con lluvia invernal: prueba 'El Niño'"),
        H("valle", "Valle agrícola / oasis (Copiapó)",
          {"olivo": .15, "chanar": .05, "maleza": .10, "lavanda": .03}, ("olivo",)),
        H("absoluto", "Desierto absoluto (interior)", {"chanar": .01, "suspiro": .02}),
        H("urbano", "Jardín urbano desértico", {"lavanda": .06, "maleza": .08, "chanar": .02}),
    ],
}

# Every zone also offers a regional mosaic: the zone's environments stitched together in
# ~1.2 km patches. Most realistic on the larger maps (6 or 12 km).
for _zone, _habs in HABITATS.items():
    _habs.append(H("regional", "Mosaico regional (todos los entornos de la zona)", {},
                   note="Recomendado para mapas de 6 o 12 km"))
