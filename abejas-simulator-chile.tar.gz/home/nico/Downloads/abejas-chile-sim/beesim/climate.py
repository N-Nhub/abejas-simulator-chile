"""Climate zones (O'Higgins -> La Araucanía, plus the Atacama) and a stochastic
daily/hourly weather generator.

Numbers are approximate climatological normals (rounded) meant to give each
zone the right character: Mediterranean summer drought in the north of the
range, wetter and cooler oceanic influence toward Temuco, a mild coastal
Concepción, and a near-rainless desert. Verify against DMC (Dirección
Meteorológica de Chile) normals if you need exact figures.
"""
from dataclasses import dataclass
import math
import numpy as np


@dataclass(frozen=True)
class Zone:
    key: str
    name: str
    lat: float          # degrees (negative = south)
    jan_mean: float     # °C mean of warmest month
    jul_mean: float     # °C mean of coldest month
    diurnal: float      # °C typical daily max-min range
    rain_mm: float      # annual rainfall
    rain_days: int      # days/year with meaningful rain
    koppen: str
    wind: float = 3.0   # m/s typical daytime mean wind
    cloud: float = 0.3  # mean cloud fraction on dry days (coastal fog counts)


ZONES = {
    "ohiggins": Zone("ohiggins", "O'Higgins (Rancagua, valle central)", -34.2,
                     20.5, 8.5, 17, 450, 35, "Csb (mediterráneo)", 2.6, .20),
    "maule": Zone("maule", "Maule (Talca, valle central)", -35.4,
                  21.0, 8.0, 17, 680, 45, "Csb (mediterráneo)", 2.6, .22),
    "nuble": Zone("nuble", "Ñuble (Chillán)", -36.6,
                  20.0, 8.0, 16, 1000, 60, "Csb", 2.8, .28),
    "biobio_costa": Zone("biobio_costa", "Biobío costa (Concepción)", -36.8,
                         17.5, 9.5, 9, 1100, 85, "Csb (influencia oceánica)", 4.6, .40),
    "biobio_interior": Zone("biobio_interior", "Biobío interior (Los Ángeles)", -37.5,
                            19.5, 7.5, 16, 1150, 80, "Csb", 3.0, .30),
    "araucania": Zone("araucania", "La Araucanía (Temuco)", -38.7,
                      16.5, 7.5, 13, 1200, 115, "Cfb/Csb (templado lluvioso)", 3.2, .45),
    "desierto": Zone("desierto", "Desierto de Atacama (Copiapó / desierto florido)", -27.4,
                     21.5, 13.0, 15, 15, 3, "BWk (desierto)", 4.0, .35),
}

YEAR_TYPES = {
    "normal": dict(label="Año normal", rain_mult=1.0, temp_add=0.0),
    "seco": dict(label="Megasequía (año seco)", rain_mult=0.45, temp_add=0.8),
    "nino": dict(label="El Niño (año lluvioso)", rain_mult=1.7, temp_add=-0.3),
}


def day_length_hours(lat_deg: float, doy: int) -> float:
    """Astronomical day length (hours) for a latitude and day of year."""
    decl = 23.44 * math.sin(math.radians(360 / 365 * (doy - 81)))
    x = -math.tan(math.radians(lat_deg)) * math.tan(math.radians(decl))
    x = max(-1.0, min(1.0, x))
    return 2 * math.degrees(math.acos(x)) / 15


class Weather:
    """Daily weather generator in the style of WGEN (Richardson 1981):
    a first-order Markov chain decides wet/dry days (so rain comes in spells),
    rain amounts are exponential, temperature has a seasonal cycle plus an AR(1)
    anomaly. Added for bees: daytime wind with an afternoon sea-breeze peak,
    cloud cover (morning coastal fog, 'camanchaca', on the coast and desert), and a
    simple soil-moisture bucket that drives grass colour and non-irrigated nectar."""

    PERSIST = 0.45          # lag-1 autocorrelation of wet days

    def __init__(self, zone: Zone, year_type: str, rng: np.random.Generator):
        self.z = zone
        self.yt = dict(YEAR_TYPES[year_type])
        if zone.key == "desierto":
            # Atacama rainfall swings far more in relative terms: El Niño winters
            # bring several times the normal ~15 mm, which triggers the desierto florido
            self.yt["rain_mult"] = {"normal": 1.0, "seco": 0.2, "nino": 4.0}[year_type]
            self.yt["freq"] = {"normal": 1.0, "seco": 0.3, "nino": 3.5}[year_type]
        # how much of the wetter/drier year comes from more rain days vs bigger storms
        self.freq = self.yt.get("freq", self.yt["rain_mult"] ** 0.6)
        self.rng = rng
        self.anom = 0.0              # AR(1) temperature anomaly
        self.soil = 0.5              # 0..1 soil moisture index
        self.winter_rain = 0.0       # mm accumulated since May (desert bloom trigger)
        self.wet_yesterday = False
        self.today = None

    def mean_temp(self, doy):
        mid = (self.z.jan_mean + self.z.jul_mean) / 2
        amp = (self.z.jan_mean - self.z.jul_mean) / 2
        return mid + amp * math.cos(2 * math.pi * (doy - 15) / 365) + self.yt["temp_add"]

    def new_day(self, doy: int):
        z, rng = self.z, self.rng
        self.anom = 0.7 * self.anom + rng.normal(0, 1.8)
        # unconditional wet-day probability peaks in July (southern winter)
        w = 1 + 0.9 * math.cos(2 * math.pi * (doy - 196) / 365)
        p = min(0.9, z.rain_days / 365 * w * self.freq)
        r = self.PERSIST
        p_wet = p + r * (1 - p) if self.wet_yesterday else p * (1 - r)
        rain = rng.random() < p_wet
        self.wet_yesterday = rain
        mm = 0.0
        if rain:
            mean_mm = z.rain_mm * self.yt["rain_mult"] / self.freq / max(z.rain_days, 1)
            mm = float(rng.exponential(mean_mm))
        tmean = self.mean_temp(doy) + self.anom - (1.5 if rain else 0)
        dr = z.diurnal * (0.55 if rain else 1.0)
        self.soil = float(np.clip(self.soil * 0.975 + mm / 60.0
                                  - 0.004 * max(tmean - 10, 0), 0, 1))
        if 121 <= doy <= 273:        # May..Sep
            self.winter_rain += mm
        if rain:
            cloud = float(np.clip(rng.normal(.85, .08), .6, 1))
        else:
            cloud = float(np.clip(rng.beta(2, 2 / max(z.cloud, .05) - 2) if z.cloud > 0 else 0, 0, .95))
        wind = float(rng.gamma(4.0, z.wind / 4.0) * (1.3 if rain else 1.0))
        fog = (z.key in ("biobio_costa", "desierto")) and rng.random() < .35 and not rain
        self.today = dict(doy=doy, rain=rain, mm=mm, tmean=tmean,
                          tmin=tmean - dr / 2, tmax=tmean + dr / 2,
                          wet_frac=float(np.clip(0.35 + mm / 30, 0, 1)) if rain else 0.0,
                          daylen=day_length_hours(z.lat, doy),
                          cloud=cloud, wind=wind, fog=fog)
        return self.today

    def temp_at(self, hour: float) -> float:
        d = self.today
        return d["tmean"] + (d["tmax"] - d["tmean"]) * math.cos(2 * math.pi * (hour - 15) / 24)

    def raining_at(self, hour: float) -> bool:
        d = self.today
        if not d["rain"]:
            return False
        span = d["wet_frac"] * d["daylen"]
        return abs(hour - 13.5) < span / 2

    def wind_at(self, hour: float) -> float:
        """m/s; calm mornings, afternoon sea-breeze peak around 16 h."""
        d = self.today
        return d["wind"] * (0.45 + 0.9 * max(0.0, math.sin(math.pi * (hour - 9) / 12)))

    def cloud_at(self, hour: float) -> float:
        d = self.today
        c = d["cloud"]
        if d["fog"] and hour < 11.5:           # morning camanchaca burns off
            c = max(c, 0.9 - 0.25 * max(0.0, hour - 9))
        return c
