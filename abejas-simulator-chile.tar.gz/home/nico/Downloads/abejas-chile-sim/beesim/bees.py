"""Bee species. Units: 1 'load' = one honeybee crop-full of nectar (~40 mg).
Cell size is 20 m and one tick is 2 minutes, so speed 9 ≈ 1.5 m/s effective
(searching flight is slow and meandering; the beeline home uses speed * 1.8).
"""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Species:
    key: str
    name: str
    native: bool
    kind: str            # "apis" | "bumble" | "solitary"
    color: tuple
    min_t: float         # °C minimum air temp for flight
    max_t: float         # °C above this they stop (heat stress)
    speed: float         # cells / tick while searching
    range_cells: float   # typical max foraging distance from nest
    capacity: float      # loads per trip (per bee)
    tongue: float        # mm, compares to flower corolla depth
    poll_eff: float      # pollen transfer per visit (relative)
    buzz: float          # multiplier on buzz-pollinated crops (blueberry)
    scale: int           # real bees represented by one dot (target)
    max_dots: int
    # colony life-history
    c_worker: float = 0.0     # loads eaten per worker per day
    c_brood: float = 0.0
    lay_max: float = 0.0      # eggs per day
    dev_days: float = 21
    mort: float = 1 / 30      # daily worker mortality baseline
    pollen_per_brood: float = 0.1
    emerge_doy: int = 0       # bumblebee queen emergence / solitary season start
    season_end_doy: int = 0   # solitary flight season end
    repro_doy: int = 0        # bumblebee switch to producing new queens
    pathogen_carrier: bool = False
    pathogen_susceptible: bool = False
    # flight response (logistic): 50 % of foragers fly at t50 °C; wind50 m/s halves
    # activity; cloud_sens = how much heavy cloud suppresses flight (light-dependent bees)
    t50: float = 12.0
    wind50: float = 7.0
    cloud_sens: float = 0.4


def flight_prob(s: Species, temp, wind, cloud, raining):
    """Probability that a forager of species s is willing to fly right now."""
    import math
    if raining:
        return 0.0
    p_cold = 1 / (1 + math.exp(-(temp - s.t50) / 1.4))
    p_hot = 1 / (1 + math.exp((temp - s.max_t) / 1.2))
    p_wind = 1 / (1 + math.exp((wind - s.wind50) / 1.0))
    p_light = 1 - s.cloud_sens * max(0.0, cloud - 0.5) * 2
    return p_cold * p_hot * p_wind * p_light


SPECIES = [
    Species("apis", "Abeja de miel (Apis mellifera)", False, "apis", (240, 190, 40),
            min_t=11, max_t=38, speed=9, range_cells=110, capacity=1.0, tongue=6,
            poll_eff=0.6, buzz=0.5, scale=150, max_dots=120,
            c_worker=2.0, c_brood=1.5, lay_max=2000, dev_days=21, mort=1 / 35,
            pollen_per_brood=0.12, t50=12.5, wind50=7.0, cloud_sens=.5),
    Species("dahlbomii", "Abejorro colorado (Bombus dahlbomii, nativo)", True, "bumble", (214, 84, 24),
            min_t=5, max_t=29, speed=8, range_cells=60, capacity=2.5, tongue=9,
            poll_eff=1.0, buzz=2.0, scale=3, max_dots=40,
            c_worker=3.0, c_brood=2.0, lay_max=8, dev_days=25, mort=1 / 25,
            pollen_per_brood=1.5, emerge_doy=253, repro_doy=32,
            pathogen_susceptible=True, t50=7.0, wind50=9.5, cloud_sens=.2),
    Species("terrestris", "Abejorro europeo (Bombus terrestris, invasor)", False, "bumble", (28, 28, 30),
            min_t=5, max_t=34, speed=8, range_cells=75, capacity=2.0, tongue=7,
            poll_eff=0.8, buzz=2.0, scale=4, max_dots=40,
            c_worker=3.0, c_brood=2.0, lay_max=15, dev_days=24, mort=1 / 25,
            pollen_per_brood=1.5, emerge_doy=227, repro_doy=15,
            pathogen_carrier=True, t50=7.5, wind50=9.0, cloud_sens=.2),
    Species("solitaria", "Abejas nativas solitarias (Colletidae/Halictidae)", True, "solitary", (60, 170, 210),
            min_t=13, max_t=36, speed=4, range_cells=22, capacity=0.35, tongue=4,
            poll_eff=0.9, buzz=1.0, scale=1, max_dots=1,
            mort=1 / 40, pollen_per_brood=5, emerge_doy=244, season_end_doy=15,
            t50=14.5, wind50=5.0, cloud_sens=.7),
]
SP_INDEX = {s.key: i for i, s in enumerate(SPECIES)}

# how common each wild species is per zone (0..1)
PRESENCE = {
    "ohiggins":        {"dahlbomii": .15, "terrestris": .8, "solitaria": 1.0},
    "maule":           {"dahlbomii": .35, "terrestris": 1.0, "solitaria": 1.0},
    "nuble":           {"dahlbomii": .55, "terrestris": 1.0, "solitaria": 1.0},
    "biobio_costa":    {"dahlbomii": .8, "terrestris": 1.0, "solitaria": .9},
    "biobio_interior": {"dahlbomii": .8, "terrestris": 1.0, "solitaria": 1.0},
    "araucania":       {"dahlbomii": 1.0, "terrestris": 1.0, "solitaria": .9},
    "desierto":        {"dahlbomii": 0.0, "terrestris": 0.0, "solitaria": 1.0},
}
