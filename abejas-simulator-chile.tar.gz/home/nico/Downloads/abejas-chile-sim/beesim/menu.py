"""Terminal menu to pick a scenario from presets."""
from .climate import ZONES, YEAR_TYPES
from .flora import HABITATS
from .world import Scenario


def _pick(title, options, default=0):
    """options: list of (value, label). Returns value."""
    print(f"\n{title}")
    for i, (_, label) in enumerate(options, 1):
        mark = "  (por defecto)" if i - 1 == default else ""
        print(f"  {i}) {label}{mark}")
    while True:
        raw = input("> ").strip()
        if raw == "":
            return options[default][0]
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1][0]
        print("  Escribe un número de la lista / type a number from the list")


def interactive() -> Scenario:
    print("=" * 64)
    print(" Abejas de Chile central — simulador de polinizadores")
    print(" Enter = opción por defecto")
    print("=" * 64)
    zone = _pick("Zona climática / climate zone",
                 [(k, f"{z.name}  [{z.koppen}]") for k, z in ZONES.items()], default=3)
    size = _pick("Tamaño del área / map size",
                 [(3, "3 x 3 km (rápido, un valle o un barrio)"),
                  (6, "6 x 6 km (comuna pequeña)"),
                  (12, "12 x 12 km (paisaje regional, más lento)")])
    habs = HABITATS[zone]
    habitat = _pick("Tu entorno / your environment",
                    [(h.key, h.name + (f"  — {h.note}" if h.note else "")) for h in habs],
                    default=len(habs) - 1 if size > 3 else 0)
    year = _pick("Tipo de año / year type",
                 [(k, v["label"]) for k, v in YEAR_TYPES.items()],
                 default=2 if zone == "desierto" else 0)
    hives = _pick("Colmenas por cada 9 km² / managed honeybee hives per 9 km²",
                  [(0, "Ninguna"), (2, "2 colmenas"), (4, "4 colmenas (apicultor pequeño)"),
                   (10, "10 colmenas (apiario comercial)")], default=2)
    pest = _pick("Pesticidas en cultivos en flor / pesticides on flowering crops",
                 [("ninguno", "Ninguno"), ("moderado", "Moderado"), ("alto", "Alto (neonicotinoides)")])
    nest = _pick("Sitios de nidificación para abejas nativas / native nesting habitat",
                 [("bajo", "Pocos (suelo compactado, sin hoteles)"),
                  ("medio", "Medio (algo de suelo desnudo + 1 hotel de abejas)"),
                  ("alto", "Alto (suelo desnudo, taludes + 3 hoteles)")], default=1)
    terr = _pick("Bombus terrestris (invasor)",
                 [("auto", "Según la zona (realista)"), ("ausente", "Ausente (¿y si nunca hubiera llegado?)"),
                  ("presente", "Presente en abundancia")])
    strips = _pick("Franjas florales nativas / native flower strips",
                   [(False, "No"), (True, "Sí (~4 % del paisaje)")])
    days = _pick("Duración / duration",
                 [(240, "Temporada completa: 1 ago → 28 mar"), (120, "Primavera: 1 ago → 28 nov"),
                  (30, "Prueba rápida: 30 días")])
    return Scenario(zone=zone, habitat=habitat, year=year, hives=hives, pesticide=pest,
                    nesting=nest, terrestris=terr, flower_strips=strips, days=days, size_km=size)
