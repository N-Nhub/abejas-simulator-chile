"""Live view of the simulation.

Mouse: wheel zooms (from the whole map down to ~0.4 m per pixel), drag pans,
       click the minimap to jump, hover a plant or nest for details.
Keys:  Space pause, Up/Down speed, D skip to the next day, H visit map,
       R whole map, +/- zoom, F fullscreen, S screenshot, Q/Esc stop and save.
"""
import datetime as dt
import math
import random

import numpy as np
import pygame

from .world import HOME, FORAGE, CELL_CAP, CELL_M
from .bees import SPECIES
from .art import (PADC, Clouds, BeeSprites, font, hive_sprite, nest_sprite, hotel_sprite,
                  weather_icon, flower_tile, shade)
from .tiles import TileRenderer, TILE

WIN_W, WIN_H = 1600, 900
MAP = 900
PX0 = MAP
PAD = 36
MAX_S = 48.0                 # screen px per 20 m cell at full zoom
MINI = 176

PAPER = (233, 237, 226)
INK = (31, 51, 38)
INK2 = (88, 106, 92)
RULE = (198, 207, 190)
HONEY = (201, 138, 18)
LEAF = (60, 128, 64)

MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
          "septiembre", "octubre", "noviembre", "diciembre"]
SCI = {"apis": ("Apis mellifera", "introducida"), "dahlbomii": ("Bombus dahlbomii", "nativa"),
       "terrestris": ("Bombus terrestris", "invasora"), "solitaria": ("Colletidae y Halictidae", "nativas")}
COMMON = {"apis": "Abeja de miel", "dahlbomii": "Abejorro colorado",
          "terrestris": "Abejorro europeo", "solitaria": "Abejas solitarias"}
DOT_COL = {"apis": (240, 190, 40), "dahlbomii": (226, 96, 30), "terrestris": (24, 24, 26), "solitaria": (60, 170, 210)}


def num(x, dec=0):
    s = f"{float(x):,.{dec}f}"
    return s.replace(",", "§").replace(".", ",").replace("§", ".")


def long_date(doy):
    d = dt.date(2025, 1, 1) + dt.timedelta(days=doy - 1)
    return f"{d.day} de {MONTHS[d.month - 1]}"


def hhmm(h):
    return f"{int(h):02d}:{int((h % 1) * 60):02d}"


class Viewer:
    def __init__(self, world, out_dir, team=""):
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_caption("Abejas de Chile central")
        self.screen = pygame.display.set_mode((WIN_W, WIN_H), pygame.SCALED | pygame.RESIZABLE)
        self.w = world
        self.G = world.G
        self.out_dir = out_dir
        self.team = team
        self._loading("Preparando el paisaje…")
        self.tiles = TileRenderer(world)
        self.clouds = Clouds(world.sc.seed)
        self.bees = BeeSprites()
        self.clock = pygame.time.Clock()
        self.speed = 4
        self.paused = False
        self.heatmap = False
        self.frame = 0
        self.ticks = 0
        self._text_cache = {}
        self.min_s = MAP / self.G
        self.s = self.min_s           # screen px per cell
        self.cx = self.cy = 0.0       # map cell at the viewport's top-left
        self.dragging = False
        self.view_dirty = True
        self.view_img = pygame.Surface((MAP, MAP))
        self.scaled = {}
        self.scaled_s = None
        self.overlay = None
        self.overlay_tick = -999
        self.hd = np.zeros(world.N, np.float32)
        self.px = world.x.copy()
        self.py = world.y.copy()
        self.trail = pygame.Surface((MAP, MAP), pygame.SRCALPHA)
        self.vignette = self._make_vignette()
        self.rain_rng = np.random.default_rng(3)
        self.cache = {}
        self.day_built = -1
        self.mini_img = None
        self.present = set(int(j) for j in world.present_plants)

    # ------------------------------------------------------------- helpers
    def _loading(self, msg):
        self.screen.fill(PAPER)
        t = font(26, bold=True).render(msg, True, INK)
        self.screen.blit(t, t.get_rect(center=(WIN_W / 2, WIN_H / 2)))
        pygame.display.flip()

    def _make_vignette(self):
        yy, xx = np.mgrid[0:MAP, 0:MAP]
        d = np.hypot((xx - MAP / 2) / (MAP / 2), (yy - MAP / 2) / (MAP / 2))
        a = np.clip((d - .75) / .7, 0, 1) ** 1.6 * 110
        s = pygame.Surface((MAP, MAP), pygame.SRCALPHA)
        s.fill((14, 20, 12, 0))
        pygame.surfarray.pixels_alpha(s)[:] = a.T.astype(np.uint8)
        return s

    def text(self, s, size, color=INK, bold=False, italic=False):
        key = (s, size, color, bold, italic)
        t = self._text_cache.get(key)
        if t is None:
            if len(self._text_cache) > 800:
                self._text_cache.clear()
            t = font(size, bold, italic).render(s, True, color)
            self._text_cache[key] = t
        return t

    def put(self, s, x, y, size, color=INK, bold=False, italic=False, anchor="topleft"):
        t = self.text(s, size, color, bold, italic)
        r = t.get_rect(**{anchor: (x, y)})
        self.screen.blit(t, r)
        return r

    # -------------------------------------------------------------- camera
    def clamp_camera(self):
        self.s = min(MAX_S, max(self.min_s, self.s))
        span = MAP / self.s
        self.cx = float(min(max(self.cx, 0), self.G - span))
        self.cy = float(min(max(self.cy, 0), self.G - span))

    def camera_changed(self):
        self.view_dirty = True
        self.overlay = None
        self.trail.fill((0, 0, 0, 0))

    def zoom_at(self, mx, my, factor):
        wx, wy = self.cx + mx / self.s, self.cy + my / self.s
        self.s *= factor
        self.clamp_camera()
        self.cx, self.cy = wx - mx / self.s, wy - my / self.s
        self.clamp_camera()
        self.camera_changed()

    def center_on(self, wx, wy):
        span = MAP / self.s
        self.cx, self.cy = wx - span / 2, wy - span / 2
        self.clamp_camera()
        self.camera_changed()

    def to_screen(self, wx, wy):
        sx, sy = (wx - self.cx) * self.s, (wy - self.cy) * self.s
        if np.ndim(sx) == 0:
            return float(sx), float(sy)
        return sx, sy

    # ------------------------------------------------------------ the map
    def compose_view(self):
        """Blit the visible tiles (any level of detail) into self.view_img."""
        w = self.w
        if self.day_built != w.day_index:
            if self.tiles.update_day():
                self.mini_img = None
                self.scaled.clear()
            self.day_built = w.day_index
            self.view_dirty = True
        if not self.view_dirty:
            return
        t = self.tiles
        t.begin_frame()
        s = self.s
        if self.scaled_s != round(s, 4):
            self.scaled.clear()
            self.scaled_s = round(s, 4)
        p = t.pick_level(s)
        span = MAP / s
        tx0, tx1 = int(self.cx * p // TILE), int((self.cx + span) * p // TILE)
        ty0, ty1 = int(self.cy * p // TILE), int((self.cy + span) * p // TILE)
        nmax = int(math.ceil(self.G * p / TILE)) - 1
        img = self.view_img
        incomplete = False
        # render nearest-to-centre tiles first so the middle sharpens first
        order = sorted(((tx, ty) for tx in range(tx0, min(tx1, nmax) + 1) for ty in range(ty0, min(ty1, nmax) + 1)),
                       key=lambda q: (q[0] - (tx0 + tx1) / 2) ** 2 + (q[1] - (ty0 + ty1) / 2) ** 2)
        for tx, ty in order:
            X0 = math.floor((tx * TILE / p - self.cx) * s)
            X1 = math.floor(((tx + 1) * TILE / p - self.cx) * s)
            Y0 = math.floor((ty * TILE / p - self.cy) * s)
            Y1 = math.floor(((ty + 1) * TILE / p - self.cy) * s)
            surf, fresh = t.get(p, tx, ty)
            if not fresh:
                incomplete = True
            key = (p, tx, ty, X1 - X0, Y1 - Y0, id(surf))
            sc = self.scaled.get(key)
            if sc is None:
                if surf is None:
                    sc = self._overview_patch(tx * TILE / p, ty * TILE / p, TILE / p, (X1 - X0, Y1 - Y0))
                else:
                    sc = pygame.transform.smoothscale(surf, (max(1, X1 - X0), max(1, Y1 - Y0)))
                    self.scaled[key] = sc
                    if len(self.scaled) > 400:
                        self.scaled.clear()
            img.blit(sc, (X0, Y0))
        self.view_dirty = incomplete

    def _overview_patch(self, c0, r0, n, size):
        ov = self.tiles.overview
        r = pygame.Rect(int(c0), int(r0), max(1, int(math.ceil(n))), max(1, int(math.ceil(n))))
        r = r.clip(ov.get_rect())
        if r.w == 0 or r.h == 0:
            return pygame.Surface((max(1, size[0]), max(1, size[1])))
        return pygame.transform.smoothscale(ov.subsurface(r), (max(1, size[0]), max(1, size[1])))

    def draw_overlay(self):
        """Nectar depletion (and the visit heat map) for the visible cells."""
        w, G = self.w, self.G
        if self.overlay is None or self.ticks - self.overlay_tick >= 15:
            self.overlay_tick = self.ticks
            span = MAP / self.s
            i0, j0 = int(self.cx), int(self.cy)
            i1, j1 = min(G, int(math.ceil(self.cx + span)) + 1), min(G, int(math.ceil(self.cy + span)) + 1)
            cap = w.cap.reshape(G, G)[j0:j1, i0:i1]
            nec = w.nectar.reshape(G, G)[j0:j1, i0:i1]
            frac = np.where(cap > 0, nec / np.maximum(cap, 1e-6), 1)
            weight = np.clip(cap / (0.3 * CELL_CAP), 0, 1)
            rgba = np.zeros(cap.shape + (4,), np.uint8)
            rgba[..., :3] = (66, 46, 26)
            rgba[..., 3] = (np.clip(1 - frac, 0, 1) * weight * 120).astype(np.uint8)
            if self.heatmap:
                hh = np.log1p(w.heat.reshape(G, G)[j0:j1, i0:i1])
                hh = hh / max(float(np.log1p(w.heat).max()), 1e-6)
                rgba[..., 0] = (66 + hh * 189).astype(np.uint8)
                rgba[..., 1] = (46 + hh * 60).astype(np.uint8)
                rgba[..., 2] = (26 + hh * 10).astype(np.uint8)
                rgba[..., 3] = np.maximum(rgba[..., 3], (hh * 200).astype(np.uint8))
            small = pygame.image.frombuffer(np.ascontiguousarray(rgba).tobytes(), (i1 - i0, j1 - j0), "RGBA")
            size = (max(1, round((i1 - i0) * self.s)), max(1, round((j1 - j0) * self.s)))
            self.overlay = (pygame.transform.smoothscale(small, size) if self.s < 16
                            else pygame.transform.scale(small, size))
            self.overlay_pos = ((i0 - self.cx) * self.s, (j0 - self.cy) * self.s)
        self.screen.blit(self.overlay, self.overlay_pos)

    def draw_clouds(self):
        cover = float(self.w.cloud_now)
        if cover < .12:
            return
        tile = self.clouds.surface(min(cover, .85))
        if tile is None:
            return
        T = max(32, int(128 * self.s))
        key = ("cloud", round(min(cover, .85) * 20), T)
        st = self.cache.get(key)
        if st is None:
            f = T / 512
            full = pygame.transform.smoothscale(tile, (round(tile.get_width() * f), round(tile.get_height() * f)))
            m = round(PADC * f)
            st = full.subsurface(pygame.Rect(m, m, T, T)).copy()
            if len([k for k in self.cache if k[0] == "cloud"]) > 12:
                for k in [k for k in self.cache if k[0] == "cloud"]:
                    del self.cache[k]
            self.cache[key] = st
        drift = self.w.hour * 18 + self.w.day_index * 90          # cells
        ox = int(-((self.cx + drift) * self.s) % T)
        oy = int(-((self.cy + drift * .35) * self.s) % T)
        x = ox - T
        while x < MAP:
            y = oy - T
            while y < MAP:
                self.screen.blit(st, (x, y))
                y += T
            x += T

    def nest_icon(self, kind, scale, extra):
        key = ("nest", kind, round(scale * 4) / 4, extra)
        s = self.cache.get(key)
        if s is None:
            if kind == "hive":
                s = hive_sprite(scale, extra)
            elif kind == "hotel":
                s = hotel_sprite(scale)
            else:
                s = nest_sprite(scale, extra[0], extra[1])
            self.cache[key] = s
        return s

    def draw_nests(self):
        w = self.w
        z = min(5.0, max(.6, self.s / 6)) ** .6
        for site in w.hotel_sites:
            sx, sy = self.to_screen(site[0], site[1])
            if -40 < sx < MAP + 40 and -40 < sy < MAP + 40:
                s = self.nest_icon("hotel", z, None)
                self.screen.blit(s, s.get_rect(midbottom=(sx, sy + 6 * z)))
        for c in w.colonies:
            sp = SPECIES[c.sp]
            sx, sy = self.to_screen(c.x, c.y)
            if not (-40 < sx < MAP + 40 and -40 < sy < MAP + 40):
                continue
            if sp.kind == "apis":
                s = self.nest_icon("hive", z, c.cid % 5)
                self.screen.blit(s, s.get_rect(midbottom=(sx, sy + 6 * z)))
            elif sp.kind == "bumble" and c.alive:
                if self.s < 3:
                    pygame.draw.circle(self.screen, sp.color, (sx, sy), 2)
                else:
                    s = self.nest_icon("bumble", z, (sp.color, c.active))
                    self.screen.blit(s, s.get_rect(center=(sx, sy)))
            elif sp.kind == "solitary" and c.active and not c.hotel and self.s > 12:
                pygame.draw.circle(self.screen, (120, 92, 60), (sx, sy), 2.5 * z)
                pygame.draw.circle(self.screen, (52, 38, 26), (sx, sy), 1.2 * z)

    def draw_bees(self):
        w = self.w
        idx = np.flatnonzero(w.on & (w.state != HOME))
        dx, dy = w.x - self.px, w.y - self.py
        moved = np.hypot(dx, dy) > 0.02
        self.hd = np.where(moved, np.arctan2(dy, dx), self.hd).astype(np.float32)
        sx, sy = self.to_screen(w.x[idx], w.y[idx])
        vis = (sx > -12) & (sx < MAP + 12) & (sy > -12) & (sy < MAP + 12)
        if self.s < 3:                      # far zoom: bees as coloured specks
            for a, x, y in zip(idx[vis], sx[vis], sy[vis]):
                self.screen.fill(DOT_COL[SPECIES[w.sp[a]].key], (int(x), int(y), 2, 2))
            self.px[:], self.py[:] = w.x, w.y
            return
        z = min(7.0, max(.9, self.s / 6)) ** .6
        sdx, sdy = -(w.hour - 12) * .8 * z, 3.0 * z
        self.trail.fill((255, 255, 255, 196), special_flags=pygame.BLEND_RGBA_MULT)
        fly = idx[w.state[idx] != FORAGE]
        if len(fly) and self.speed <= 12 and not self.paused:
            x0, y0 = self.to_screen(self.px[fly], self.py[fly])
            x1, y1 = self.to_screen(w.x[fly], w.y[fly])
            d = np.hypot(x1 - x0, y1 - y0)
            for i in np.flatnonzero((d > .5) & (d < 40)):
                pygame.draw.line(self.trail, (255, 250, 228, 64), (float(x0[i]), float(y0[i])),
                                 (float(x1[i]), float(y1[i])), 1)
        self.screen.blit(self.trail, (0, 0))
        seq, shadows = [], []
        for a, x, y in zip(idx[vis], sx[vis], sy[vis]):
            x, y = float(x), float(y)
            key = SPECIES[w.sp[a]].key
            feeding = w.state[a] == FORAGE
            frame = 2 if feeding else (self.frame + int(a)) % 2
            if feeding:
                x += math.sin(self.frame * 1.7 + a) * .6 * z
            spr = self.bees.get(key, z, frame, float(self.hd[a]))
            sh = self.bees.shadow(key, z)
            off = .35 if feeding else 1.0
            shadows.append((sh, (x - sh.get_width() / 2 + sdx * off, y - sh.get_height() / 2 + sdy * off)))
            seq.append((spr, (x - spr.get_width() / 2, y - spr.get_height() / 2)))
        self.screen.blits(shadows, doreturn=False)
        self.screen.blits(seq, doreturn=False)
        self.px[:], self.py[:] = w.x, w.y

    def light(self):
        w = self.w
        span = max(w.sunset - w.sunrise, 1)
        t = min(max((w.hour - w.sunrise) / span, 0), 1)
        elev = math.sin(math.pi * t)
        warm = (255, 176, 128)
        tint = [warm[i] + (b - warm[i]) * elev ** .45 for i, b in enumerate((255, 252, 246))]
        bright = (.64 + .36 * elev ** .35) * (1 - .18 * float(w.cloud_now))
        if w.rain_now:
            bright *= .8
            tint = [tint[0] * .9, tint[1] * .95, tint[2]]
        col = tuple(int(c * bright) for c in tint)
        self.screen.fill(col, pygame.Rect(0, 0, MAP, MAP), special_flags=pygame.BLEND_RGB_MULT)

    def draw_rain(self):
        if not self.w.rain_now:
            return
        r = self.rain_rng
        n = 260
        for x, y, l in zip(r.uniform(0, MAP, n), r.uniform(0, MAP, n), r.uniform(10, 22, n)):
            pygame.draw.aaline(self.screen, (196, 210, 226), (x, y), (x - l * .25, y + l))

    def shadow_text(self, s, x, y, size, anchor="topleft"):
        t = self.text(s, size, (16, 22, 14), bold=True)
        r = t.get_rect(**{anchor: (x + 1, y + 1)})
        self.screen.blit(t, r)
        self.screen.blit(self.text(s, size, (250, 250, 244), bold=True), r.move(-1, -1))

    def pill(self, s, x, y):
        t = self.text(s, 16, INK, bold=True)
        r = pygame.Rect(x, y, t.get_width() + 24, t.get_height() + 10)
        pygame.draw.rect(self.screen, PAPER, r, border_radius=r.h // 2)
        self.screen.blit(t, (x + 12, y + 5))

    def minimap_rect(self):
        return pygame.Rect(MAP - MINI - 18, 18, MINI, MINI)

    def draw_minimap(self):
        if self.tiles.overview is None or self.s <= self.min_s * 1.05:
            return
        r = self.minimap_rect()
        if self.mini_img is None:
            self.mini_img = pygame.transform.smoothscale(self.tiles.overview, (MINI, MINI))
        pygame.draw.rect(self.screen, PAPER, r.inflate(8, 8), border_radius=6)
        self.screen.blit(self.mini_img, r)
        k = MINI / self.G
        span = MAP / self.s
        vr = pygame.Rect(r.x + self.cx * k, r.y + self.cy * k, max(3, span * k), max(3, span * k))
        pygame.draw.rect(self.screen, (255, 255, 255), vr, 2)
        pygame.draw.rect(self.screen, INK, vr.inflate(2, 2), 1)
        # north arrow in the minimap corner
        nx, ny = r.x + 14, r.y + 18
        pygame.draw.polygon(self.screen, (250, 250, 244), [(nx, ny - 11), (nx - 6, ny + 6), (nx, ny + 2), (nx + 6, ny + 6)])
        pygame.draw.polygon(self.screen, INK, [(nx, ny - 11), (nx, ny + 2), (nx + 6, ny + 6)])
        self.shadow_text("N", nx, ny + 8, 13, anchor="midtop")
        self.put(f"{self.w.sc.size_km} × {self.w.sc.size_km} km", r.right, r.bottom + 8, 13, PAPER, bold=True,
                 anchor="topright")

    def map_furniture(self):
        m_per_px = CELL_M / self.s
        label, bar = "", 0
        for L in (5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000):
            if L / m_per_px >= 70:
                bar, label = L / m_per_px, (f"{L // 1000} km" if L >= 1000 else f"{L} m")
                break
        x0, y0 = 28, MAP - 34
        pygame.draw.rect(self.screen, (250, 250, 244), (x0, y0, bar, 6))
        pygame.draw.rect(self.screen, INK, (x0, y0, bar / 2, 6))
        pygame.draw.rect(self.screen, INK, (x0 - 1, y0 - 1, bar + 2, 8), 1)
        self.shadow_text(label, x0, y0 - 24, 16)
        self.draw_minimap()
        if self.s <= self.min_s * 1.05:
            nx, ny = MAP - 40, 46
            pygame.draw.polygon(self.screen, (250, 250, 244), [(nx, ny - 20), (nx - 9, ny + 8), (nx, ny + 2), (nx + 9, ny + 8)])
            pygame.draw.polygon(self.screen, INK, [(nx, ny - 20), (nx, ny + 2), (nx + 9, ny + 8)])
            self.shadow_text("N", nx, ny + 12, 16, anchor="midtop")
            self.shadow_text(f"{self.w.sc.size_km} × {self.w.sc.size_km} km", MAP - 22, ny + 34, 14, anchor="topright")
        y = 22
        if self.paused:
            self.pill("En pausa", 24, y)
            y += 40
        if self.heatmap:
            self.pill("Mapa de visitas", 24, y)
            y += 40
        if self.view_dirty:
            self.pill("Dibujando detalle…", 24, y)

    # ----------------------------------------------------------------- tooltip
    def tooltip(self):
        mx, my = pygame.mouse.get_pos()
        on_mini = self.s > self.min_s * 1.05 and self.minimap_rect().collidepoint(mx, my)
        if not (0 <= mx < MAP and 0 <= my < MAP) or self.dragging or on_mini:
            return
        w, G = self.w, self.G
        lines = []
        best, bd = None, 14
        if self.s >= 3:
            for c in w.colonies:
                sx, sy = self.to_screen(c.x, c.y)
                d = math.hypot(sx - mx, sy - my)
                if d < bd and (SPECIES[c.sp].kind != "solitary" or c.active or c.hotel):
                    best, bd = c, d
        if best is not None:
            c, sp = best, SPECIES[best.sp]
            if sp.kind == "apis":
                lines = [(f"Colmena {c.cid + 1}", True),
                         (f"{num(c.W)} pecoreadoras, {num(c.H)} abejas internas", False),
                         (f"{num(c.B)} crías, reservas {num(c.S)} cargas", False)]
            elif sp.kind == "bumble":
                state = "activo" if c.active else ("sin colonia" if not c.alive else "reina hibernando")
                lines = [(f"Nido de {COMMON[sp.key].lower()}", True),
                         (f"Estado: {state}, {num(c.W)} obreras", False),
                         (f"Nuevas reinas: {num(c.new_queens, 1)}", False)]
                if sp.pathogen_susceptible:
                    lines.append((f"Infección: {num(c.infection * 100)} %", False))
                if sp.pathogen_carrier:
                    lines.append(("Porta parásitos" if c.carrier else "Sin parásitos", False))
            else:
                lines = [("Abeja solitaria" + (" en hotel de abejas" if c.hotel else ", nido en el suelo"), True),
                         (f"Celdas de cría: {num(c.cells, 1)}", False)]
        else:
            cx, cy = int(self.cx + mx / self.s), int(self.cy + my / self.s)
            if 0 <= cx < G and 0 <= cy < G and w.pid[cy, cx] >= 0:
                j = int(w.pid[cy, cx])
                p = w.plants[j]
                i = cy * G + cx
                lines = [(p.name, True), ("Nativa" if p.native else "Introducida", False),
                         (f"Floración: {num(w.bloom[j] * 100)} %", False)]
                if w.cap[i] > 0:
                    lines.append((f"Néctar disponible: {num(w.nectar[i] / w.cap[i] * 100)} %", False))
                if w.poll_cell[i] > 0 and p.crop:
                    lines.append((f"Polinización: {num((1 - math.exp(-w.poll_cell[i] / 40)) * 100)} %", False))
            if w.region is not None and 0 <= cx < G and 0 <= cy < G:
                lines.append((w.region_names[int(w.region[cy, cx])], False))
        if not lines:
            return
        surfs = [self.text(s, 16 if b else 15, INK if b else INK2, bold=b) for s, b in lines]
        wbox = max(s.get_width() for s in surfs) + 24
        hbox = sum(s.get_height() + 2 for s in surfs) + 18
        x = mx + 18 if mx + 18 + wbox < MAP else mx - 18 - wbox
        y = min(my + 14, MAP - hbox - 6)
        sh = pygame.Surface((wbox, hbox), pygame.SRCALPHA)
        pygame.draw.rect(sh, (10, 16, 10, 70), sh.get_rect(), border_radius=8)
        self.screen.blit(sh, (x + 3, y + 4))
        pygame.draw.rect(self.screen, PAPER, (x, y, wbox, hbox), border_radius=8)
        yy = y + 9
        for s in surfs:
            self.screen.blit(s, (x + 12, yy))
            yy += s.get_height() + 2

    # ------------------------------------------------------------------- panel
    def sparkline(self, vals, rect, color):
        pygame.draw.line(self.screen, RULE, (rect.left, rect.bottom), (rect.right, rect.bottom))
        if len(vals) < 2:
            return
        v = np.log10(np.maximum(np.array(vals, float), 1))
        top = max(v.max(), 1)
        n = max(self.w.sc.days, len(v))
        pts = [(rect.left + i / (n - 1) * rect.w, rect.bottom - 2 - (x / top) * (rect.h - 4)) for i, x in enumerate(v)]
        sub = pygame.Surface((rect.w + 2, rect.h + 2), pygame.SRCALPHA)
        poly = [(0, rect.h)] + [(x - rect.left, y - rect.top) for x, y in pts] + [(pts[-1][0] - rect.left, rect.h)]
        pygame.draw.polygon(sub, (*color, 52), poly)
        self.screen.blit(sub, rect.topleft)
        pygame.draw.aalines(self.screen, color, False, pts)
        pygame.draw.circle(self.screen, color, pts[-1], 3)

    def species_icon(self, key):
        k = ("icon", key)
        if k not in self.cache:
            self.cache[k] = self.bees.get(key, 2.5, 0, -math.pi / 2)
        return self.cache[k]

    def flower_icon(self, j):
        k = ("fl", j)
        if k not in self.cache:
            self.cache[k] = flower_tile(self.w.plants[j].color, 1, random.Random(1), radius=.1, tile=20, dot=4.2)
        return self.cache[k]

    def wrap(self, text, x, y, width, size, color):
        line = ""
        for wd in text.split():
            test = (line + " " + wd).strip()
            if font(size).size(test)[0] > width and line:
                self.put(line, x, y, size, color)
                line, y = wd, y + size + 3
            else:
                line = test
        self.put(line, x, y, size, color)
        return y + size + 3

    def species_status(self, i, s, act, flying):
        w = self.w
        if not act:
            return "Sin actividad", INK2
        if flying:
            return "Volando", LEAF
        if w.fly_p[i] < .15:
            if w.rain_now:
                return "Llueve", INK2
            if w.temp_now < s.t50:
                return "Hace frío", INK2
            if w.temp_now > s.max_t:
                return "Hace calor", INK2
            if w.wind_now > s.wind50:
                return "Mucho viento", INK2
            return "Muy nublado", INK2
        return "En el nido", INK2

    def draw_panel(self):
        w = self.w
        scr = self.screen
        scr.fill(PAPER, pygame.Rect(PX0, 0, WIN_W - PX0, WIN_H))
        pygame.draw.line(scr, shade(PAPER, .8), (PX0, 0), (PX0, WIN_H))
        x0, xr = PX0 + PAD, WIN_W - PAD
        y = 24
        if self.team:
            y = self.put(self.team, x0, y, 16, HONEY, bold=True).bottom + 2
        zs = 30
        while zs > 20 and font(zs, True).size(w.zone.name)[0] > xr - x0:
            zs -= 1
        y = self.put(w.zone.name, x0, y, zs, INK, bold=True).bottom + 1
        hab = w.habitat.name
        while font(19).size(hab)[0] > xr - x0 and len(hab) > 10:
            hab = hab[:-2].rstrip() + "…"
        y = self.put(hab, x0, y, 19, INK2).bottom + 16

        wx = w.today
        top = y
        self.put(long_date(w.doy), x0, top, 28, INK, bold=True)
        self.put(f"Día {w.day_index + 1} de {w.sc.days}", x0, top + 36, 16, INK2)
        ax, aw, ah = x0 + 236, 170, 56
        base = top + 62
        pygame.draw.line(scr, RULE, (ax - 8, base), (ax + aw + 8, base), 2)
        pygame.draw.arc(scr, RULE, pygame.Rect(ax, base - ah, aw, ah * 2), 0, math.pi, 2)
        span = max(w.sunset - w.sunrise, 1)
        t = min(max((w.hour - w.sunrise) / span, 0), 1)
        sxp = ax + aw / 2 - math.cos(math.pi * t) * aw / 2
        syp = base - math.sin(math.pi * t) * ah
        pygame.draw.circle(scr, (240, 190, 50), (sxp, syp), 9)
        pygame.draw.circle(scr, HONEY, (sxp, syp), 9, 2)
        self.put(hhmm(w.hour), ax + aw / 2, base - 20, 22, INK, bold=True, anchor="midbottom")
        self.put(hhmm(w.sunrise), ax - 8, base + 4, 13, INK2)
        self.put(hhmm(w.sunset), ax + aw + 8, base + 4, 13, INK2, anchor="topright")
        cover = float(w.cloud_now)
        kind = "rain" if w.rain_now else "cloud" if cover >= .65 else "partly" if cover > .3 else "sun"
        cond = {"rain": "Lluvia", "cloud": "Nublado", "partly": "Parcialmente nublado", "sun": "Despejado"}[kind]
        if kind == "cloud" and wx.get("fog") and w.hour < 11.5:
            cond = "Neblina costera"
        wxx = ax + aw + 40
        ik = ("wicon", kind)
        if ik not in self.cache:
            self.cache[ik] = weather_icon(kind, 44)
        scr.blit(self.cache[ik], (wxx, top + 2))
        self.put(f"{num(w.temp_now, 1)} °C", wxx + 52, top + 2, 26, INK, bold=True)
        self.put(cond, wxx + 52, top + 36, 15, INK2)
        self.put(f"Viento {num(w.wind_now * 3.6)} km/h", wxx + 52, top + 56, 14, INK2)
        y = base + 30
        n = w.sc.days
        tl = pygame.Rect(x0, y, xr - x0, 6)
        pygame.draw.rect(scr, RULE, tl, border_radius=3)
        prog = min((w.day_index + (w.hour - w.sunrise) / span) / n, 1)
        pygame.draw.rect(scr, HONEY, (tl.x, tl.y, max(6, tl.w * prog), tl.h), border_radius=3)
        start = dt.date(2025, 1, 1) + dt.timedelta(days=w.sc.start_doy - 1)
        for i in range(n):
            d = start + dt.timedelta(days=i)
            if d.day == 1:
                xx = tl.x + i / n * tl.w
                pygame.draw.line(scr, INK2, (xx, tl.bottom + 2), (xx, tl.bottom + 7))
                self.put(MONTHS[d.month - 1][:3], xx + 3, tl.bottom + 3, 12, INK2)
        y = tl.bottom + 28
        self.put("Humedad del suelo", x0, y, 14, INK2)
        sb = pygame.Rect(x0 + 132, y + 7, 150, 6)
        pygame.draw.rect(scr, RULE, sb, border_radius=3)
        pygame.draw.rect(scr, (70, 110, 150), (sb.x, sb.y, max(4, sb.w * w.weather.soil), sb.h), border_radius=3)
        self.put(f"Lluvia hoy: {num(wx['mm'])} mm, mín {num(wx['tmin'])}°, máx {num(wx['tmax'])}°",
                 x0 + 300, y, 14, INK2)
        y += 32

        pygame.draw.line(scr, RULE, (x0, y), (xr, y))
        y += 12
        self.put("Abejas", x0, y, 20, INK, bold=True)
        self.put("Obreras en la temporada", xr, y + 6, 13, INK2, anchor="topright")
        y += 34
        hist = w.daily
        for i, s in enumerate(SPECIES):
            cs = [c for c in w.colonies if c.sp == i]
            if not cs:
                continue
            act = [c for c in cs if c.active]
            workers = sum(c.W for c in act)
            flying = int((w.on & (w.sp == i) & (w.state != HOME)).sum())
            status, scol = self.species_status(i, s, act, flying)
            icon = self.species_icon(s.key)
            scr.blit(icon, icon.get_rect(center=(x0 + 18, y + 24)))
            self.put(COMMON[s.key], x0 + 48, y, 18, INK, bold=True)
            sci, origin = SCI[s.key]
            r = self.put(sci, x0 + 48, y + 23, 15, INK2, italic=True)
            self.put(f", {origin}", r.right, y + 23, 15, INK2)
            if s.kind == "apis":
                desc = f"{len(act)} colmenas, {num(workers)} pecoreadoras"
            elif s.kind == "bumble":
                desc = f"{len(act)} nidos activos, {num(workers)} obreras"
            else:
                desc = f"{len(act)} hembras construyendo nidos"
            self.put(desc, x0 + 48, y + 43, 14, INK)
            dot_x = x0 + 318
            pygame.draw.circle(scr, scol, (dot_x + 5, y + 11), 5)
            self.put(status, dot_x + 16, y + 1, 15, scol, bold=scol == LEAF)
            spark_col = (60, 58, 54) if s.key == "terrestris" else shade(s.color, .8)
            self.sparkline([d[f"{s.key}_obreras"] for d in hist], pygame.Rect(xr - 150, y + 8, 150, 44), spark_col)
            y += 68
        y += 4

        pygame.draw.line(scr, RULE, (x0, y), (xr, y))
        y += 12
        colw = (xr - x0 - 36) // 2
        lx, rx = x0, x0 + colw + 36
        self.put("En flor", lx, y, 20, INK, bold=True)
        self.put("Ayer", rx, y, 20, INK, bold=True)
        top2 = y + 34
        order = [int(j) for j in np.argsort(-w.bloom) if w.bloom[j] >= .05 and int(j) in self.present]
        yy = top2
        bottom_limit = WIN_H - 104
        if not order:
            yy = self.wrap("Nada florece hoy en este paisaje.", lx, yy, colw, 15, INK2)
        for j in order:
            if yy + 30 > bottom_limit:
                break
            p = w.plants[j]
            ic = self.flower_icon(j)
            scr.blit(ic, ic.get_rect(center=(lx + 10, yy + 10)))
            self.put(p.name.split(" (")[0], lx + 26, yy, 15, INK)
            bar = pygame.Rect(lx + 26, yy + 22, colw - 76, 4)
            pygame.draw.rect(scr, RULE, bar, border_radius=2)
            pygame.draw.rect(scr, shade(p.color, .85), (bar.x, bar.y, max(3, bar.w * float(w.bloom[j])), bar.h),
                             border_radius=2)
            self.put(f"{num(w.bloom[j] * 100)} %", lx + colw, yy + 14, 14, INK2, anchor="topright")
            yy += 34
        d = hist[-1] if hist else None
        yy = top2
        if d:
            stats = [(f"{num(d['visitas_nativas_pct'], 1)} %", "de las visitas, por abejas nativas")]
            if any(SPECIES[c.sp].key == "dahlbomii" for c in w.colonies):
                stats.append((f"{num(d['dahlbomii_infeccion_media'] * 100)} %", "de infección en abejorro colorado"))
            if any(SPECIES[c.sp].kind == "bumble" for c in w.colonies):
                stats.append((num(d["dahlbomii_nuevas_reinas"] + d["terrestris_nuevas_reinas"]),
                              "nuevas reinas de abejorro"))
            stats.append((num(d["solitaria_celdas"]), "celdas de cría de abejas solitarias"))
            for val, lab in stats:
                if yy + 26 > bottom_limit:
                    break
                r = self.put(val, rx, yy, 20, INK, bold=True)
                lx2 = max(r.right + 10, rx + 72)
                yy = self.wrap(lab, lx2, yy + 5, xr - lx2, 14, INK2) + 12
        else:
            self.wrap("Los datos aparecen al terminar el primer día.", rx, yy, colw, 15, INK2)

        fy = WIN_H - 92
        pygame.draw.line(scr, RULE, (x0, fy - 12), (xr, fy - 12))
        keys = [("Espacio", "pausa"), ("ARROWS", f"velocidad ×{self.speed}"), ("D", "saltar día"),
                ("H", "visitas"), ("R", "ver todo"), ("F", "pantalla completa"), ("S", "captura")]
        kx, ky = x0, fy
        for k, lab in keys:
            lw = font(14).size(lab)[0]
            kw = 34 if k == "ARROWS" else font(14, True).size(k)[0] + 14
            if kx + kw + 7 + lw > xr:
                kx, ky = x0, ky + 30
            kr = pygame.Rect(kx, ky, kw, 24)
            pygame.draw.rect(scr, (250, 251, 246), kr, border_radius=5)
            pygame.draw.rect(scr, RULE, kr, 1, border_radius=5)
            if k == "ARROWS":
                ax_, ay_ = kr.x + 10, kr.centery
                pygame.draw.polygon(scr, INK, [(ax_ - 4, ay_ + 3), (ax_ + 4, ay_ + 3), (ax_, ay_ - 4)])
                ax_ += 14
                pygame.draw.polygon(scr, INK, [(ax_ - 4, ay_ - 3), (ax_ + 4, ay_ - 3), (ax_, ay_ + 4)])
            else:
                scr.blit(self.text(k, 14, INK, bold=True), (kx + 7, ky + 3))
            kx = self.put(lab, kr.right + 7, ky + 3, 14, INK2).right + 16
        self.put(f"Rueda para acercar (hasta {num(CELL_M / MAX_S, 1)} m por píxel), arrastra para moverte, "
                 "clic en el minimapa para saltar.", x0, ky + 32, 13, INK2)

    # -------------------------------------------------------------------- loop
    def handle(self, ev):
        if ev.type == pygame.QUIT:
            return False
        if ev.type == pygame.KEYDOWN:
            k = ev.key
            if k in (pygame.K_ESCAPE, pygame.K_q):
                return False
            if k == pygame.K_SPACE:
                self.paused = not self.paused
            elif k == pygame.K_UP:
                self.speed = min(400, max(self.speed + 1, int(self.speed * 1.6)))
            elif k == pygame.K_DOWN:
                self.speed = max(1, int(self.speed / 1.6))
            elif k == pygame.K_d:
                self.pill("Avanzando un día…", 24, MAP - 80)
                pygame.display.flip()
                self.w.run_day_fast()
                self.trail.fill((0, 0, 0, 0))
                self.px[:], self.py[:] = self.w.x, self.w.y
            elif k == pygame.K_h:
                self.heatmap = not self.heatmap
                self.overlay = None
            elif k == pygame.K_r:
                self.s, self.cx, self.cy = self.min_s, 0, 0
                self.camera_changed()
            elif k == pygame.K_f:
                pygame.display.toggle_fullscreen()
            elif k in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                self.zoom_at(MAP / 2, MAP / 2, 1.35)
            elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
                self.zoom_at(MAP / 2, MAP / 2, 1 / 1.35)
            elif k == pygame.K_s:
                self.screenshot()
        elif ev.type == pygame.MOUSEWHEEL:
            mx, my = pygame.mouse.get_pos()
            if mx < MAP:
                self.zoom_at(mx, my, 1.18 ** ev.y)
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1 and ev.pos[0] < MAP:
            r = self.minimap_rect()
            if self.s > self.min_s * 1.05 and r.collidepoint(ev.pos):
                k = self.G / MINI
                self.center_on((ev.pos[0] - r.x) * k, (ev.pos[1] - r.y) * k)
            else:
                self.dragging = True
        elif ev.type == pygame.MOUSEBUTTONUP and ev.button == 1:
            self.dragging = False
        elif ev.type == pygame.MOUSEMOTION and self.dragging:
            self.cx -= ev.rel[0] / self.s
            self.cy -= ev.rel[1] / self.s
            self.clamp_camera()
            self.camera_changed()
        return True

    def render(self):
        scr = self.screen
        self.compose_view()
        scr.blit(self.view_img, (0, 0))
        self.draw_overlay()
        self.draw_clouds()
        self.draw_nests()
        self.draw_bees()
        self.light()
        self.draw_rain()
        scr.blit(self.vignette, (0, 0))
        self.map_furniture()
        self.draw_panel()
        self.tooltip()
        pygame.display.flip()

    def run(self):
        w = self.w
        running = True
        while running and not w.finished:
            for ev in pygame.event.get():
                running = self.handle(ev) and running
            if not self.paused:
                for _ in range(self.speed):
                    self.ticks += 1
                    if not w.step():
                        self.trail.fill((0, 0, 0, 0))
                        self.px[:], self.py[:] = w.x, w.y
                        break
                    if w.finished:
                        break
            if w.finished:
                break
            self.frame += 1
            self.render()
            self.clock.tick(30)
        self.screenshot("mapa_final.png")
        pygame.quit()

    def screenshot(self, name=None):
        if self.out_dir is None:
            return
        self.out_dir.mkdir(parents=True, exist_ok=True)
        name = name or f"captura_dia{self.w.day_index + 1:03d}.png"
        pygame.image.save(self.screen, str(self.out_dir / name))
