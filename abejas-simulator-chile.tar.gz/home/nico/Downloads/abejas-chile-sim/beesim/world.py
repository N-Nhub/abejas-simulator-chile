"""The simulated landscape and its bees.

Space: square grid of 20 m cells; 3, 6 or 12 km across (150, 300 or 600 cells).
Time:  2-minute ticks during daylight; colony dynamics update once per day.
Bees:  each dot is an agent standing for one or more real foragers (`rep`),
       sitting on top of colony-level population models.
See README.md for the full model description and references.
"""
from dataclasses import dataclass
import datetime as dt
import math

import numpy as np

from .climate import ZONES, Weather
from .flora import PLANTS, HABITATS, bloom_intensity, in_window, APR, MAY
from .bees import SPECIES, SP_INDEX, PRESENCE, flight_prob
from .brain import FeedingCircuit, MushroomBody

G = 150                 # default grid size (cells) — kept for the classic viewer
CELL_M = 20             # metres per cell
TICK_H = 2 / 60         # hours per tick
CELL_CAP = 400.0        # nectar loads a fully blooming cell can hold
REFILL_TICKS = 90       # ~3 h to refill an emptied cell at peak secretion
HANDLE = 0.08           # fraction of a bee's capacity gathered per tick on flowers
DEPOSIT = 0.3           # fraction of body pollen left on the next flowers (carry-over)
FRUIT_K = 40.0          # conspecific pollen units per cell for ~63 % pollination

HOME, SEARCH, FORAGE, RETURN, GOTO = 0, 1, 2, 3, 4
MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]

# Khoury et al. (2011, 2013) honeybee colony model parameters (our units: 1 food unit = 1 load)
KH = dict(w=27000.0, alpha_min=0.25, alpha_max=0.25, sigma=0.75, b=6000.0,
          tau=21.0, m_hive=0.006, m_forager=0.13, g_adult=0.8, g_brood=1.2, b_lay=3000.0)


def doy_to_str(doy):
    d = dt.date(2025, 1, 1) + dt.timedelta(days=doy - 1)
    return f"{d.day:02d}-{MONTHS[d.month - 1]}"


@dataclass
class Scenario:
    zone: str = "biobio_costa"
    habitat: str = "nativo"
    year: str = "normal"
    hives: int = 4                    # managed hives per 9 km²
    pesticide: str = "ninguno"        # ninguno | moderado | alto
    nesting: str = "medio"            # bajo | medio | alto  (bee hotels + ground)
    terrestris: str = "auto"          # auto | ausente | presente
    flower_strips: bool = False
    start_doy: int = 213              # 1 Aug
    days: int = 240
    seed: int = 7
    size_km: int = 3                  # 3, 6 or 12


@dataclass
class Colony:
    cid: int
    sp: int
    x: float
    y: float
    W: float = 0.0          # foragers / workers (real bees)
    H: float = 0.0          # honeybee hive bees (nurses etc.)
    B: float = 0.0          # brood
    S: float = 0.0          # nectar stores (loads)
    Pn: float = 0.0         # pollen stores
    active: bool = False
    alive: bool = True
    infection: float = 0.0
    carrier: bool = False
    pest: float = 0.0
    new_queens: float = 0.0
    cells: float = 0.0      # solitary brood cells provisioned
    honey: float = 0.0      # honeybee surplus above the brood-nest store cap
    hotel: bool = False
    slot0: int = 0
    nslots: int = 0
    max_dots: int = 1
    gathered_today: float = 0.0


def jittered_voronoi(G, block, probs, rng, edge_jitter=1.2):
    """Label every cell by its nearest seed; one seed per `block`-sized square.
    Linear in map size, so it scales to 600 x 600 cells easily."""
    nb = int(math.ceil(G / block)) + 1
    sx = (np.arange(nb)[None, :] + rng.random((nb, nb))) * block
    sy = (np.arange(nb)[:, None] + rng.random((nb, nb))) * block
    lab = rng.choice(len(probs), (nb, nb), p=probs)
    yy, xx = np.mgrid[0:G, 0:G].astype(np.float32)
    xx += .5 + rng.normal(0, edge_jitter, xx.shape).astype(np.float32)
    yy += .5 + rng.normal(0, edge_jitter, yy.shape).astype(np.float32)
    bx = np.clip((xx // block).astype(int), 0, nb - 1)
    by = np.clip((yy // block).astype(int), 0, nb - 1)
    best = np.full((G, G), np.inf, np.float32)
    out = np.zeros((G, G), np.int32)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cy, cx = np.clip(by + dy, 0, nb - 1), np.clip(bx + dx, 0, nb - 1)
            d = (xx - sx[cy, cx]) ** 2 + (yy - sy[cy, cx]) ** 2
            m = d < best
            best[m] = d[m]
            out[m] = lab[cy, cx][m]
    return out


class World:
    def __init__(self, sc: Scenario):
        self.sc = sc
        self.G = int(sc.size_km * 1000 / CELL_M)
        self.area = (sc.size_km / 3.0) ** 2           # in units of the 3 x 3 km base map
        self.rng = np.random.default_rng(sc.seed)
        self.zone = ZONES[sc.zone]
        self.habitat = next(h for h in HABITATS[sc.zone] if h.key == sc.habitat)
        self.weather = Weather(self.zone, sc.year, self.rng)
        self.plant_keys = list(PLANTS)
        self.plants = [PLANTS[k] for k in self.plant_keys]
        self.NP = len(self.plants)
        self._plant_arrays()
        self._build_landscape()
        self._place_colonies()
        self._alloc_agents()
        self.feeding = FeedingCircuit()
        self.mb = MushroomBody(self.plant_keys, self.N, self.rng)
        self.visits = np.zeros((self.NP, len(SPECIES)))
        self.visits_today = np.zeros((self.NP, len(SPECIES)))
        self.pollen_cons = np.zeros(len(SPECIES))     # conspecific pollen delivered
        self.pollen_het = np.zeros(len(SPECIES))      # pollen wasted on other species
        self.daily = []
        self.day_index = 0
        self.doy = sc.start_doy
        self.lost_bees = np.zeros(len(SPECIES))
        self.temp_now, self.rain_now, self.wind_now, self.cloud_now = 10.0, False, 0.0, 0.0
        self.fly_p = np.zeros(len(SPECIES))
        d = MAY                    # spin up weather so soil moisture / desert rain are realistic
        while d != sc.start_doy:
            self.weather.new_day(d)
            d = d % 365 + 1
        self._start_day()

    # ------------------------------------------------------------------ setup
    def _plant_arrays(self):
        p = self.plants
        self.p_nectar = np.array([x.nectar for x in p], np.float32)
        self.p_sugar = np.array([min(x.sugar / 0.45, 1) for x in p], np.float32)
        self.p_pollen = np.array([x.pollen for x in p], np.float32)
        self.p_crop = np.array([x.crop for x in p])
        self.p_native = np.array([x.native for x in p])
        self.p_buzz = np.array([x.buzz for x in p])
        self.p_irrig = np.array([x.irrigated for x in p])
        corolla = np.array([x.corolla for x in p], np.float32)
        tongue = np.array([s.tongue for s in SPECIES], np.float32)
        self.access = np.clip(1 - np.maximum(corolla[None, :] - tongue[:, None], 0) / 4, .05, 1)
        self.s_speed = np.array([s.speed for s in SPECIES], np.float32)
        self.s_range = np.array([s.range_cells for s in SPECIES], np.float32)
        self.s_cap = np.array([s.capacity for s in SPECIES], np.float32)
        self.s_poll = np.array([s.poll_eff for s in SPECIES], np.float32)
        self.s_buzz = np.array([s.buzz for s in SPECIES], np.float32)
        self.s_native = np.array([s.native for s in SPECIES])

    def _pid_for(self, hab, rng):
        """Plant map for one habitat preset over the whole grid."""
        G = self.G
        pid = np.full((G, G), -1, np.int16)
        idx = {k: i for i, k in enumerate(self.plant_keys)}
        mix = dict(hab.mix)
        for key in hab.fields:                       # rectangular orchards / fields / plantations
            target = mix.get(key, 0) * G * G
            placed, tries = 0, 0
            while placed < target and tries < 400 * self.area:
                tries += 1
                w, h = rng.integers(10, 34), rng.integers(8, 26)
                x0, y0 = rng.integers(0, G - w), rng.integers(0, G - h)
                block = pid[y0:y0 + h, x0:x0 + w]
                free = block == -1
                block[free] = idx[key]
                placed += int(free.sum())
        rest = {k: v for k, v in mix.items() if k not in hab.fields}
        labels = list(rest) + [None]
        w = np.array([rest[k] for k in rest] + [max(0.0, 1.0 - sum(mix.values()))], float)
        w = w / w.sum() if w.sum() > 0 else np.r_[np.zeros(len(rest)), 1.0]
        lab = jittered_voronoi(G, 5.7, w, rng)
        free = pid == -1
        for j, k in enumerate(labels):
            if k is not None:
                pid[free & (lab == j)] = idx[k]
        return pid

    def _build_landscape(self):
        rng, G = self.rng, self.G
        if self.habitat.key == "regional":
            # regional mosaic: ~1.2 km patches, each one of the zone's environments
            habs = [h for h in HABITATS[self.sc.zone] if h.key != "regional"]
            region = jittered_voronoi(G, 60, np.ones(len(habs)) / len(habs), rng, edge_jitter=4)
            pid = np.full((G, G), -1, np.int16)
            for i, h in enumerate(habs):
                m = region == i
                if m.any():
                    pid[m] = self._pid_for(h, rng)[m]
            self.region = region
            self.region_names = [h.name for h in habs]
        else:
            pid = self._pid_for(self.habitat, rng)
            self.region = None
        idx = {k: i for i, k in enumerate(self.plant_keys)}
        if self.sc.flower_strips:                  # native flower strips (~4 %)
            target, placed = 0.04 * G * G, 0
            while placed < target:
                L = rng.integers(25, 60)
                if rng.random() < .5:
                    y, x0 = rng.integers(0, G - 2), rng.integers(0, G - 60)
                    seg = pid[y:y + 2, x0:x0 + L]
                else:
                    x, y0 = rng.integers(0, G - 2), rng.integers(0, G - 60)
                    seg = pid[y0:y0 + L, x:x + 2]
                ok = seg != idx["pino"]
                seg[ok] = idx["franja"]
                placed += int(ok.sum())
        self.pid = pid
        self.flat_pid = pid.ravel()
        self.present_plants = np.unique(self.flat_pid[self.flat_pid >= 0]).astype(np.int64)
        n = G * G
        self.nectar = np.zeros(n, np.float32)
        self.cap = np.zeros(n, np.float32)
        self.regen = np.zeros(n, np.float32)
        self.path = np.zeros(n, np.float32)        # Crithidia/Apicystis-like parasite on flowers
        self.pest = np.zeros(n, np.float32)        # pesticide residue on flowers
        self.poll_cell = np.zeros(n, np.float32)   # conspecific pollen received (season)
        self.heat = np.zeros(n, np.float32)        # visit heat map (decays daily)
        self.bloom = np.zeros(self.NP, np.float32)

    def _rand_cell(self, pred=None, near=None, spread=6):
        G = self.G
        for _ in range(500):
            if near is not None:
                x, y = np.clip(near + self.rng.normal(0, spread, 2), 1, G - 2)
            else:
                x, y = self.rng.uniform(2, G - 2, 2)
            if pred is None or pred(int(y), int(x)):
                return float(x), float(y)
        return float(G / 2), float(G / 2)

    def _place_colonies(self):
        sc, rng, A = self.sc, self.rng, self.area
        pres = PRESENCE[sc.zone]
        cols = []
        pine = self.plant_keys.index("pino")
        not_pine = lambda y, x: self.pid[y, x] != pine
        dot_div = math.sqrt(A)
        # managed honeybees: one apiary per 9 km², sc.hives hives each
        if sc.hives > 0:
            for _ in range(max(1, int(round(A)))):
                apiary = np.array(self._rand_cell(not_pine))
                for _ in range(sc.hives):
                    x, y = self._rand_cell(not_pine, near=apiary, spread=2)
                    c = Colony(len(cols), SP_INDEX["apis"], x, y, W=4000, H=9000, B=6000,
                               S=8000, Pn=1500, active=True,
                               honey=500000)           # ~5 kg of honey left after winter
                    c.max_dots = max(20, int(120 / dot_div))
                    cols.append(c)
        tp = pres["terrestris"]
        if sc.terrestris == "ausente":
            tp = 0.0
        elif sc.terrestris == "presente":
            tp = max(tp, 1.0)
        for key, p in (("dahlbomii", pres["dahlbomii"]), ("terrestris", tp)):
            n = int(round(9 * p * A + rng.normal(0, .8 * math.sqrt(A)))) if p > 0 else 0
            for _ in range(max(n, 0)):
                x, y = self._rand_cell(not_pine)
                c = Colony(len(cols), SP_INDEX[key], x, y)
                c.carrier = SPECIES[c.sp].pathogen_carrier and rng.random() < .7
                c.max_dots = max(8, int(40 / dot_div))
                cols.append(c)
        ground = {"bajo": 25, "medio": 45, "alto": 60}[sc.nesting]
        hotels = {"bajo": 0, "medio": 1, "alto": 3}[sc.nesting]
        nest_ok = set(self.plant_keys.index(k) for k in ("yuyo", "maleza", "litre", "quillay", "franja",
                                                          "pata_guanaco", "suspiro", "chanar"))
        for _ in range(int(ground * pres["solitaria"] * A)):
            x, y = self._rand_cell(lambda y, x: self.pid[y, x] == -1 or int(self.pid[y, x]) in nest_ok)
            cols.append(Colony(len(cols), SP_INDEX["solitaria"], x, y))
        self.hotel_sites = []
        for _ in range(int(round(hotels * A))):
            site = np.array(self._rand_cell(not_pine))
            self.hotel_sites.append(site)
            for _ in range(int(20 * max(pres["solitaria"], .5))):
                x, y = np.clip(site + rng.normal(0, .3, 2), 0, self.G - 1)
                cols.append(Colony(len(cols), SP_INDEX["solitaria"], float(x), float(y), hotel=True))
        self.colonies = cols

    def _alloc_agents(self):
        s0 = 0
        for c in self.colonies:
            c.slot0, c.nslots = s0, c.max_dots
            s0 += c.nslots
        N = self.N = max(s0, 1)
        self.on = np.zeros(N, bool)
        self.col = np.zeros(N, np.int32)
        for c in self.colonies:
            self.col[c.slot0:c.slot0 + c.nslots] = c.cid
        if self.colonies:
            self.sp = np.array([self.colonies[i].sp for i in self.col], np.int32)
            self.nest_x = np.array([self.colonies[i].x for i in self.col], np.float32)
            self.nest_y = np.array([self.colonies[i].y for i in self.col], np.float32)
        else:
            self.sp = np.zeros(N, np.int32)
            self.nest_x = self.nest_y = np.full(N, self.G / 2, np.float32)
        self.x = self.nest_x.copy()
        self.y = self.nest_y.copy()
        self.state = np.zeros(N, np.int8)
        self.load = np.zeros(N, np.float32)
        self.pload = np.zeros(N, np.float32)
        self.qual = np.zeros(N, np.float32)
        self.tx = np.zeros(N, np.float32)
        self.ty = np.zeros(N, np.float32)
        self.memx = np.zeros(N, np.float32)
        self.memy = np.zeros(N, np.float32)
        self.memok = np.zeros(N, bool)
        self.timer = np.zeros(N, np.int32)
        self.search_t = np.zeros(N, np.int32)
        self.heading = self.rng.uniform(0, 2 * np.pi, N).astype(np.float32)
        self.rep = np.ones(N, np.float32)
        self.pol_sp = np.full(N, -1, np.int16)      # plant species of the pollen on the body
        self.pol_amt = np.zeros(N, np.float32)
        self.c_sp = np.array([c.sp for c in self.colonies], np.int32)

    # ------------------------------------------------------------- day cycle
    def _start_day(self):
        wx = self.weather.new_day(self.doy)
        self.today = wx
        self.sunrise = 12 - wx["daylen"] / 2
        self.sunset = 12 + wx["daylen"] / 2
        self.hour = self.sunrise
        for j, p in enumerate(self.plants):
            self.bloom[j] = bloom_intensity(p, self.doy, self.weather.soil, self.weather.winter_rain)
        valid = self.flat_pid >= 0
        pidv = self.flat_pid[valid]
        self.cap[:] = 0
        self.cap[valid] = self.p_nectar[pidv] * self.bloom[pidv] * CELL_CAP
        self.regen = self.cap / REFILL_TICKS
        self.nectar = np.minimum(self.nectar + self.cap * .5, self.cap)
        lvl = {"ninguno": 0, "moderado": .4, "alto": 1.0}[self.sc.pesticide]
        self.pest[:] = 0
        if lvl:
            crop = valid.copy()
            crop[valid] = self.p_crop[pidv] & (self.bloom[pidv] > .05)
            self.pest[crop] = lvl
        self._colony_activation()
        self.visits_today[:] = 0
        for c in self.colonies:
            c.gathered_today = 0.0

    def _colony_activation(self):
        doy = self.doy
        for c in self.colonies:
            s = SPECIES[c.sp]
            if not c.alive:
                c.active = False
            elif s.kind == "bumble":
                if not c.active and in_window(doy, s.emerge_doy, APR) and c.W == 0 and c.new_queens == 0:
                    if self.today["tmax"] > s.t50 + 4 and self.rng.random() < .12:
                        c.active, c.W, c.S = True, 1.0, 20.0      # queen leaves hibernation
                if c.active and in_window(doy, APR + 15, MAY + 30):
                    c.active, c.alive = False, False              # annual colony dies off
            elif s.kind == "solitary":
                if in_window(doy, s.emerge_doy, s.season_end_doy):
                    if not c.active and c.W == 0 and c.cells == 0 and self.rng.random() < .06:
                        c.active, c.W = True, 1.0
                elif c.active:
                    c.active, c.alive = False, False
            want = 0
            if c.active and c.W >= 1:
                want = int(min(c.max_dots, max(1, math.ceil(c.W / s.scale))))
            sl = slice(c.slot0, c.slot0 + c.nslots)
            prev = self.on[sl].copy()
            now = np.zeros(c.nslots, bool)
            now[:want] = True
            newly = np.flatnonzero(now & ~prev) + c.slot0
            if len(newly):
                self.mb.reset_agents(newly)                       # naive new foragers
                self.memok[newly] = False
            self.on[sl] = now
            self.rep[sl] = c.W / want if want else 1.0
        nc = len(self.colonies)
        self.col_S = np.array([c.S for c in self.colonies], np.float32)
        self.col_pest = np.array([c.pest for c in self.colonies], np.float32)
        self.col_carrier = np.array([c.carrier for c in self.colonies], bool)
        self.col_expo, self.col_nvis = np.zeros(nc), np.zeros(nc)
        self.col_pexpo, self.col_pvis = np.zeros(nc), np.zeros(nc)
        home = self.on
        self.state[home] = HOME
        self.x[home] = self.nest_x[home]
        self.y[home] = self.nest_y[home]
        self.load[:] = 0
        self.pload[:] = 0
        self.pol_amt[:] = 0
        self.pol_sp[:] = -1
        self.timer[home] = self.rng.integers(0, 40, int(home.sum()))

    def _honeybee_day(self, c, wx):
        """Khoury et al. (2011, 2013): brood B, hive bees H, foragers F (=W), food S."""
        k = KH
        season = min(max((wx["daylen"] - 9.8) / 3.0, 0.15), 1.0)
        cold = 1 + max(0, 12 - wx["tmean"]) * 0.06
        H, F, B, S = c.H, c.W, c.B, c.S
        lay = SPECIES[c.sp].lay_max * season * S / (S + k["b_lay"]) * min(1, c.Pn / 300)
        new_brood = lay * (H + F) / (k["w"] + H + F)          # brood survival needs nurses
        emerge = B / k["tau"]
        R = max(0.0, k["alpha_min"] + k["alpha_max"] * k["b"] ** 2 / (k["b"] ** 2 + S ** 2)
                - k["sigma"] * F / max(H + F, 1))             # recruitment to foraging
        m_f = k["m_forager"] * (0.4 + 0.6 * season) + 0.05 * c.pest
        c.B = B + new_brood - emerge
        c.H = max(0.0, H + emerge - H * R - k["m_hive"] * H)
        c.W = max(0.0, F + H * R - m_f * F)
        c.Pn = max(0.0, c.Pn - lay * 0.12)
        # clustered winter bees burn less than active summer bees
        c.S = S - (k["g_adult"] * (H + F) * cold * (0.45 + 0.55 * season) + k["g_brood"] * B)
        if c.S < 20000 and c.honey > 0:                        # dearth: eat stored honey
            draw = min(c.honey, 20000 - c.S)
            c.honey -= draw
            c.S += draw
        if c.S < 0:                                            # starvation
            c.S, c.B, c.H, c.W = 0.0, c.B * .6, c.H * .9, c.W * .9
        if c.S > 60000:                                        # surplus goes to honey supers
            c.honey += c.S - 60000
            c.S = 60000
        if c.W + c.H < 500:
            c.alive = c.active = False

    def _end_day(self):
        wx = self.today
        rng = self.rng
        tmean = wx["tmean"]
        for c in self.colonies:
            s = SPECIES[c.sp]
            if not c.alive or not c.active:
                continue
            c.pest = min(1.0, 0.8 * c.pest + 0.5 * self.col_pexpo[c.cid] / max(self.col_pvis[c.cid], 1.0))
            if s.kind == "solitary":
                if rng.random() < s.mort + 0.02 * c.pest:
                    c.W, c.active, c.alive = 0, False, False
                continue
            if s.kind == "apis":
                self._honeybee_day(c, wx)
                continue
            # bumblebee colony (simplified after Becher et al. 2018, Bumble-BEEHAVE)
            cold = 1 + max(0, 12 - tmean) * 0.06
            c.S -= c.W * s.c_worker * cold + c.B * s.c_brood
            repro = in_window(self.doy, s.repro_doy, APR + 15)
            lay = 0 if repro else s.lay_max * min(1, c.Pn / (s.pollen_per_brood * 3)) * min(1, c.S / 30)
            lay = max(0.0, lay * (1 - 0.6 * c.infection))
            if repro and c.S > 120:
                q = min((c.S - 120) / 160.0, 0.012 * c.W)
                c.new_queens += q * (1 - 0.7 * c.infection) * (1 - 0.5 * c.pest)
                c.S -= q * 160
            c.Pn = max(0.0, c.Pn - lay * s.pollen_per_brood)
            c.B += lay
            matured = c.B / s.dev_days
            c.B -= matured
            c.W += matured
            c.W *= (1 - (s.mort + 0.04 * c.pest + 0.03 * c.infection))
            if c.S < 0:
                c.S, c.W, c.B = 0.0, c.W * .85, c.B * .7
            if s.pathogen_susceptible:
                expo = self.col_expo[c.cid] / max(self.col_nvis[c.cid], 1.0)
                c.infection = min(1.0, c.infection + (0.04 * expo + 0.012 * c.infection) * (1 - c.infection))
                if c.infection > .9 and rng.random() < .02:
                    c.alive = False
            if c.W < 0.5 and c.B < 1:
                c.alive, c.active = False, False
        self.mb.daily_forgetting()
        self.heat *= 0.6
        self.visits += self.visits_today
        self._record_day()

    def _record_day(self):
        wx = self.today
        row = dict(day=self.day_index, doy=self.doy, date=doy_to_str(self.doy),
                   tmin=round(wx["tmin"], 1), tmax=round(wx["tmax"], 1),
                   rain_mm=round(wx["mm"], 1), soil=round(self.weather.soil, 2),
                   wind_ms=round(wx["wind"], 1), nubes=round(wx["cloud"], 2))
        for i, s in enumerate(SPECIES):
            cs = [c for c in self.colonies if c.sp == i]
            row[f"{s.key}_colonias"] = sum(c.active for c in cs)
            row[f"{s.key}_obreras"] = round(sum(c.W for c in cs if c.active), 1)
            row[f"{s.key}_visitas"] = round(float(self.visits_today[:, i].sum()), 1)
        apis = [c for c in self.colonies if SPECIES[c.sp].kind == "apis"]
        row["apis_reservas_media"] = round(float(np.mean([c.S for c in apis])), 1) if apis else 0
        row["apis_abejas_internas"] = round(sum(c.H for c in apis), 1)
        dahl = [c for c in self.colonies if SPECIES[c.sp].key == "dahlbomii" and c.alive]
        row["dahlbomii_infeccion_media"] = round(float(np.mean([c.infection for c in dahl])), 3) if dahl else 0
        for key in ("dahlbomii", "terrestris"):
            row[f"{key}_nuevas_reinas"] = round(sum(c.new_queens for c in self.colonies
                                                    if SPECIES[c.sp].key == key), 1)
        row["solitaria_celdas"] = round(sum(c.cells for c in self.colonies
                                            if SPECIES[c.sp].kind == "solitary"), 1)
        nat = self.visits_today[:, self.s_native].sum()
        row["visitas_nativas_pct"] = round(100 * nat / max(self.visits_today.sum(), 1e-9), 1)
        row["plantas_en_flor"] = int((self.bloom[self.present_plants] > .05).sum())
        self.daily.append(row)

    @property
    def finished(self):
        return self.day_index >= self.sc.days

    def next_day(self):
        self._end_day()
        self.day_index += 1
        self.doy = self.doy % 365 + 1
        if not self.finished:
            self._start_day()

    # ------------------------------------------------------------------ tick
    def step(self):
        """Advance one 2-minute tick. Returns False when the day is over."""
        if self.hour >= self.sunset:
            self.next_day()
            return False
        rng, W = self.rng, self.weather
        hour = self.hour
        temp, raining = W.temp_at(hour), W.raining_at(hour)
        wind, cloud = W.wind_at(hour), W.cloud_at(hour)
        self.temp_now, self.rain_now, self.wind_now, self.cloud_now = temp, raining, wind, cloud
        self.fly_p = np.array([flight_prob(s, temp, wind, cloud, raining) for s in SPECIES])
        late = hour > self.sunset - 0.5
        on, sp = self.on, self.sp
        pf = self.fly_p[sp]
        spd = self.s_speed[sp]

        # weather / dusk: foragers outside head home when conditions turn bad
        out = on & ((self.state == SEARCH) | (self.state == FORAGE) | (self.state == GOTO))
        recall = out & ((pf < 0.15) | late)
        self.state[recall] = RETURN

        # leaving the nest is a per-tick gamble on the weather
        home = on & (self.state == HOME)
        self.timer[home] -= 1
        if not late:
            leave = home & (self.timer <= 0) & (rng.random(self.N) < pf)
            if leave.any():
                li = np.flatnonzero(leave)
                use_mem = self.memok[li] & (rng.random(len(li)) < .85)
                g = li[use_mem]
                self.state[g] = GOTO
                self.tx[g] = self.memx[g] + rng.normal(0, 1.5, len(g))
                self.ty[g] = self.memy[g] + rng.normal(0, 1.5, len(g))
                s_ = li[~use_mem]
                self.state[s_] = SEARCH
                self.heading[s_] = rng.uniform(0, 2 * np.pi, len(s_))
                self.search_t[li] = 0

        gi = np.flatnonzero(on & (self.state == GOTO))
        if len(gi):
            arrived = self._move_towards(gi, self.tx[gi], self.ty[gi], spd[gi] * 1.6)
            self.state[gi[arrived]] = SEARCH
        si = np.flatnonzero(on & (self.state == SEARCH))
        if len(si):
            self._search(si, spd[si])
        fi = np.flatnonzero(on & (self.state == FORAGE))
        if len(fi):
            self._forage(fi, first=False)
        ri = np.flatnonzero(on & (self.state == RETURN))
        if len(ri):
            arrived = self._move_towards(ri, self.nest_x[ri], self.nest_y[ri], spd[ri] * 1.8)
            if arrived.any():
                self._unload(ri[arrived])

        # nectar secretion: morning peak, slowed by cold
        diurnal = 0.45 + 1.1 * math.exp(-((hour - 10.0) / 3.2) ** 2)
        warm = min(max((temp - 4) / 14, 0.15), 1.2)
        self.nectar = np.minimum(self.nectar + self.regen * (diurnal * warm), self.cap)
        self.path *= 0.994
        self.hour += TICK_H
        return True

    # ------------------------------------------------------------- behaviours
    def _move_towards(self, idx, tx, ty, speed):
        dx, dy = tx - self.x[idx], ty - self.y[idx]
        d = np.hypot(dx, dy)
        arrived = d <= speed
        f = np.where(arrived, 1.0, speed / np.maximum(d, 1e-6))
        self.x[idx] += dx * f
        self.y[idx] += dy * f
        return arrived

    def _cell(self, x, y):
        G = self.G
        ix = np.clip(x.astype(np.int32), 0, G - 1)
        iy = np.clip(y.astype(np.int32), 0, G - 1)
        return iy * G + ix

    def _search(self, si, spd):
        rng, G = self.rng, self.G
        K, R = 8, 6.0
        ang = rng.uniform(0, 2 * np.pi, (len(si), K))
        rad = rng.uniform(1, R, (len(si), K))
        cx = np.clip(self.x[si, None] + np.cos(ang) * rad, 0, G - .01)
        cy = np.clip(self.y[si, None] + np.sin(ang) * rad, 0, G - .01)
        cells = self._cell(cx, cy)
        pidc = self.flat_pid[cells]
        valid = pidc >= 0
        pc = np.where(valid, pidc, 0)
        display = self.cap[cells] / CELL_CAP
        scent = self.nectar[cells] / CELL_CAP
        agents2 = np.repeat(si[:, None], K, 1)
        pref = self.mb.preference(agents2, pc)
        acc = self.access[self.sp[si][:, None], pc]
        # constancy bias: flowers matching the pollen already carried look more attractive
        const = 1 + 0.35 * (self.pol_sp[si][:, None] == pc)
        score = (0.7 * display + 0.3 * scent) * self.p_sugar[pc] * (0.25 + pref) * acc * const
        score = np.where(valid, score, 0) + rng.random(score.shape) * 0.01
        best = score.argmax(1)
        bscore = score[np.arange(len(si)), best]
        go = bscore > 0.03
        gi = si[go]
        self.x[gi] = cx[go, best[go]]
        self.y[gi] = cy[go, best[go]]
        wi = si[~go]
        if len(wi):
            h = self.heading[wi] + rng.normal(0, .6, len(wi))
            dxn, dyn = self.nest_x[wi] - self.x[wi], self.nest_y[wi] - self.y[wi]
            far = np.hypot(dxn, dyn) > self.s_range[self.sp[wi]]
            h = np.where(far, np.arctan2(dyn, dxn) + rng.normal(0, .4, len(wi)), h)
            step = spd[~go]
            nx, ny = self.x[wi] + np.cos(h) * step, self.y[wi] + np.sin(h) * step
            bounce = (nx < 0) | (nx >= G) | (ny < 0) | (ny >= G)
            h = np.where(bounce, h + np.pi, h)
            self.x[wi] = np.clip(nx, 0, G - .01)
            self.y[wi] = np.clip(ny, 0, G - .01)
            self.heading[wi] = h
        self.search_t[si] += 1
        if len(gi):
            self._forage(gi, first=True)
        tired = si[(self.search_t[si] > 40) & (self.state[si] == SEARCH)]
        if len(tired):
            self.state[tired] = RETURN
            self.memok[tired] = False

    def _forage(self, ai, first):
        rng, G = self.rng, self.G
        cells = self._cell(self.x[ai], self.y[ai])
        pidc = self.flat_pid[cells]
        ok = pidc >= 0
        ai, cells, pidc = ai[ok], cells[ok], pidc[ok]
        if not len(ai):
            return
        sp = self.sp[ai]
        rep = self.rep[ai]
        col = self.col[ai]
        cap_bee = self.s_cap[sp]
        avail = np.clip(self.nectar[cells] / (CELL_CAP * 0.15), 0, 1)
        sugar = self.p_sugar[pidc] * avail * self.access[sp, pidc]
        hunger = np.clip(1 - self.col_S[col] / np.where(sp == SP_INDEX["apis"], 20000, 200), 0, 1)
        hunger = np.where(sp == SP_INDEX["solitaria"], 0.8, hunger)
        p_acc = self.feeding.accept_prob(sugar, hunger)
        accept = rng.random(len(ai)) < p_acc
        lr = 0.25 * (1 - 0.7 * self.col_pest[col])

        take = np.minimum(cap_bee * HANDLE * avail, cap_bee - self.load[ai])
        take = np.minimum(take, self.nectar[cells] / np.maximum(rep, 1))
        take = np.where(accept, np.maximum(take, 0), 0)
        np.subtract.at(self.nectar, cells, take * rep)
        np.maximum(self.nectar, 0, out=self.nectar)
        self.load[ai] += take
        self.pload[ai] += take * self.p_pollen[pidc]
        q = self.p_sugar[pidc] * self.access[sp, pidc]
        self.qual[ai] = np.where(accept, 0.7 * self.qual[ai] + 0.3 * q, self.qual[ai])

        reward = np.where(accept, np.clip(take / (cap_bee * HANDLE), 0, 1) * q, 0)
        punish = np.where(accept, 0, 0.6) + np.where(accept & (take < cap_bee * HANDLE * 0.2), 0.3, 0)
        full_now = self.load[ai] >= cap_bee * 0.95
        lm = (np.full(len(ai), first) | ~accept | (avail < 0.15) | full_now | (rng.random(len(ai)) < 0.2))
        self.mb.learn(ai[lm], pidc[lm].astype(np.int64), reward[lm].astype(np.float32),
                      punish[lm].astype(np.float32), lr[lm].astype(np.float32))

        acc_i = np.flatnonzero(accept)
        if len(acc_i):
            a, a_sp, a_p = ai[acc_i], sp[acc_i], pidc[acc_i]
            a_rep, a_cells, a_col = rep[acc_i], cells[acc_i], col[acc_i]
            np.add.at(self.visits_today, (a_p, a_sp), a_rep)
            np.add.at(self.heat, a_cells, a_rep)
            # pollen transfer: only pollen of the same plant species pollinates
            same = self.pol_sp[a] == a_p
            dep = self.pol_amt[a] * DEPOSIT
            eff = self.s_poll[a_sp] * np.where(self.p_buzz[a_p], self.s_buzz[a_sp], 1.0)
            cons = np.where(same, dep * eff, 0) * a_rep
            np.add.at(self.poll_cell, a_cells, cons)
            np.add.at(self.pollen_cons, a_sp, cons)
            np.add.at(self.pollen_het, a_sp, np.where(same, 0, dep) * a_rep)
            carried = self.pol_amt[a] * (1 - DEPOSIT) * np.where(same, 1.0, 0.4)
            self.pol_amt[a] = carried + 0.5 * self.p_pollen[a_p] * self.access[a_sp, a_p]
            self.pol_sp[a] = a_p
            # parasites: carriers contaminate flowers, susceptible colonies pick up
            carrier = self.col_carrier[a_col]
            np.add.at(self.path, a_cells[carrier], 0.25)
            np.minimum(self.path, 1.0, out=self.path)
            susc = a_sp == SP_INDEX["dahlbomii"]
            if susc.any():
                np.add.at(self.col_expo, a_col[susc], self.path[a_cells[susc]])
                np.add.at(self.col_nvis, a_col[susc], 1.0)
            np.add.at(self.col_pexpo, a_col, self.pest[a_cells])
            np.add.at(self.col_pvis, a_col, 1.0)

        self.state[ai[accept]] = FORAGE
        if first:
            self.search_t[ai[accept]] = 0
        full = accept & (self.load[ai] >= cap_bee * 0.95)
        fi = ai[full]
        self.state[fi] = RETURN
        good = self.qual[fi] > 0.35
        self.memx[fi] = np.where(good, self.x[fi], self.memx[fi])
        self.memy[fi] = np.where(good, self.y[fi], self.memy[fi])
        self.memok[fi] = good | self.memok[fi]
        if not first:
            dry = ~accept | ((avail < 0.15) & ~full)
            di = ai[dry]
            self.state[di] = SEARCH
            hop = rng.normal(0, 1.5, (len(di), 2))
            self.x[di] = np.clip(self.x[di] + hop[:, 0], 0, G - .01)
            self.y[di] = np.clip(self.y[di] + hop[:, 1], 0, G - .01)
        else:
            self.state[ai[~accept]] = SEARCH

    def _unload(self, ui):
        rng = self.rng
        for a in ui:
            c = self.colonies[self.col[a]]
            s = SPECIES[c.sp]
            if c.pest > 0 and rng.random() < c.pest * 0.01:      # homing failure
                c.W = max(0.0, c.W - self.rep[a])
                self.lost_bees[c.sp] += self.rep[a]
                self.on[a] = False
                continue
            got = float(self.load[a] * self.rep[a])
            pol = float(self.pload[a] * self.rep[a])
            c.gathered_today += got
            if s.kind == "solitary":
                c.cells += pol / s.pollen_per_brood
            else:
                c.S += got
                c.Pn += pol
            # honeybee recruitment ("waggle dance"): better patches recruit more
            if s.kind == "apis" and self.qual[a] > 0.45 and self.memok[a]:
                sl = np.arange(c.slot0, c.slot0 + c.nslots)
                idle = sl[self.on[sl] & (self.state[sl] == HOME) & ~self.memok[sl]]
                n = int(round(4 * (self.qual[a] - 0.4) / 0.6))
                if len(idle) and n > 0:
                    r = rng.choice(idle, min(n, len(idle)), replace=False)
                    self.memx[r], self.memy[r], self.memok[r] = self.memx[a], self.memy[a], True
                    self.timer[r] = np.minimum(self.timer[r], 2)
        alive = ui[self.on[ui]]
        self.load[alive] = 0
        self.pload[alive] = 0
        self.pol_amt[alive] *= 0.25            # grooming packs most body pollen away
        self.state[alive] = HOME
        self.timer[alive] = rng.integers(6, 20, len(alive))
        self.x[alive] = self.nest_x[alive]
        self.y[alive] = self.nest_y[alive]

    # ------------------------------------------------------------- results
    def run_day_fast(self):
        while self.step():
            pass

    def crop_fruit_set(self):
        """Pollination index per crop (0..1): saturating function of conspecific pollen."""
        out = {}
        for j, p in enumerate(self.plants):
            if not p.crop or p.key == "olivo":
                continue
            m = self.flat_pid == j
            if m.sum() == 0:
                continue
            out[p.name] = float(np.mean(1 - np.exp(-self.poll_cell[m] / FRUIT_K)))
        return out

    def summary(self):
        lines = []
        z, h, sc = self.zone, self.habitat, self.sc
        lines.append(f"Zona: {z.name}  |  Hábitat: {h.name}  |  Año: {sc.year}  |  Área: {sc.size_km} x {sc.size_km} km")
        lines.append(f"Colmenas: {sc.hives} por 9 km²  Pesticidas: {sc.pesticide}  Nidificación: {sc.nesting}  "
                     f"B. terrestris: {sc.terrestris}  Franjas florales: {'sí' if sc.flower_strips else 'no'}")
        lines.append(f"Circuito de alimentación: {self.feeding.source}")
        lines.append(f"Lluvia invernal acumulada (may–sep): {self.weather.winter_rain:.0f} mm")
        lines.append("")
        lines.append("Visitas florales por especie de abeja (temporada):")
        tot = self.visits.sum(0)
        for i, s in enumerate(SPECIES):
            lines.append(f"  {s.name:52s} {tot[i]:12.0f}")
        lines.append("")
        lines.append("Constancia floral (polen depositado en la misma especie de planta):")
        for i, s in enumerate(SPECIES):
            t = self.pollen_cons[i] + self.pollen_het[i]
            if t > 0:
                lines.append(f"  {s.name:52s} {100 * self.pollen_cons[i] / t:5.1f} %")
        lines.append("")
        lines.append("Plantas más visitadas:")
        for j in np.argsort(-self.visits.sum(1))[:10]:
            v = self.visits[j]
            if v.sum() <= 0:
                break
            nat = v[self.s_native].sum() / v.sum() * 100
            lines.append(f"  {self.plants[j].name:45s} {v.sum():12.0f}  ({nat:4.0f}% por abejas nativas)")
        fs = self.crop_fruit_set()
        if fs:
            lines.append("")
            lines.append("Índice de polinización de cultivos (0 = nada, 1 = saturado):")
            for k, v in fs.items():
                lines.append(f"  {k:45s} {v:.2f}")
        lines.append("")
        for key in ("dahlbomii", "terrestris"):
            cs = [c for c in self.colonies if SPECIES[c.sp].key == key]
            if cs:
                lines.append(f"{SPECIES[SP_INDEX[key]].name}: {len(cs)} colonias, "
                             f"{sum(c.new_queens for c in cs):.1f} nuevas reinas producidas")
        dahl = [c for c in self.colonies if SPECIES[c.sp].key == "dahlbomii"]
        if dahl:
            lines.append(f"  Infección media en B. dahlbomii: {np.mean([c.infection for c in dahl]):.2f}")
        sol = [c for c in self.colonies if SPECIES[c.sp].kind == "solitary"]
        if sol:
            hot = [c for c in sol if c.hotel]
            lines.append(f"Abejas solitarias: {len(sol)} nidos ({len(hot)} en hoteles), "
                         f"{sum(c.cells for c in sol):.0f} celdas de cría aprovisionadas")
        api = [c for c in self.colonies if SPECIES[c.sp].kind == "apis"]
        if api:
            honey_kg = sum(c.honey for c in api) * 40e-6 * 0.25
            lines.append(f"Colmenas ({len(api)}): pecoreadoras medias {np.mean([c.W for c in api]):.0f}, "
                         f"abejas internas medias {np.mean([c.H for c in api]):.0f}, "
                         f"miel excedente aprox. {honey_kg / len(api):.1f} kg/colmena")
        if self.lost_bees.sum() > 0:
            lines.append(f"Pecoreadoras perdidas por desorientación (pesticidas): {self.lost_bees.sum():.0f}")
        return "\n".join(lines)
