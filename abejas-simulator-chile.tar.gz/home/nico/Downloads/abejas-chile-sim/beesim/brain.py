"""Insect 'brain' modules driving each bee dot.

1. FeedingCircuit — sugar signal -> probability of accepting a flower.
   The curve comes from calibration.json, produced by flywire_calibrate.py,
   which runs the FlyWire whole-fly-brain LIF model (sugar GRNs -> MN9).
   Hunger raises the gain of the sugar input, as hunger sensitises sugar
   receptor neurons in real insects.

2. MushroomBody — odour learning. Projection neurons (PNs, ~50 glomeruli)
   fan out onto 2,000 Kenyon cells (KCs); each KC samples ~6 PNs and only the
   top 5 % fire (APL feedback inhibition). These numbers follow the fly
   connectome (FlyWire/hemibrain). Dopamine reward depresses KC->'avoid'
   output synapses; disappointment depresses KC->'approach' synapses.
   The net valence per flower odour becomes the bee's learned preference.
"""
import json
import zlib
from pathlib import Path
import numpy as np

CAL_PATH = Path(__file__).parent / "calibration.json"


class FeedingCircuit:
    def __init__(self, path: Path = CAL_PATH):
        # fallback shape if no calibration has been run
        self.rmax, self.x0, self.s, self.in_max = 100.0, 80.0, 15.0, 200.0
        self.source = "default (run flywire_calibrate.py to derive from FlyWire)"
        self.table = None
        if path.exists():
            c = json.loads(path.read_text())
            self.rmax, self.x0, self.s = c["rmax_hz"], c["x0_hz"], c["slope_hz"]
            self.in_max = c.get("input_max_hz", 200.0)
            self.source = c.get("source", "calibration.json")
            if c.get("table"):
                # use the simulated dose-response points directly
                self.table = (np.array([r["sugar_hz"] for r in c["table"]]),
                              np.array([r["mn9_hz"] for r in c["table"]]))

    def accept_prob(self, sugar_signal, hunger):
        """sugar_signal, hunger: arrays in 0..1 -> P(start feeding)."""
        grn_hz = sugar_signal * self.in_max * (0.55 + 0.9 * hunger)
        if self.table is not None:
            x, y = self.table
            return np.clip(np.interp(grn_hz, x, y) / y.max(), 0.0, 1.0)
        mn9 = self.rmax / (1.0 + np.exp(-(grn_hz - self.x0) / self.s))
        return np.clip(mn9 / self.rmax, 0.0, 1.0)


class MushroomBody:
    N_PN, N_KC, CLAWS, SPARSITY = 50, 2000, 6, 0.05

    def __init__(self, plant_keys, n_agents, rng):
        self.P = len(plant_keys)
        pn_kc = np.zeros((self.N_PN, self.N_KC), np.float32)
        for k in range(self.N_KC):
            pn_kc[rng.choice(self.N_PN, self.CLAWS, replace=False), k] = rng.uniform(.5, 1.5, self.CLAWS)
        n_act = int(self.N_KC * self.SPARSITY)
        self.nk = n_act
        K = np.zeros((self.N_KC, self.P), bool)
        self.kc_idx = np.zeros((self.P, n_act), np.int64)
        for j, key in enumerate(plant_keys):
            orng = np.random.default_rng(zlib.crc32(key.encode()))
            odour = (orng.random(self.N_PN) < 0.3) * orng.uniform(.3, 1, self.N_PN)
            drive = odour @ pn_kc
            top = np.argsort(drive)[-n_act:]
            K[top, j] = True
            self.kc_idx[j] = top
        self.K = K
        self.Kf = K.astype(np.float32)
        # overlap of each plant's active KCs with every plant's code: (P, nk, P)
        self.O = np.stack([self.Kf[self.kc_idx[j]] for j in range(self.P)]) / self.nk
        self.w_app = np.ones((n_agents, self.N_KC), np.float16)   # float16 keeps big maps in RAM
        self.w_av = np.ones((n_agents, self.N_KC), np.float16)
        self.v = np.zeros((n_agents, self.P), np.float32)   # valence per plant odour

    def reset_agents(self, idx):
        self.w_app[idx] = 1.0
        self.w_av[idx] = 1.0
        self.v[idx] = 0.0

    def learn(self, agents, plants, reward, punish, lr):
        """Batch update. reward/punish in 0..1, lr per agent (pesticide-impaired)."""
        if len(agents) == 0:
            return
        act = self.kc_idx[plants]                       # (B, nk)
        a = agents[:, None]
        old_av = self.w_av[a, act].astype(np.float32)
        old_ap = self.w_app[a, act].astype(np.float32)
        new_av = old_av * (1 - (lr * reward)[:, None])
        new_ap = old_ap * (1 - (lr * punish)[:, None])
        self.w_av[a, act] = new_av
        self.w_app[a, act] = new_ap
        delta = (new_ap - old_ap) - (new_av - old_av)   # change in (app - av)
        for p in np.unique(plants):
            m = plants == p
            self.v[agents[m]] += delta[m] @ self.O[p]

    def daily_forgetting(self, rate=0.08):
        self.w_app += np.float16(rate) * (np.float16(1) - self.w_app)
        self.w_av += np.float16(rate) * (np.float16(1) - self.w_av)
        v = np.empty_like(self.v)
        for i in range(0, len(v), 2048):      # chunked to bound temporary memory
            v[i:i + 2048] = ((self.w_app[i:i + 2048].astype(np.float32)
                              - self.w_av[i:i + 2048].astype(np.float32)) @ self.Kf) / self.nk
        self.v = v

    def preference(self, agents, plants):
        return 1.0 / (1.0 + np.exp(-4.0 * self.v[agents, plants]))
