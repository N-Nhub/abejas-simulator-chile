"""Procedural art for the viewer.

Everything is generated at start-up from the simulated landscape, so there are
no image assets to ship: terrain with hillshading and seasonal grass, tree
canopies, orchards in rows, flower carpets, clouds, bees and nests.
World texture: 8 px per 20 m cell -> 1200 x 1200 px for the 3 x 3 km map.
"""
import math
from pathlib import Path

import numpy as np
import pygame


CELL = 8
FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"


# --------------------------------------------------------------------- fonts
_font_cache = {}


def font(size, bold=False, italic=False):
    key = (size, bold, italic)
    if key in _font_cache:
        return _font_cache[key]
    style = ("BoldItalic" if bold and italic else "Bold" if bold
             else "Italic" if italic else "Regular")
    path = FONT_DIR / f"AtkinsonHyperlegible-{style}.ttf"
    if path.exists():
        f = pygame.font.Font(str(path), size)
    else:
        f = pygame.font.SysFont("atkinsonhyperlegible,inter,notosans,dejavusans",
                                size, bold=bold, italic=italic)
    _font_cache[key] = f
    return f


# --------------------------------------------------------------------- noise
def _upsample(grid, h, w, wrap=False):
    if wrap:
        n_y, n_x = grid.shape
        grid = np.pad(grid, ((0, 1), (0, 1)), mode="wrap")
        ys = np.linspace(0, n_y, h, endpoint=False)
        xs = np.linspace(0, n_x, w, endpoint=False)
    else:
        gh, gw = grid.shape
        ys = np.linspace(0, gh - 1.001, h)
        xs = np.linspace(0, gw - 1.001, w)
    y0, x0 = ys.astype(int), xs.astype(int)
    fy, fx = (ys - y0)[:, None], (xs - x0)[None, :]
    fy, fx = fy * fy * (3 - 2 * fy), fx * fx * (3 - 2 * fx)
    a, b = grid[y0][:, x0], grid[y0][:, x0 + 1]
    c, d = grid[y0 + 1][:, x0], grid[y0 + 1][:, x0 + 1]
    return ((a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy).astype(np.float32)


def fbm(h, w, rng, base=6, octaves=5, persistence=0.5, wrap=False):
    out = np.zeros((h, w), np.float32)
    amp, tot, n = 1.0, 0.0, base
    for _ in range(octaves):
        out += amp * _upsample(rng.random((n, n) if wrap else (n + 2, n + 2)).astype(np.float32),
                               h, w, wrap)
        tot += amp
        amp *= persistence
        n *= 2
    return out / tot


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


# ------------------------------------------------------------- plant forms
# form, canopy radius (px at 8 px/cell), leaf colour
FORMS = {
    "quillay": ("tree", 6.5, (80, 104, 58)), "litre": ("tree", 5.5, (90, 110, 56)),
    "boldo": ("tree", 5.5, (98, 122, 76)), "peumo": ("tree", 7.0, (62, 96, 52)),
    "maqui": ("shrub", 4.5, (72, 112, 58)), "ulmo": ("tree", 8.5, (50, 98, 56)),
    "canelo": ("tree", 6.5, (94, 128, 78)), "avellano": ("tree", 6.0, (58, 92, 50)),
    "chilco": ("shrub", 4.0, (76, 110, 60)), "eucalipto": ("tree", 7.5, (114, 138, 120)),
    "pino": ("conifer", 6.0, (38, 68, 46)), "chanar": ("shrub", 4.5, (120, 128, 82)),
    "cerezo": ("orchard_dec", 3.7, (86, 124, 62)), "almendro": ("orchard_dec", 3.7, (100, 130, 72)),
    "palto": ("orchard", 3.9, (52, 90, 48)), "olivo": ("orchard", 3.5, (130, 142, 110)),
    "arandano": ("bushrow", 2.7, (72, 104, 72)),
    "raps": ("crop", 0, (112, 152, 62)), "trebol": ("crop", 0, (88, 134, 66)),
    "yuyo": ("herb", 0, None), "maleza": ("herb", 0, None), "franja": ("herb", 0, None),
    "lavanda": ("garden", 0, None),
    "pata_guanaco": ("ephemeral", 0, None), "ananuca": ("ephemeral", 0, None),
    "suspiro": ("ephemeral", 0, None),
}
DENSITY = {"tree": .82, "shrub": .62, "conifer": 1.0, "orchard": 1.0, "orchard_dec": 1.0, "bushrow": 1.0}
FIELD_FORMS = {"orchard", "orchard_dec", "conifer", "crop", "bushrow"}
FLOWERS_MAX = {"crop": 18, "herb": 9, "garden": 10, "ephemeral": 16, "bushrow": 5}

# ground categories
PASTURE, SAND, LITTER, NEEDLES, ORCH_GRASS, CROP, BERRY_SOIL, URBAN, GARDEN = range(9)


def _aa(draw_fn, size, scale=3):
    """Draw at `scale`x then smooth-downscale for antialiasing."""
    big = pygame.Surface((size[0] * scale, size[1] * scale), pygame.SRCALPHA)
    draw_fn(big, scale)
    return pygame.transform.smoothscale(big, size)


# ------------------------------------------------------------- vegetation
def canopy_sprite(r, color, rng, kind="tree"):
    size = int(2 * r + max(10, r))

    def draw(s, k):
        c = size * k / 2
        R = r * k
        # cast shadow (afternoon sun from the north-west), scaled with the crown
        sh = pygame.Surface(s.get_size(), pygame.SRCALPHA)
        pygame.draw.ellipse(sh, (20, 26, 16, 85), (c - R + R * .32, c - R * .9 + R * .45, 2 * R, 1.8 * R))
        s.blit(sh, (0, 0))
        if kind == "conifer":
            pts = []
            n = 11
            for i in range(2 * n):
                a = i * math.pi / n + rng.uniform(-.08, .08)
                rr = R if i % 2 == 0 else R * .6
                pts.append((c + math.cos(a) * rr, c + math.sin(a) * rr))
            pygame.draw.polygon(s, shade(color, .85), pts)
            pygame.draw.circle(s, shade(color, 1.15), (c - R * .2, c - R * .2), R * .45)
            pygame.draw.circle(s, shade(color, .7), (c, c), R * .18)
            return
        lobes = 5 if kind == "tree" else 4
        for _ in range(lobes):
            a = rng.uniform(0, 2 * math.pi)
            d = rng.uniform(0, R * .38)
            pygame.draw.circle(s, shade(color, rng.uniform(.78, .92)),
                               (c + math.cos(a) * d, c + math.sin(a) * d), R * rng.uniform(.55, .68))
        for _ in range(3):
            a = rng.uniform(math.pi * 1.0, math.pi * 1.6)
            d = rng.uniform(R * .1, R * .35)
            pygame.draw.circle(s, shade(color, rng.uniform(1.08, 1.22)),
                               (c + math.cos(a) * d, c + math.sin(a) * d), R * rng.uniform(.28, .4))
    return _aa(draw, (size, size))


def bare_sprite(r, rng):
    size = int(2 * r + max(10, r))

    def draw(s, k):
        c = size * k / 2
        R = r * k
        pygame.draw.circle(s, (92, 72, 54, 150), (c, c), R * .75)
        for _ in range(6):
            a = rng.uniform(0, 2 * math.pi)
            pygame.draw.line(s, (78, 58, 42), (c, c), (c + math.cos(a) * R, c + math.sin(a) * R), max(1, k // 2))
    return _aa(draw, (size, size))


def flower_tile(color, n, rng, radius=None, tile=CELL + 4, dot=1.0):
    """A small transparent tile scattered with n flowers (inside a circle if radius)."""
    def draw(s, k):
        c = tile * k / 2
        for _ in range(n):
            if radius:
                a, d = rng.uniform(0, 2 * math.pi), radius * math.sqrt(rng.random()) * .85
                x, y = c + math.cos(a) * d * k, c + math.sin(a) * d * k
            else:
                x, y = rng.uniform(1, tile - 1) * k, rng.uniform(1, tile - 1) * k
            pr = dot * k * rng.uniform(.8, 1.15)
            for i in range(5):
                a = i * 2 * math.pi / 5
                pygame.draw.circle(s, color, (x + math.cos(a) * pr * .7, y + math.sin(a) * pr * .7), pr * .62)
            pygame.draw.circle(s, lerp(color, (255, 250, 210), .55), (x, y), pr * .36)
    return _aa(draw, (tile, tile))


# ------------------------------------------------------------------ clouds
PADC = 16


class Clouds:
    # tileable cloud shadows; surface() gives a 512 px tile plus a PADC margin
    def __init__(self, seed):
        rng = np.random.default_rng(seed + 55)
        self.n = fbm(512, 512, rng, base=4, octaves=5, wrap=True)
        self.cache = {}

    def surface(self, cover):
        key = round(cover * 20)
        if key not in self.cache:
            if key == 0:
                self.cache[key] = None
            else:
                thr = np.quantile(self.n, 1 - key / 20)
                a = np.clip((self.n - thr) / .08, 0, 1) * 105
                a = np.pad(a, PADC, mode="wrap")   # wrapped margin: no seams after scaling
                s = pygame.Surface(a.shape[::-1], pygame.SRCALPHA)
                s.fill((18, 26, 38, 0))
                pygame.surfarray.pixels_alpha(s)[:] = a.T.astype(np.uint8)
                self.cache[key] = s
        return self.cache[key]


# -------------------------------------------------------------------- bees
BEE_STYLE = {
    "apis": dict(L=11, abd=(214, 152, 48), bands=[(.25, (72, 48, 24)), (.45, (72, 48, 24)), (.65, (72, 48, 24))],
                 tip=(70, 46, 22), thorax=(146, 104, 54), head=(62, 46, 30), fuzz=None),
    "dahlbomii": dict(L=16, abd=(214, 100, 38), bands=[], tip=(176, 74, 26), thorax=(210, 98, 36),
                      head=(76, 42, 24), fuzz=(232, 128, 58)),
    "terrestris": dict(L=15, abd=(36, 34, 32), bands=[(.18, (232, 196, 60))], tip=(242, 240, 234),
                       thorax=(34, 32, 30), head=(28, 26, 24), fuzz=(70, 66, 60), collar=(232, 196, 60)),
    "solitaria": dict(L=9, abd=(48, 136, 148), bands=[(.4, (36, 98, 110)), (.62, (36, 98, 110))],
                      tip=(36, 98, 110), thorax=(58, 148, 118), head=(40, 92, 92), fuzz=None),
}


def bee_sprite(key, scale, frame):
    """Top-down bee facing +x. frame 0/1 = wing beat, 2 = wings folded (feeding)."""
    st = BEE_STYLE[key]
    L = st["L"] * scale
    S = max(8, int(L * 1.8))

    def draw(s, k):
        c = S * k / 2
        Lk = L * k
        rng = np.random.default_rng(7)
        outline = (26, 20, 12)
        # abdomen with bands, clipped to its ellipse, plus a dark outline for contrast
        er = pygame.Rect(0, 0, Lk * .66, Lk * .44)
        er.center = (c - Lk * .2, c)
        pygame.draw.ellipse(s, outline, er.inflate(Lk * .1, Lk * .1))
        pygame.draw.circle(s, outline, (c + Lk * .14, c), Lk * .24)
        pygame.draw.circle(s, outline, (c + Lk * .37, c), Lk * .16)
        abd = pygame.Surface(s.get_size(), pygame.SRCALPHA)
        pygame.draw.ellipse(abd, st["abd"], er)
        mask = pygame.surfarray.array_alpha(abd).copy()
        for pos, col in st["bands"]:
            x = er.right - er.width * (pos + .12)
            pygame.draw.rect(abd, col, (x, er.top, er.width * .12, er.height))
        pygame.draw.rect(abd, st["tip"], (er.left, er.top, er.width * .2, er.height))
        pygame.surfarray.pixels_alpha(abd)[:] = mask
        s.blit(abd, (0, 0))
        hl = pygame.Surface(s.get_size(), pygame.SRCALPHA)
        pygame.draw.ellipse(hl, (255, 255, 255, 80), (er.x + er.w * .35, er.y + er.h * .14, er.w * .42, er.h * .26))
        s.blit(hl, (0, 0))
        if st["fuzz"]:
            for _ in range(46):
                a = rng.uniform(0, 2 * math.pi)
                x = c - Lk * .06 + math.cos(a) * Lk * .44
                y = c + math.sin(a) * Lk * .23
                pygame.draw.circle(s, st["fuzz"], (x, y), max(1, k * .7))
        # thorax + head
        pygame.draw.circle(s, st["thorax"], (c + Lk * .14, c), Lk * .19)
        if st.get("collar"):
            pygame.draw.circle(s, st["collar"], (c + Lk * .19, c), Lk * .12)
            pygame.draw.circle(s, st["thorax"], (c + Lk * .11, c), Lk * .12)
        pygame.draw.circle(s, st["head"], (c + Lk * .37, c), Lk * .12)
        pygame.draw.circle(s, (255, 255, 255, 90), (c + Lk * .1, c - Lk * .07), Lk * .06)
        # wings: attached at the thorax, swept back, translucent so the body shows
        ang = {0: 66, 1: 44, 2: 13}[frame]
        ax, ay = c + Lk * .1, c
        for side in (-1, 1):
            wl, ww = Lk * .52, Lk * .19
            w = pygame.Surface((int(wl), int(ww)), pygame.SRCALPHA)
            pygame.draw.ellipse(w, (232, 242, 250, 95), w.get_rect())
            pygame.draw.ellipse(w, (255, 255, 255, 170), w.get_rect(), max(1, k // 2))
            deg = 180 + side * ang
            wr = pygame.transform.rotate(w, deg)
            rad = math.radians(deg)
            s.blit(wr, wr.get_rect(center=(ax + math.cos(rad) * wl * .56, ay - math.sin(rad) * wl * .56)))
    return _aa(draw, (S, S), scale=4)


class BeeSprites:
    def __init__(self):
        self.cache = {}

    def get(self, key, scale, frame, angle):
        sb = round(scale * 4) / 4
        ab = int(round(angle / (2 * math.pi) * 32)) % 32
        k = (key, sb, frame, ab)
        if k not in self.cache:
            base_k = (key, sb, frame, None)
            if base_k not in self.cache:
                self.cache[base_k] = bee_sprite(key, sb, frame)
            self.cache[k] = pygame.transform.rotozoom(self.cache[base_k], -ab * 360 / 32, 1)
        return self.cache[k]

    def shadow(self, key, scale):
        k = ("shadow", key, round(scale * 4) / 4)
        if k not in self.cache:
            L = BEE_STYLE[key]["L"] * scale
            s = pygame.Surface((int(L * .9) + 2, int(L * .5) + 2), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (16, 22, 12, 60), s.get_rect())
            self.cache[k] = s
        return self.cache[k]


# ------------------------------------------------------------------- nests
HIVE_COLORS = [(236, 236, 226), (176, 206, 226), (190, 222, 186), (238, 214, 140), (226, 186, 176)]


def hive_sprite(scale, cid):
    w, h = int(13 * scale), int(15 * scale)
    col = HIVE_COLORS[cid % len(HIVE_COLORS)]

    def draw(s, k):
        W, H = w * k, h * k
        pygame.draw.rect(s, (20, 24, 16, 80), (W * .18, H * .2, W * .82, H * .8))
        pygame.draw.rect(s, shade(col, .9), (0, H * .3, W * .82, H * .62))
        pygame.draw.line(s, shade(col, .7), (0, H * .61), (W * .82, H * .61), max(1, k))
        pygame.draw.rect(s, shade(col, 1.05), (-W * .02, H * .14, W * .86, H * .2))
        pygame.draw.rect(s, (50, 40, 30), (W * .25, H * .84, W * .32, H * .05))
    return _aa(draw, (w, h))


def nest_sprite(scale, color, active):
    d = int(10 * scale)

    def draw(s, k):
        c = d * k / 2
        for i in range(10):
            a = i * math.pi / 5
            pygame.draw.circle(s, (70, 100, 50), (c + math.cos(a) * c * .72, c + math.sin(a) * c * .72), c * .22)
        pygame.draw.circle(s, (40, 30, 22), (c, c), c * .42)
        if active:
            pygame.draw.circle(s, color, (c, c), c * .9, max(1, int(k * scale * .9)))
    return _aa(draw, (d, d))


def hotel_sprite(scale):
    w, h = int(14 * scale), int(17 * scale)

    def draw(s, k):
        W, H = w * k, h * k
        pygame.draw.rect(s, (20, 24, 16, 80), (W * .2, H * .25, W * .8, H * .75))
        pygame.draw.polygon(s, (110, 70, 42), [(0, H * .3), (W * .5, 0), (W, H * .3)])
        pygame.draw.rect(s, (160, 112, 70), (W * .08, H * .28, W * .84, H * .66))
        for i in range(3):
            for j in range(3):
                pygame.draw.circle(s, (54, 36, 24), (W * (.25 + .25 * i), H * (.42 + .17 * j)), W * .07)
    return _aa(draw, (w, h))


def weather_icon(kind, size):
    def draw(s, k):
        c = size * k / 2
        if kind in ("sun", "partly"):
            sx, sy = (c, c) if kind == "sun" else (c * .8, c * .75)
            for i in range(8):
                a = i * math.pi / 4
                pygame.draw.line(s, (214, 150, 20), (sx + math.cos(a) * c * .45, sy + math.sin(a) * c * .45),
                                 (sx + math.cos(a) * c * .7, sy + math.sin(a) * c * .7), max(1, int(k * 2)))
            pygame.draw.circle(s, (232, 172, 30), (sx, sy), c * .34)
        if kind in ("partly", "cloud", "rain"):
            col = (150, 162, 172) if kind != "partly" else (214, 220, 226)
            for dx, dy, r in ((-.3, .15, .3), (.05, -.05, .38), (.38, .18, .28)):
                pygame.draw.circle(s, col, (c + dx * c * 1.1, c + dy * c + c * .1), r * c)
            pygame.draw.rect(s, col, (c - c * .62, c + c * .12, c * 1.3, c * .36))
        if kind == "rain":
            for dx in (-.4, 0, .4):
                pygame.draw.line(s, (70, 110, 160), (c + dx * c, c + c * .6), (c + dx * c - c * .12, c + c * .9),
                                 max(1, int(k * 2)))
    return _aa(draw, (size, size))
