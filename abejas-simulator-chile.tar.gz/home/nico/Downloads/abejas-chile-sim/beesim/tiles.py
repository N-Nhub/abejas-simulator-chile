"""Level-of-detail landscape renderer.

The map is cut into 256 px tiles at zoom levels of 1, 2, 4, 8, 16 and 32 px per
20 m cell. A tile is drawn only when it becomes visible, cached, and redrawn
when the season changes how it looks. All texture comes from deterministic hash
noise evaluated in map coordinates, so neighbouring tiles and zoom levels line
up without seams. Low zoom levels colour pixels directly (fast); from 4 px per
cell upward each tree, shrub and flower patch is a sprite.
"""
import random
import time
from collections import OrderedDict

import numpy as np
import pygame

from .art import (FORMS, DENSITY, FIELD_FORMS, FLOWERS_MAX, canopy_sprite, bare_sprite,
                  flower_tile, lerp, shade)
from .flora import in_window

TILE = 256
LEVELS = (1, 2, 4, 8, 16, 32)
SPRITE_LEVEL = 4

PASTURE, SAND, LITTER, NEEDLES, ORCH_GRASS, CROP, BERRY_SOIL, URBAN, GARDEN = range(9)
M32 = np.uint64(0xFFFFFFFF)


# ------------------------------------------------------------------ noise
def _hash(ix, iy, seed):
    h = (ix.astype(np.int64).astype(np.uint64) * np.uint64(374761393)
         + iy.astype(np.int64).astype(np.uint64) * np.uint64(668265263)
         + np.uint64(seed * 2246822519 % 4294967291)) & M32
    h = ((h ^ (h >> np.uint64(13))) * np.uint64(1274126177)) & M32
    h = h ^ (h >> np.uint64(16))
    return (h & M32).astype(np.float32) / np.float32(4294967296.0)


def vnoise(u, v, freq, seed):
    x, y = u * freq, v * freq
    ix, iy = np.floor(x), np.floor(y)
    fx, fy = x - ix, y - iy
    fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    a = _hash(ix, iy, seed)
    b = _hash(ix + 1, iy, seed)
    c = _hash(ix, iy + 1, seed)
    d = _hash(ix + 1, iy + 1, seed)
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


def fbm(u, v, freq, octaves, seed, max_freq=None):
    out = np.zeros_like(u, dtype=np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        if max_freq is not None and freq > max_freq:
            break
        out += amp * vnoise(u, v, freq, seed + o * 101)
        tot += amp
        amp *= .5
        freq *= 2
    return out / max(tot, 1e-6)


class TileRenderer:
    def __init__(self, world, budget_ms=24):
        self.w = world
        self.G = world.G
        self.seed = world.sc.seed * 7919 + 13
        self.budget = budget_ms / 1000
        self.cache = OrderedDict()            # (p, tx, ty) -> (key, surface)
        self.max_tiles = 260
        self.queue = []
        self.desert = world.sc.zone == "desierto"
        keys = world.plant_keys
        self.form = [FORMS.get(k, ("herb", 0, None))[0] for k in keys]
        self.radius = np.array([FORMS.get(k, ("herb", 0, None))[1] / 8 for k in keys], np.float32)  # in cells
        self.leaf = [FORMS.get(k, ("herb", 0, (90, 120, 70)))[2] or (96, 134, 66) for k in keys]
        self.is_field = np.array([f in FIELD_FORMS for f in self.form])
        cat = []
        for j, f in enumerate(self.form):
            cat.append({"tree": LITTER, "shrub": SAND if self.desert else LITTER, "conifer": NEEDLES,
                        "orchard": ORCH_GRASS, "orchard_dec": ORCH_GRASS, "bushrow": BERRY_SOIL,
                        "crop": CROP, "garden": GARDEN, "ephemeral": SAND}.get(f, SAND if self.desert else PASTURE))
        self.cat_of_plant = np.array(cat, np.int8)
        # background category per cell (urban blocks only inside urban regions)
        G = self.G
        bg = SAND if self.desert else PASTURE
        self.bg_cat = np.full((G, G), bg, np.int8)
        if world.habitat.key == "urbano":
            self.bg_cat[:] = URBAN
        elif world.region is not None:
            from .flora import HABITATS
            habs = [h for h in HABITATS[world.sc.zone] if h.key != "regional"]
            for i, h in enumerate(habs):
                if h.key == "urbano":
                    self.bg_cat[world.region == i] = URBAN
        # per-cell instance data (deterministic)
        r = np.random.default_rng(world.sc.seed + 7)
        self.jx = r.uniform(-.3, .3, (G, G)).astype(np.float32)
        self.jy = r.uniform(-.3, .3, (G, G)).astype(np.float32)
        self.var = r.integers(0, 12, (G, G)).astype(np.int16)
        dens = np.array([DENSITY.get(f, 0.0) for f in self.form], np.float32)
        pid = world.pid
        self.canopy = (pid >= 0) & (r.random((G, G)) < dens[np.maximum(pid, 0)])
        self._houses()
        self.sprites = {}
        self.day_key = None
        self.overview = None
        self.sp_rng = random.Random(world.sc.seed)

    # ------------------------------------------------------------- houses
    def _houses(self):
        G = self.G
        r = np.random.default_rng(self.seed + 5)
        roofs = np.array([(170, 86, 64), (150, 70, 56), (128, 128, 134), (184, 112, 80),
                          (106, 110, 118), (196, 150, 108)])
        hs = []
        urban = (self.bg_cat == URBAN) & (self.w.pid < 0)
        for by in range(0, G, 9):
            for bx in range(0, G, 9):
                if not urban[by:by + 9, bx:bx + 9].any():
                    continue
                for _ in range(r.integers(3, 7)):
                    hx, hy = bx + 1 + r.uniform(0, 6), by + 1 + r.uniform(0, 6)
                    cx, cy = min(int(hx), G - 1), min(int(hy), G - 1)
                    if not urban[cy, cx]:
                        continue
                    hs.append((hx, hy, r.uniform(1.2, 2.2), r.uniform(1.1, 1.9), *roofs[r.integers(0, len(roofs))]))
        self.houses = np.array(hs, np.float32) if hs else np.zeros((0, 7), np.float32)

    # ---------------------------------------------------------- day state
    def _dryness(self):
        return float(np.clip((0.55 - self.w.weather.soil) / 0.42, 0, 1))

    def orchard_state(self, j):
        p = self.w.plants[j]
        if self.w.bloom[j] > .08:
            return "bloom"
        return "bare" if in_window(self.w.doy, 135, p.start) else "leaf"

    def levels(self):
        return np.array([int(min(4, round(float(b) * 4))) for b in self.w.bloom], np.int8)

    def update_day(self):
        """Call once per simulated day. Returns True if tiles must be redrawn."""
        lv = self.levels()
        orch = tuple(self.orchard_state(j) for j, f in enumerate(self.form) if f == "orchard_dec")
        key = (round(self._dryness() * 12), lv.tobytes(), orch)
        if key != self.day_key:
            self.day_key = key
            self.lv = lv
            self.orch = {j: self.orchard_state(j) for j, f in enumerate(self.form) if f == "orchard_dec"}
            self.overview = self.render_overview()
            return True
        return False

    def _palette(self):
        dry = self._dryness()
        green, straw = (98, 134, 66), (198, 174, 104)
        if self.desert:
            green = (164, 160, 108)
        pal = np.zeros((9, 3), np.float32)
        pal[PASTURE] = lerp(green, straw, dry)
        pal[SAND] = (214, 188, 142)
        pal[LITTER] = lerp((70, 96, 52), (128, 120, 76), dry * .6)
        pal[NEEDLES] = (106, 82, 54)
        pal[ORCH_GRASS] = lerp((96, 138, 70), (150, 150, 88), dry * .4)
        pal[CROP] = (110, 148, 64)
        pal[BERRY_SOIL] = (122, 96, 68)
        pal[URBAN] = (178, 172, 158)
        pal[GARDEN] = (92, 142, 74)
        return pal

    # ------------------------------------------------------- pixel colour
    def _pixels(self, u, v, p):
        """Colour (h, w, 3) float for map coordinates u, v (in cells) at level p."""
        G, w, seed = self.G, self.w, self.seed
        pid = w.pid
        cu = np.clip(u.astype(np.int32), 0, G - 1)
        cv = np.clip(v.astype(np.int32), 0, G - 1)
        # organic patch edges: look up a slightly displaced cell, except inside fields
        du = (vnoise(u, v, .22, seed + 1) - .5) * 1.8 + (vnoise(u, v, 1.1, seed + 2) - .5) * .7
        dv = (vnoise(u, v, .22, seed + 3) - .5) * 1.8 + (vnoise(u, v, 1.1, seed + 4) - .5) * .7
        if p >= 8:            # close up: wobble the cell edges at finer scales too
            du = du + (vnoise(u, v, 3.3, seed + 5) - .5) * .45 + (vnoise(u, v, 9.0, seed + 6) - .5) * .2
            dv = dv + (vnoise(u, v, 3.3, seed + 7) - .5) * .45 + (vnoise(u, v, 9.0, seed + 8) - .5) * .2
        du2 = np.clip((u + du).astype(np.int32), 0, G - 1)
        dv2 = np.clip((v + dv).astype(np.int32), 0, G - 1)
        p0, p1 = pid[cv, cu], pid[dv2, du2]
        keep = ((p0 >= 0) & self.is_field[np.maximum(p0, 0)]) | ((p1 >= 0) & self.is_field[np.maximum(p1, 0)])
        cy = np.where(keep, cv, dv2)
        cx = np.where(keep, cu, du2)
        pp = pid[cy, cx]
        cat = np.where(pp >= 0, self.cat_of_plant[np.maximum(pp, 0)], self.bg_cat[cy, cx])
        rgb = self._palette()[cat]
        # texture
        fine = fbm(u, v, 1.5, 3, seed + 10, max_freq=p / 2.5) if p >= 4 else np.float32(.5)
        mottle = fbm(u, v, .1, 4, seed + 20, max_freq=p * .6)
        e0 = fbm(u, v, .012, 4, seed + 30)
        ex = fbm(u + 1.5, v, .012, 4, seed + 30)
        ey = fbm(u, v + 1.5, .012, 4, seed + 30)
        hill = np.clip(1 + (-(ex - e0) * 40 - (ey - e0) * 55) * (1.6 if self.desert else 1.0), .78, 1.22)
        mod = (.9 + .2 * fine) * (.9 + .2 * mottle) * hill
        if p >= 4:
            mod = np.where(cat == ORCH_GRASS, mod * np.where(cy % 2 == 0, 1.05, .95), mod)
            mod = np.where(cat == CROP, mod * (.965 + .035 * np.sin(v * 7.2 + mottle * 8)), mod)
        mod = np.where(cat == SAND, mod * (1 + .05 * np.sin((u * 7 + v * 3.5 + mottle * 60) / 3.2)), mod)
        rgb = rgb * mod[..., None]
        # urban streets
        urb = cat == URBAN
        if urb.any():
            street = urb & ((cx % 9 == 0) | (cy % 9 == 0))
            rgb[street] = np.array((84, 86, 92), np.float32) * mod[street][:, None]
        # blooming crops tint the whole field (raps yellow, clover pink)
        crop = (cat == CROP) & (pp >= 0)
        if crop.any():
            j = pp[crop]
            b = w.bloom[j][:, None] * .55
            fc = np.array([w.plants[k].color for k in range(len(w.plants))], np.float32)[j]
            rgb[crop] = rgb[crop] * (1 - b) + fc * mod[crop][:, None] * b
        if p < SPRITE_LEVEL:
            rgb = self._lowres_vegetation(rgb, pp, cx, cy, u, v, mod)
        return rgb

    def _lowres_vegetation(self, rgb, pp, cx, cy, u, v, mod):
        """At far zoom: canopies and flowers as colour, no sprites."""
        w = self.w
        has = pp >= 0
        can = has & self.canopy[cy, cx]
        if can.any():
            j = pp[can]
            leaf = np.array(self.leaf, np.float32)[j]
            orch = np.array([f == "orchard_dec" for f in self.form])[j]
            bl = np.array([w.plants[k].color for k in range(len(w.plants))], np.float32)[j]
            lvl = self.lv[j][:, None] / 4
            col = leaf * (1 - .6 * lvl * orch[:, None]) + bl * .6 * lvl * orch[:, None]
            col = col * (1 - .35 * lvl * ~orch[:, None]) + bl * .35 * lvl * ~orch[:, None]
            rgb[can] = rgb[can] * .2 + col * mod[can][:, None] * .8
        herb = has & ~self.canopy[cy, cx]
        if herb.any():
            j = pp[herb]
            lvl = self.lv[j][:, None] / 4
            bl = np.array([w.plants[k].color for k in range(len(w.plants))], np.float32)[j]
            rgb[herb] = rgb[herb] * (1 - .45 * lvl) + bl * .45 * lvl
        return rgb

    def render_overview(self):
        """Whole map at 1 px per cell (minimap and fallback)."""
        G = self.G
        v, u = np.mgrid[0:G, 0:G].astype(np.float32) + .5
        rgb = self._pixels(u, v, 1)
        return pygame.surfarray.make_surface(np.clip(rgb, 0, 255).astype(np.uint8).transpose(1, 0, 2))

    # -------------------------------------------------------------- sprites
    def sprite(self, kind, j, var, p):
        key = (kind, j, var % 4, p)
        s = self.sprites.get(key)
        if s is None:
            r = max(1.2, float(self.radius[j]) * p)
            f = self.form[j]
            pl = self.w.plants[j]
            if kind == "leaf":
                s = canopy_sprite(r, self.leaf[j], self.sp_rng, "conifer" if f == "conifer" else
                                  ("shrub" if f in ("shrub", "bushrow") else "tree"))
            elif kind == "bare":
                s = bare_sprite(r, self.sp_rng)
            elif kind == "bloom":
                s = canopy_sprite(r, lerp(pl.color, (255, 255, 255), .25), self.sp_rng)
            else:                                   # "fl1".."fl4"
                lv = int(kind[2])
                if f in ("tree", "shrub", "orchard", "orchard_dec"):
                    s = flower_tile(pl.color, max(1, int(lv * float(self.radius[j]) * 8 * .9)), self.sp_rng,
                                    radius=r * .9, tile=int(2 * r + max(10, r)), dot=max(.6, p / 10))
                else:
                    mx = FLOWERS_MAX.get(f, 8)
                    s = flower_tile(pl.color, max(1, int(mx * lv / 4)), self.sp_rng,
                                    tile=int(p * 1.5) + 2, dot=max(.6, p / (8 if f != "crop" else 11)))
            self.sprites[key] = s
        return s

    # ---------------------------------------------------------------- tiles
    def _render_tile(self, p, tx, ty):
        c0 = tx * TILE / p
        r0 = ty * TILE / p
        px = (np.arange(TILE, dtype=np.float32) + .5) / p
        v, u = np.meshgrid(r0 + px, c0 + px, indexing="ij")
        rgb = self._pixels(u, v, p)
        surf = pygame.surfarray.make_surface(np.clip(rgb, 0, 255).astype(np.uint8).transpose(1, 0, 2))
        if p >= SPRITE_LEVEL:
            self._draw_houses(surf, p, c0, r0)
            self._draw_vegetation(surf, p, c0, r0)
        return surf

    def _draw_houses(self, surf, p, c0, r0):
        if not len(self.houses):
            return
        span = TILE / p
        h = self.houses
        m = (h[:, 0] + h[:, 2] > c0) & (h[:, 0] < c0 + span) & (h[:, 1] + h[:, 3] > r0) & (h[:, 1] < r0 + span)
        for hx, hy, hw, hh, cr, cg, cb in h[m]:
            x, y, wpx, hpx = float((hx - c0) * p), float((hy - r0) * p), float(hw * p), float(hh * p)
            col = (int(cr), int(cg), int(cb))
            sh = pygame.Surface((max(1, int(wpx)), max(1, int(hpx))), pygame.SRCALPHA)
            sh.fill((40, 40, 36, 90))
            surf.blit(sh, (x + p * .35, y + p * .35))
            pygame.draw.rect(surf, col, (x, y, wpx, hpx))
            pygame.draw.rect(surf, shade(col, 1.15), (x, y, wpx, hpx / 2))
            pygame.draw.line(surf, shade(col, .75), (x, y + hpx / 2), (x + wpx, y + hpx / 2))

    def _draw_vegetation(self, surf, p, c0, r0):
        G = self.G
        span = TILE / p
        a0, a1 = max(0, int(c0) - 2), min(G, int(c0 + span) + 3)
        b0, b1 = max(0, int(r0) - 2), min(G, int(r0 + span) + 3)
        sub = self.w.pid[b0:b1, a0:a1]
        ys, xs = np.nonzero(sub >= 0)
        if not len(ys):
            return
        ys, xs = ys + b0, xs + a0
        seq = []
        for cy, cx in zip(ys.tolist(), xs.tolist()):
            j = int(self.w.pid[cy, cx])
            f = self.form[j]
            var = int(self.var[cy, cx])
            canopy = bool(self.canopy[cy, cx])
            jit = .3 if f in ("tree", "shrub") else (.12 if f == "conifer" else (.0 if f in DENSITY else .4))
            px = float((cx + .5 + self.jx[cy, cx] * jit / .3 - c0) * p)
            py = float((cy + .5 + self.jy[cy, cx] * jit / .3 - r0) * p)
            if canopy:
                kind = self.orch[j] if f == "orchard_dec" else "leaf"
                s = self.sprite(kind, j, var, p)
                seq.append((s, (px - s.get_width() / 2, py - s.get_height() / 2)))
            lv = int(self.lv[j])
            if lv > 0 and (canopy or f not in DENSITY) and (self.w.p_nectar[j] > 0 or self.w.p_pollen[j] > 0):
                s = self.sprite(f"fl{lv}", j, var, p)
                seq.append((s, (px - s.get_width() / 2, py - s.get_height() / 2)))
        surf.blits(seq, doreturn=False)

    def get(self, p, tx, ty, allow_render=True):
        """Return (surface, fresh). Renders within the frame budget, else returns stale or None."""
        k = (p, tx, ty)
        ent = self.cache.get(k)
        if ent is not None and ent[0] == self.day_key:
            self.cache.move_to_end(k)
            return ent[1], True
        if allow_render and time.perf_counter() < self.deadline:
            s = self._render_tile(p, tx, ty)
            self.cache[k] = (self.day_key, s)
            self.cache.move_to_end(k)
            while len(self.cache) > self.max_tiles:
                self.cache.popitem(last=False)
            return s, True
        return (ent[1], False) if ent is not None else (None, False)

    def begin_frame(self):
        self.deadline = time.perf_counter() + self.budget

    def pick_level(self, s):
        for p in LEVELS:
            if p >= s * .95:
                return p
        return LEVELS[-1]
