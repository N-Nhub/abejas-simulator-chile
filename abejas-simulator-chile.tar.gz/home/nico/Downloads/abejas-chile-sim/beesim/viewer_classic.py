"""Live pygame view of the landscape.

Keys: SPACE pause · ↑/↓ speed · D finish the current day instantly
      H visit heatmap · S screenshot · ESC/Q stop and write results
"""
import numpy as np
import pygame

from .world import G, HOME, doy_to_str
from .bees import SPECIES
from .flora import BG_COLOR

PX = 4
MAP = G * PX
PANEL = 400
H_WIN = MAP
PANEL_BG = (38, 44, 36)
INK = (232, 228, 214)
DIM = (160, 164, 150)
HONEY = (240, 190, 40)


class Viewer:
    def __init__(self, world, out_dir):
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_caption("Abejas de Chile central — simulación")
        self.w = world
        self.out_dir = out_dir
        self.screen = pygame.display.set_mode((MAP + PANEL, H_WIN))
        self.font = pygame.font.SysFont("dejavusans,notosans,liberationsans", 14)
        self.big = pygame.font.SysFont("dejavusans,notosans,liberationsans", 18, bold=True)
        self.small = pygame.font.SysFont("dejavusans,notosans,liberationsans", 12)
        self.clock = pygame.time.Clock()
        self.speed = 6            # ticks per frame
        self.paused = False
        self.heatmap = False
        self.map_surf = None
        self.tick_count = 0
        bg = BG_COLOR["desierto" if world.sc.zone == "desierto" else "default"]
        self.bg = np.array(bg, np.float32)
        cols = np.array([p.color for p in world.plants], np.float32)
        foliage = np.array([82, 112, 64], np.float32)
        self.present = set(int(v) for v in np.unique(world.flat_pid[world.flat_pid >= 0]))
        self.plant_full = cols
        self.plant_leaf = np.where(np.array([p.key == "pino" for p in world.plants])[:, None],
                                   cols, 0.75 * foliage + 0.25 * cols * 0.7)

    # ----------------------------------------------------------------- drawing
    def _build_map(self):
        w = self.w
        pid = w.flat_pid
        rgb = np.tile(self.bg, (G * G, 1))
        m = pid >= 0
        p = pid[m]
        bloom = w.bloom[p][:, None]
        rgb[m] = self.plant_leaf[p] * (1 - bloom) + self.plant_full[p] * bloom
        # depleted nectar darkens a blooming cell
        cap = w.cap[m]
        frac = np.where(cap > 0, w.nectar[m] / np.maximum(cap, 1e-6), 1)
        rgb[m] *= (0.65 + 0.35 * frac)[:, None]
        if self.heatmap:
            h = np.log1p(w.heat) / np.log1p(max(w.heat.max(), 1))
            rgb = rgb * (1 - 0.75 * h[:, None]) + np.array([255, 40, 30]) * 0.75 * h[:, None]
        if w.rain_now:
            rgb = rgb * 0.75 + np.array([60, 80, 120]) * 0.25
        img = np.clip(rgb, 0, 255).astype(np.uint8).reshape(G, G, 3).transpose(1, 0, 2)
        surf = pygame.surfarray.make_surface(img)
        self.map_surf = pygame.transform.scale(surf, (MAP, MAP))

    def _draw_nests(self):
        w = self.w
        for site in w.hotel_sites:
            r = pygame.Rect(site[0] * PX - 6, site[1] * PX - 6, 12, 12)
            pygame.draw.rect(self.screen, (120, 80, 40), r)
            pygame.draw.rect(self.screen, INK, r, 1)
        for c in w.colonies:
            s = SPECIES[c.sp]
            x, y = int(c.x * PX), int(c.y * PX)
            if s.kind == "apis":
                pygame.draw.rect(self.screen, (250, 250, 240), (x - 4, y - 4, 8, 8))
                pygame.draw.rect(self.screen, s.color, (x - 4, y - 4, 8, 8), 2)
            elif s.kind == "bumble" and c.alive:
                pygame.draw.circle(self.screen, s.color, (x, y), 5, 2 if c.active else 1)
            elif s.kind == "solitary" and c.active and not c.hotel:
                pygame.draw.circle(self.screen, (90, 60, 30), (x, y), 2)

    def _draw_bees(self):
        w = self.w
        vis = np.flatnonzero(w.on & (w.state != HOME))
        for a in vis:
            s = SPECIES[w.sp[a]]
            r = 3 if s.kind == "bumble" else 2
            pos = (int(w.x[a] * PX), int(w.y[a] * PX))
            pygame.draw.circle(self.screen, s.color, pos, r)
            if s.kind == "bumble":
                pygame.draw.circle(self.screen, (250, 240, 200), pos, r, 1)

    def _text(self, txt, x, y, font=None, color=INK):
        surf = (font or self.font).render(txt, True, color)
        self.screen.blit(surf, (x, y))
        return y + surf.get_height() + 3

    def _draw_panel(self):
        w = self.w
        x0 = MAP + 18
        pygame.draw.rect(self.screen, PANEL_BG, (MAP, 0, PANEL, H_WIN))
        y = 14
        y = self._text(w.zone.name, x0, y, self.big, HONEY)
        y = self._text(w.habitat.name, x0, y)
        y = self._text(f"{w.zone.koppen}  ·  año: {w.sc.year}", x0, y, self.small, DIM)
        y += 8
        h = int(w.hour); mnt = int((w.hour - h) * 60)
        wx = w.today
        sky = "lluvia" if w.rain_now else ("nublado" if wx["rain"] else "despejado")
        y = self._text(f"Día {w.day_index + 1}/{w.sc.days}   {doy_to_str(w.doy)}   {h:02d}:{mnt:02d}", x0, y, self.big)
        y = self._text(f"{w.temp_now:4.1f} °C   ({wx['tmin']:.0f}–{wx['tmax']:.0f})   {sky}", x0, y)
        y = self._text(f"Humedad del suelo {w.weather.soil:.2f}   lluvia hoy {wx['mm']:.0f} mm", x0, y, self.small, DIM)
        y += 10
        for i, s in enumerate(SPECIES):
            cs = [c for c in w.colonies if c.sp == i]
            if not cs:
                continue
            flying = int((w.on & (w.sp == i) & (w.state != HOME)).sum())
            workers = sum(c.W for c in cs if c.active)
            ok = w.temp_now >= s.min_t and w.temp_now <= s.max_t and not w.rain_now
            n_act = sum(c.active for c in cs)
            status = ("vuela" if ok else "en nido") if n_act else "inactiva"
            pygame.draw.circle(self.screen, s.color, (x0 + 6, y + 8), 6)
            pygame.draw.circle(self.screen, INK, (x0 + 6, y + 8), 6, 1)
            self._text(s.name.split(" (")[0], x0 + 18, y)
            y = self._text(status, x0 + 300, y, self.small, INK if (ok and n_act) else DIM)
            y = self._text(f"   {sum(c.active for c in cs)} nidos activos · {workers:,.0f} obreras · {flying} puntos volando",
                           x0 + 4, y, self.small, DIM)
        y += 8
        y = self._text("En flor ahora", x0, y, self.font, HONEY)
        order = np.argsort(-w.bloom)
        shown = 0
        for j in order:
            if w.bloom[j] < .05 or shown >= 7:
                break
            if int(j) not in self.present:
                continue
            p = w.plants[j]
            pygame.draw.rect(self.screen, p.color, (x0, y + 3, 12, 12))
            y = self._text(f"{p.name}  {w.bloom[j]:.0%}", x0 + 18, y, self.small)
            shown += 1
        if shown == 0:
            y = self._text("Nada florece en este paisaje hoy", x0, y, self.small, DIM)
        y += 8
        d = w.daily[-1] if w.daily else {}
        if d:
            y = self._text("Ayer", x0, y, self.font, HONEY)
            y = self._text(f"Visitas por abejas nativas: {d['visitas_nativas_pct']}%", x0, y, self.small)
            y = self._text(f"Nuevas reinas: dahlbomii {d['dahlbomii_nuevas_reinas']} · terrestris {d['terrestris_nuevas_reinas']}", x0, y, self.small)
            y = self._text(f"Infección en dahlbomii: {d['dahlbomii_infeccion_media']:.2f}", x0, y, self.small)
            y = self._text(f"Celdas de cría solitarias: {d['solitaria_celdas']:.0f}", x0, y, self.small)
        foot = H_WIN - 56
        self._text(f"Velocidad ×{self.speed}  {'(pausa)' if self.paused else ''}  "
                   f"{'· mapa de calor' if self.heatmap else ''}", x0, foot, self.small, DIM)
        self._text("Espacio pausa · ↑↓ velocidad · D terminar día", x0, foot + 16, self.small, DIM)
        self._text("H mapa de calor · S captura · Q salir", x0, foot + 31, self.small, DIM)

    # -------------------------------------------------------------------- loop
    def run(self):
        w = self.w
        w.temp_now, w.rain_now = w.weather.temp_at(w.hour), False
        running = True
        while running and not w.finished:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    running = False
                elif ev.type == pygame.KEYDOWN:
                    if ev.key in (pygame.K_ESCAPE, pygame.K_q):
                        running = False
                    elif ev.key == pygame.K_SPACE:
                        self.paused = not self.paused
                    elif ev.key == pygame.K_UP:
                        self.speed = min(400, max(self.speed + 1, int(self.speed * 1.6)))
                    elif ev.key == pygame.K_DOWN:
                        self.speed = max(1, int(self.speed / 1.6))
                    elif ev.key == pygame.K_d:
                        w.run_day_fast()
                        self.map_surf = None
                    elif ev.key == pygame.K_h:
                        self.heatmap = not self.heatmap
                        self.map_surf = None
                    elif ev.key == pygame.K_s:
                        self.screenshot()
            if not self.paused:
                for _ in range(self.speed):
                    self.tick_count += 1
                    if not w.step():
                        self.map_surf = None
                        break
                    if w.finished:
                        break
            if w.finished:
                break
            if self.map_surf is None or self.tick_count % 15 == 0:
                self._build_map()
            self.screen.blit(self.map_surf, (0, 0))
            self._draw_nests()
            self._draw_bees()
            self._draw_panel()
            pygame.display.flip()
            self.clock.tick(30)
        self.screenshot("mapa_final.png")
        pygame.quit()

    def screenshot(self, name=None):
        if self.out_dir is None:
            return
        self.out_dir.mkdir(parents=True, exist_ok=True)
        name = name or f"captura_dia{self.w.day_index + 1:03d}.png"
        pygame.image.save(self.screen, str(self.out_dir / name))
