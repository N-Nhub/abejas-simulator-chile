# Abejas de Chile central: pollinator simulator

An agent-based simulation of bees in landscapes of central and southern Chile
(O'Higgins to La Araucanía) and the Atacama desert. You choose a climate zone, a map
size (3, 6 or 12 km across) and an environment, then what-if switches: hives,
pesticides, nesting sites for native bees, the invasive bumblebee, native flower
strips. Each bee forages, learns which flowers pay off and carries pollen between
flowers. Colonies grow or fail with weather, food, parasites and pesticides.

The model is built to **compare scenarios against each other**. Its absolute numbers
are not field predictions. Every parameter, its source, and whether it comes from
the literature or is our own assumption is listed in
[Parameters and their sources](#parameters-and-their-sources).

---

## Quick start (Arch Linux)

```fish
sudo pacman -S --needed python-numpy python-pygame python-matplotlib
./run.fish                                     # menu, then the live map
./run.fish --headless                          # menu, then a fast run without a window
./run.fish --list                              # zones and environments
python run.py --zone nuble --habitat regional --size 12 --team "Buzz Team"
./compare.fish biobio_costa nativo             # six interventions on the same landscape
./calibrate.fish                               # re-derive the feeding curve from FlyWire
```

Only the calibration needs extra packages:
`sudo pacman -S --needed python-pandas python-pyarrow python-scipy git`.

**Run time.** One season (240 days) takes a few minutes headless on the 3 km map,
about 2.5 times longer on 6 km, and roughly 20 minutes or more on 12 km. The window
can skip ahead a day at a time with `D`.

**Outputs** go to `results/<zone>_<habitat>_<year>_<time>/`:
`diario.csv` (one row per day), `resumen.txt` (season summary) and `graficos.png`.

## The live view

| Control | Action |
|---|---|
| Mouse wheel, `+` / `-` | Zoom from the whole map down to about 0.4 m per pixel |
| Drag | Pan |
| Click the minimap | Jump there (the minimap appears once you zoom in) |
| Hover | Details for a plant, hive, nest or bee hotel, and the region name in mosaics |
| `Space` / `↑` `↓` / `D` | Pause, simulation speed, skip to the next day |
| `H` | Season visit heat map |
| `R` / `F` / `S` / `Q` | Whole map, fullscreen, screenshot, stop and save |

The map uses a tiled level-of-detail renderer at 1 to 32 px per 20 m cell. Far out,
canopies and flowers are drawn as colour and bees as coloured specks. Close up, every
tree, orchard row, flower patch, hive and bee is a sprite. Tiles are drawn as they come
into view, so a newly revealed area sharpens over a second or two. The renderer draws
seasonal grass (green to straw as the soil dries), daylight from dawn to dusk, cloud
shadows, morning coastal fog, rain, and bee shadows that follow the sun.

`--classic` runs the older, simpler viewer, but only on the 3 km map. The interface
font is Atkinson Hyperlegible (SIL Open Font License, `assets/fonts/OFL.txt`), chosen
for legibility on a projector.

---

## Model description

The structure follows the ODD protocol for agent-based models (Grimm et al. 2020) in
condensed form.

### Purpose

To compare how land use, weather, managed honeybees, an invasive bumblebee and its
parasites, pesticides and conservation measures change native bee populations and
the pollination they provide in Chilean landscapes.

### Entities, state variables and scales

- **Cells:** 20 m squares on a grid 150, 300 or 600 cells across. Each cell holds one
  plant type (or none) plus its nectar, its conspecific pollen received, parasite
  contamination and pesticide residue.
- **Colonies:** honeybee hives, *Bombus dahlbomii* and *B. terrestris* nests, and
  solitary-bee nests (in the ground or in bee hotels).
- **Foragers:** each agent is a "dot" standing for one or more real foragers. A dot
  carries a position, a behavioural state (in nest, searching, foraging, returning,
  flying to a remembered patch), a nectar and pollen load, the plant species of the
  pollen on its body, and its own learned flower preferences.
- **Time:** 2-minute ticks during daylight. Colony population dynamics update once per
  day. A season runs by default from 1 August to late March.

### Process overview (each tick)

1. Weather for the hour: temperature, rain, wind and cloud.
2. Each species' flight probability is computed from that weather.
3. Foragers decide whether to leave the nest, fly to a remembered or recruited
   patch, or search.
4. On flowers, foragers decide whether to feed, collect nectar and pollen, deliver and
   pick up pollen, and learn.
5. Full or discouraged foragers return. Honeybees recruit nestmates to good patches.
6. Flowers secrete nectar and parasites on flowers decay.

Once a day, colony models turn the food brought home into brood, workers and queens.

### Submodels

**Weather.** A daily generator in the style of WGEN (Richardson 1981). A first-order
Markov chain decides wet and dry days, so rain arrives in spells. Rain amounts are
exponential, and temperature has a seasonal cycle plus a persistent anomaly. Daytime
wind has an afternoon sea-breeze peak. Dry-day cloud is drawn around a zone mean, and
the coastal zones get morning fog (camanchaca) that burns off. A soil-moisture bucket
drives grass colour and the flowering of rain-fed plants. Day length uses the standard
astronomical formula (Forsythe et al. 1995). Zone climates are rounded approximations
of climatological normals, with Köppen classes after Sarricolea et al. (2017).
The "megasequía" year mimics the persistent rainfall deficit of central Chile since 2010
(Garreaud et al. 2017, 2020). In the Atacama, desert ephemerals bloom only after enough
winter rain, as in El Niño years (Vidiella et al. 1999; Chávez et al. 2019).

**Landscape.** Each environment preset is a mix of plant types. Orchards, crops and
plantations are placed as rectangular fields; everything else forms irregular patches
(a jittered-grid Voronoi tessellation). The *regional mosaic* stitches all of a zone's
environments together in roughly 1.2 km regions. Plant bloom windows, nectar and pollen
rewards, sugar concentration and corolla depth are set per species from general
botanical knowledge of the region (Hoffmann 1978; Rodríguez et al. 2018;
Smith-Ramírez et al. 2005). They are approximate. Nectar refills with a morning peak
and more slowly in cold weather; the timing pattern is our assumption, informed by the
general nectar-secretion literature (Nicolson et al. 2007).

**Flight.** Each species has a logistic response to temperature, heat, wind and heavy
cloud. Bumblebees fly in much colder air than honeybees because they warm their
flight muscles by shivering (Heinrich 1979; Corbet et al. 1993). Small solitary bees
need the most warmth and the calmest air (Vicens & Bosch 2000). Foragers already out
fly home when conditions turn bad or dusk approaches.

**Searching and learning.** A searching bee samples nearby cells and scores them by
floral display, scent of remaining nectar, sugar, how well its tongue fits the flower
(Harder 1983) and its learned preference. Learning uses a mushroom-body model with the
architecture of the fly's: 50 olfactory glomeruli feed 2,000 Kenyon cells, each with
about 6 inputs, and only the top 5 % fire. This sparse coding is maintained by the APL
neuron. Dopamine-gated plasticity then depresses Kenyon-cell output synapses: reward
weakens the "avoid" pathway and disappointment weakens the "approach" pathway
(Caron et al. 2013; Aso et al. 2014; Lin et al. 2014; Hige et al. 2015; Li et al. 2020).
Neonicotinoid exposure reduces the learning rate, following evidence that these
pesticides impair olfactory learning in bees (Williamson & Wright 2013).

**Feeding decision, derived from the FlyWire connectome.** FlyWire is the complete
wiring diagram of an adult fruit-fly brain (Dorkenwald et al. 2024; Schlegel et al.
2024), built on the FAFB electron-microscopy volume (Zheng et al. 2018).
`flywire_calibrate.py` runs the whole-brain leaky integrate-and-fire model of Shiu et
al. (2024) on that wiring. It is an event-driven NumPy port that uses their constants.
It drives the sugar-sensing taste neurons at different rates and records MN9, the motor
neuron that starts proboscis extension. The simulated dose-response table is in
`beesim/calibration.json`, and every bee uses it to decide whether to drink. Hunger
raises the gain of the sugar input, because hunger sensitises sugar-sensing neurons
through dopamine (Inagaki et al. 2012; Marella et al. 2012). This is a fly circuit, not
a bee one: no bee connectome exists yet. It is borrowed because the insect
sugar-to-feeding pathway is broadly conserved.

**Recruitment.** Returning honeybees that found a rich patch recruit idle nestmates to
it, more for better patches. This is an abstraction of the waggle dance
(von Frisch 1967; Seeley 1995).

**Pollination.** A bee carries pollen from the last plant species it visited. On each
visit it deposits a fraction of that pollen and keeps the rest for later flowers
(pollen carry-over; Thomson & Plowright 1980). Only pollen of the **same** plant
species counts as pollination, so flower constancy matters (Waser 1986; Chittka et al.
1999). Bumblebees get a bonus on buzz-pollinated blueberry (Javorek et al. 2002). A
crop's pollination index is a saturating function of the conspecific pollen its cells
receive, reflecting that fruit set levels off with more visits. The summary reports
each bee species' constancy (the share of its pollen that reached the right species).
Wild bees adding pollination on top of honeybees is a well-documented field result
(Garibaldi et al. 2013).

**Honeybee colonies.** These use the compartment model of Khoury et al. (2011, 2013):
eggs become brood, brood become hive bees after 21 days, and hive bees are recruited
to foraging. The queen's laying rate is L = 2000 eggs per day. Brood survival depends
on colony size through the term N/(w + N), with w = 27,000. Recruitment to foraging is
α − σ·F/(H+F), with α = 0.25 and σ = 0.75; this "social inhibition" holds the forager
share near one third. Following Khoury et al. (2013), food stores feed back on brood
rearing and recruitment: when food is short, more hive bees become foragers. Forager
mortality is 0.13 per day, inside the range Khoury et al. (2011) derived from observed
foraging lifespans (Visscher & Dukas 1997). The food-dependence functions, the
consumption rates and the seasonal laying multiplier are our own settings. Hives start
the season with about 5 kg of stored honey, as an overwintered managed colony would.

**Bumblebee colonies.** These are a simplified life cycle after Bumble-BEEHAVE (Becher
et al. 2018) and Goulson (2010). A queen leaves hibernation in spring and forages
alone. The colony then grows on nectar and pollen, switches to rearing new queens late
in the season, and dies off in autumn. Parasites and pesticides reduce worker survival,
brood production and queen production.

**Solitary bees.** Each female provisions brood cells with pollen and dies after a few
weeks. The output is brood cells built, which stands for next year's bees. Pollen per
brood cell is informed by Müller et al. (2006). Foraging ranges are a few hundred
metres (Gathmann & Tscharntke 2002; Greenleaf et al. 2007).

**Foraging ranges.**
- Honeybees: up to about 2 km in the model. Real foraging is often 1–2 km and can be
  much longer (Visscher & Seeley 1982; Steffan-Dewenter & Kuhn 2003).
- Bumblebees: roughly 1–1.5 km (Osborne et al. 1999; Knight et al. 2005).
- Solitary bees: about 400 m.

**Invasive bumblebee and parasites.** *B. terrestris* spread through Chile after
introductions for greenhouse pollination and became dominant, especially in central
Chile (Montalva et al. 2011). Its arrival is linked to the rapid decline of
*B. dahlbomii* (Morales et al. 2013). That decline is associated with parasites
introduced with it, such as *Crithidia bombi* and *Apicystis bombi*
(Arbetman et al. 2013; Schmid-Hempel et al. 2014; Aizen et al. 2019). In the model,
70 % of *B. terrestris* colonies carry a parasite that they leave on flowers.
*B. dahlbomii* colonies become infected in proportion to how contaminated their
flowers are. Infection lowers worker survival and queen production and can kill the
colony. Zone-by-zone presence follows the published distributions only qualitatively.

**Pesticides.** Neonicotinoid-type residues sit on blooming crops. Exposure in the
model has three effects:
- foragers fail to find their way home (Henry et al. 2012)
- learning is impaired (Williamson & Wright 2013)
- bumblebee queen production falls (Whitehorn et al. 2012; Rundlöf et al. 2015)

The size of each effect is our assumption.

**Conservation measures.** Native flower strips add about 4 % of the landscape as a
long-flowering native mix; flower plantings have increased wild bees and blueberry
pollination in field trials (Blaauw & Isaacs 2014). Bee hotels add clustered nest
sites. Their real-world benefit is debated (MacIvor & Packer 2015), so treat that
switch as a hypothesis to test, not a proven fix. The "hives" switch makes it possible
to explore competition between managed honeybees and wild bees (Mallinger et al. 2017).

### Scaling

The base map is 9 km² (3 × 3 km). On larger maps, apiaries, wild bumblebee nests,
ground nests and bee hotels scale with area, so densities stay the same. Each dot
stands for more real bees on larger maps, to keep the agent count manageable.

---

## Parameters and their sources

**Status key**
- **Source:** value taken from the cited work.
- **Informed:** value chosen to be consistent with the cited work, not copied from it.
- **Assumption:** our setting, to be calibrated with field data.

| Parameter | Value in the model | Status | Basis |
|---|---|---|---|
| Honeybee queen laying rate L | 2000 eggs/day (scaled by season) | Source + assumption (seasonality) | Khoury et al. 2011 |
| Brood survival constant w | 27,000 bees | Source | Khoury et al. 2011 |
| Recruitment α, σ | 0.25, 0.75 | Source | Khoury et al. 2011 |
| Development egg to adult (honeybee) | 21 days | Source | Khoury et al. 2011 |
| Forager mortality (honeybee) | 0.13 per day in season | Source (range) | Khoury et al. 2011; Visscher & Dukas 1997 |
| Food feedback on brood and recruitment | Saturating functions of stores | Informed (structure) / assumption (values) | Khoury et al. 2013 |
| Overwintered honey reserve | ~5 kg per hive | Assumption | Typical managed colony |
| Flight 50 % temperature | Honeybee 12.5 °C, bumblebees 7–7.5 °C, solitary 14.5 °C | Informed | Heinrich 1979; Corbet et al. 1993; Vicens & Bosch 2000 |
| Wind and cloud flight limits | 5–9.5 m/s at 50 % activity | Informed | Vicens & Bosch 2000 |
| Foraging ranges | Honeybee ~2.2 km, bumblebees 1.2–1.5 km, solitary ~0.4 km | Informed | Visscher & Seeley 1982; Steffan-Dewenter & Kuhn 2003; Osborne et al. 1999; Knight et al. 2005; Gathmann & Tscharntke 2002; Greenleaf et al. 2007 |
| Tongue / corolla accessibility | Linear fall-off beyond tongue length | Informed | Harder 1983 |
| Pollen carry-over, deposit fraction | 30 % per visit | Informed (concept) / assumption (value) | Thomson & Plowright 1980 |
| Buzz-pollination bonus on blueberry | ×2 for bumblebees, ×0.5 for honeybees | Informed | Javorek et al. 2002 |
| Mushroom body: glomeruli, Kenyon cells, claws, sparseness | 50, 2,000, 6, 5 % | Source (fly anatomy, rounded) | Caron et al. 2013; Aso et al. 2014; Lin et al. 2014; Li et al. 2020 |
| Learning rule | Dopamine-gated depression of KC→output synapses | Source (mechanism) | Aso et al. 2014; Hige et al. 2015 |
| Feeding dose-response | Simulated from the connectome | Source (computed) | Dorkenwald et al. 2024; Shiu et al. 2024 |
| Hunger raises sugar sensitivity | Gain 0.55–1.45 | Informed (direction) / assumption (size) | Inagaki et al. 2012; Marella et al. 2012 |
| Parasite carriage in *B. terrestris* | 70 % of colonies | Assumption | Schmid-Hempel et al. 2014; Arbetman et al. 2013 |
| Parasite effects on *B. dahlbomii* | Lower survival, brood and queens | Informed (direction) / assumption (size) | Morales et al. 2013; Schmid-Hempel et al. 2014 |
| Pesticide homing failure, learning and queen effects | Proportional to exposure | Informed (direction) / assumption (size) | Henry et al. 2012; Williamson & Wright 2013; Whitehorn et al. 2012; Rundlöf et al. 2015 |
| Solitary bee pollen per brood cell | 5 loads | Informed | Müller et al. 2006 |
| Wet-day persistence (Markov chain) | 0.45 | Assumption | Structure: Richardson 1981 |
| Zone temperature, rainfall, wind and cloud | Rounded normals | Assumption (approximate) | Check against DMC normals; Köppen classes: Sarricolea et al. 2017 |
| Megadrought and El Niño scenarios | Rain ×0.45 / ×1.7 (desert ×0.2 / ×4) | Assumption | Garreaud et al. 2017, 2020; Vidiella et al. 1999; Chávez et al. 2019 |
| Desert bloom threshold | Starts at ~10 mm, full at ~35 mm of winter rain | Assumption | Vidiella et al. 1999; Chávez et al. 2019 |
| Bloom windows, nectar, pollen, sugar, corolla depth | Per plant in `flora.py` | Assumption (approximate) | Hoffmann 1978; Rodríguez et al. 2018; Smith-Ramírez et al. 2005 |
| Nectar secretion daily pattern | Morning peak, slower when cold | Assumption | Nicolson et al. 2007 |
| Zone presence of each bumblebee | 0–1 per zone | Informed (qualitative) | Montalva et al. 2011; Morales et al. 2013 |

## Limitations

- The brain components come from a fruit fly, not a bee.
- Plant and climate values are approximations. They should be replaced with local field
  data where available: DMC climate normals, INIA and university studies, and your own
  observations.
- A dot stands for many bees, so very fine-scale effects (individual flower handling,
  individual bee energetics) are abstracted.
- Bumblebee and solitary-bee colony models are simplified compared with Bumble-BEEHAVE.
- The model has not been validated against Chilean field data. Its value is in
  comparing scenarios and showing mechanisms, not in predicting exact numbers.

---

## References

Aizen, M.A. et al. (2019). Coordinated species importation policies are needed to reduce serious invasions globally: the case of alien bumblebees in South America. *Journal of Applied Ecology* 56: 100–106.

Arbetman, M.P., Meeus, I., Morales, C.L., Aizen, M.A. & Smagghe, G. (2013). Alien parasite hitchhikes to Patagonia on invasive bumblebee. *Biological Invasions* 15: 489–494.

Aso, Y. et al. (2014). The neuronal architecture of the mushroom body provides a logic for associative learning. *eLife* 3: e04577.

Becher, M.A., Grimm, V., Thorbek, P., Horn, J., Kennedy, P.J. & Osborne, J.L. (2014). BEEHAVE: a systems model of honeybee colony dynamics and foraging to explore multifactorial causes of colony failure. *Journal of Applied Ecology* 51: 470–482.

Becher, M.A., Twiston-Davies, G., Penny, T.D., Goulson, D., Rotheray, E.L. & Osborne, J.L. (2018). Bumble-BEEHAVE: a systems model for exploring multifactorial causes of bumblebee decline at individual, colony, population and community level. *Journal of Applied Ecology* 55: 2790–2801.

Blaauw, B.R. & Isaacs, R. (2014). Flower plantings increase wild bee abundance and the pollination services provided to a pollination-dependent crop. *Journal of Applied Ecology* 51: 890–898.

Caron, S.J.C., Ruta, V., Abbott, L.F. & Axel, R. (2013). Random convergence of olfactory inputs in the *Drosophila* mushroom body. *Nature* 497: 113–117.

Chávez, R.O. et al. (2019). GIMMS NDVI time series reveal the extent, duration, and intensity of "blooming desert" events in the hyper-arid Atacama Desert, Northern Chile. *International Journal of Applied Earth Observation and Geoinformation* 76: 193–203.

Chittka, L., Thomson, J.D. & Waser, N.M. (1999). Flower constancy, insect psychology, and plant evolution. *Naturwissenschaften* 86: 361–377.

Corbet, S.A. et al. (1993). Temperature and the pollinating activity of social bees. *Ecological Entomology* 18: 17–30.

Dorkenwald, S. et al. (2024). Neuronal wiring diagram of an adult brain. *Nature* 634: 124–138.

Forsythe, W.C., Rykiel, E.J., Stahl, R.S., Wu, H. & Schoolfield, R.M. (1995). A model comparison for daylength as a function of latitude and day of year. *Ecological Modelling* 80: 87–95.

Garibaldi, L.A. et al. (2013). Wild pollinators enhance fruit set of crops regardless of honey bee abundance. *Science* 339: 1608–1611.

Garreaud, R.D. et al. (2017). The 2010–2015 megadrought in central Chile: impacts on regional hydroclimate and vegetation. *Hydrology and Earth System Sciences* 21: 6307–6327.

Garreaud, R.D. et al. (2020). The Central Chile Mega Drought (2010–2018): a climate dynamics perspective. *International Journal of Climatology* 40: 421–439.

Gathmann, A. & Tscharntke, T. (2002). Foraging ranges of solitary bees. *Journal of Animal Ecology* 71: 757–764.

Goulson, D. (2010). *Bumblebees: Behaviour, Ecology, and Conservation*, 2nd ed. Oxford University Press.

Greenleaf, S.S., Williams, N.M., Winfree, R. & Kremen, C. (2007). Bee foraging ranges and their relationship to body size. *Oecologia* 153: 589–596.

Grimm, V. et al. (2020). The ODD protocol for describing agent-based and other simulation models: a second update to improve clarity, replication, and structural realism. *Journal of Artificial Societies and Social Simulation* 23(2): 7.

Harder, L.D. (1983). Flower handling efficiency of bumble bees: morphological aspects of probing time. *Oecologia* 57: 274–280.

Heinrich, B. (1979). *Bumblebee Economics*. Harvard University Press.

Henry, M. et al. (2012). A common pesticide decreases foraging success and survival in honey bees. *Science* 336: 348–350.

Hige, T., Aso, Y., Modi, M.N., Rubin, G.M. & Turner, G.C. (2015). Heterosynaptic plasticity underlies aversive olfactory learning in *Drosophila*. *Neuron* 88: 985–998.

Hoffmann, A. (1978). *Flora silvestre de Chile: zona central*. Ediciones Fundación Claudio Gay, Santiago.

Inagaki, H.K. et al. (2012). Visualizing neuromodulation in vivo: TANGO-mapping of dopamine signaling reveals appetite control of sugar sensing. *Cell* 148: 583–595.

Javorek, S.K., Mackenzie, K.E. & Vander Kloet, S.P. (2002). Comparative pollination effectiveness among bees (Hymenoptera: Apoidea) on lowbush blueberry (Ericaceae: *Vaccinium angustifolium*). *Annals of the Entomological Society of America* 95: 345–351.

Khoury, D.S., Myerscough, M.R. & Barron, A.B. (2011). A quantitative model of honey bee colony population dynamics. *PLoS ONE* 6: e18491.

Khoury, D.S., Barron, A.B. & Myerscough, M.R. (2013). Modelling food and population dynamics in honey bee colonies. *PLoS ONE* 8: e59084.

Knight, M.E. et al. (2005). An interspecific comparison of foraging range and nest density of four bumblebee (*Bombus*) species. *Molecular Ecology* 14: 1811–1820.

Li, F. et al. (2020). The connectome of the adult *Drosophila* mushroom body provides insights into function. *eLife* 9: e62576.

Lin, A.C. et al. (2014). Sparse, decorrelated odor coding in the mushroom body enhances learned odor discrimination. *Nature Neuroscience* 17: 559–568.

MacIvor, J.S. & Packer, L. (2015). "Bee hotels" as tools for native pollinator conservation: a premature verdict? *PLoS ONE* 10: e0122126.

Mallinger, R.E., Gaines-Day, H.R. & Gratton, C. (2017). Do managed bees have negative effects on wild bees? A systematic review of the literature. *PLoS ONE* 12: e0189268.

Marella, S., Mann, K. & Scott, K. (2012). Dopaminergic modulation of sucrose acceptance behavior in *Drosophila*. *Neuron* 73: 941–950.

Montalva, J., Dudley, L., Arroyo, M.K., Retamales, H. & Abrahamovich, A.H. (2011). Geographic distribution and associated flora of native and introduced bumble bees (*Bombus* spp.) in Chile. *Journal of Apicultural Research* 50: 11–21.

Montalva, J. & Ruz, L. (2010). Actualización de la lista sistemática de las abejas chilenas (Hymenoptera: Apoidea). *Revista Chilena de Entomología* 35: 15–52.

Morales, C.L., Arbetman, M.P., Cameron, S.A. & Aizen, M.A. (2013). Rapid ecological replacement of a native bumble bee by invasive species. *Frontiers in Ecology and the Environment* 11: 529–534.

Müller, A. et al. (2006). Quantitative pollen requirements of solitary bees: implications for bee conservation and the evolution of bee–flower relationships. *Biological Conservation* 130: 604–615.

Nicolson, S.W., Nepi, M. & Pacini, E. (eds) (2007). *Nectaries and Nectar*. Springer.

Osborne, J.L. et al. (1999). A landscape-scale study of bumble bee foraging range and constancy, using harmonic radar. *Journal of Applied Ecology* 36: 519–533.

Richardson, C.W. (1981). Stochastic simulation of daily precipitation, temperature, and solar radiation. *Water Resources Research* 17: 182–190.

Rodríguez, R. et al. (2018). Catálogo de las plantas vasculares de Chile. *Gayana Botánica* 75: 1–430.

Rundlöf, M. et al. (2015). Seed coating with a neonicotinoid insecticide negatively affects wild bees. *Nature* 521: 77–80.

Sarricolea, P., Herrera-Ossandon, M. & Meseguer-Ruiz, Ó. (2017). Climatic regionalisation of continental Chile. *Journal of Maps* 13: 66–73.

Schlegel, P. et al. (2024). Whole-brain annotation and multi-connectome cell typing of *Drosophila*. *Nature* 634: 139–152.

Schmid-Hempel, R. et al. (2014). The invasion of southern South America by imported bumblebees and associated parasites. *Journal of Animal Ecology* 83: 823–837.

Seeley, T.D. (1995). *The Wisdom of the Hive: The Social Physiology of Honey Bee Colonies*. Harvard University Press.

Shiu, P.K. et al. (2024). A *Drosophila* computational brain model reveals sensorimotor processing. *Nature* 634: 210–219.

Smith-Ramírez, C. et al. (2005). Diversity, flower visitation frequency and generalism of pollinators in temperate rain forests of Chiloé Island, Chile. *Botanical Journal of the Linnean Society* 147: 399–416.

Steffan-Dewenter, I. & Kuhn, A. (2003). Honeybee foraging in differentially structured landscapes. *Proceedings of the Royal Society B* 270: 569–575.

Thomson, J.D. & Plowright, R.C. (1980). Pollen carryover, nectar rewards, and pollinator behavior with special reference to *Diervilla lonicera*. *Oecologia* 46: 68–74.

Vicens, N. & Bosch, J. (2000). Weather-dependent pollinator activity in an apple orchard, with special reference to *Osmia cornuta* and *Apis mellifera* (Hymenoptera: Megachilidae and Apidae). *Environmental Entomology* 29: 413–420.

Vidiella, P.E., Armesto, J.J. & Gutiérrez, J.R. (1999). Vegetation changes and sequential flowering after rain in the southern Atacama Desert. *Journal of Arid Environments* 43: 449–458.

Visscher, P.K. & Dukas, R. (1997). Survivorship of foraging honey bees. *Insectes Sociaux* 44: 1–5.

Visscher, P.K. & Seeley, T.D. (1982). Foraging strategy of honeybee colonies in a temperate deciduous forest. *Ecology* 63: 1790–1801.

von Frisch, K. (1967). *The Dance Language and Orientation of Bees*. Harvard University Press.

Waser, N.M. (1986). Flower constancy: definition, cause, and measurement. *The American Naturalist* 127: 593–603.

Whitehorn, P.R., O'Connor, S., Wackers, F.L. & Goulson, D. (2012). Neonicotinoid pesticide reduces bumble bee colony growth and queen production. *Science* 336: 351–352.

Williamson, S.M. & Wright, G.A. (2013). Exposure to multiple cholinergic pesticides impairs olfactory learning and memory in honeybees. *Journal of Experimental Biology* 216: 1799–1807.

Zheng, Z. et al. (2018). A complete electron microscopy volume of the brain of adult *Drosophila melanogaster*. *Cell* 174: 730–743.

Model code and data for the connectome simulation: Shiu, P.K. *Drosophila_brain_model*, github.com/philshiu/Drosophila_brain_model (FlyWire v630 tables). Native bee checklist for Chile: Montalva & Ruz (2010).
