#!/usr/bin/env python3
"""
flywire_calibrate.py — derive the bees' nectar-acceptance curve from the real
FlyWire fruit-fly connectome.

What it does
------------
Runs a whole-brain leaky integrate-and-fire (LIF) model built from FlyWire
(the Princeton/Google-led full adult Drosophila brain connectome), using the
same equations and constants as Shiu et al., Nature 2024
(github.com/philshiu/Drosophila_brain_model). It drives the sugar-sensing
gustatory neurons at a range of Poisson rates and records the firing rate of
MN9, the motor neuron that starts proboscis extension (feeding). The resulting
dose-response curve "sugar signal -> feeding command" is fitted with a sigmoid
and written to calibration.json, which beesim/brain.py loads.

This is an event-driven NumPy/SciPy port (only spiking neurons push current
each step), so it runs on a laptop CPU in a few minutes. Optional --torch uses
your GPU for the neuron update, but the CPU path is usually fast enough.

Honest caveat: this is a FLY brain. Bees have ~1M neurons vs ~140k in a fly
and no full bee connectome exists yet. We borrow the shape of an insect
sugar->feeding transformation, which is broadly conserved, not a bee brain.

Usage
-----
    git clone --depth 1 https://github.com/philshiu/Drosophila_brain_model.git
    python flywire_calibrate.py --data Drosophila_brain_model
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

# --- Constants from Shiu et al. model.py (default_params) -------------------
V0, V_RST, V_TH = -52.0, -52.0, -45.0   # mV
T_MBR, TAU = 20.0, 5.0                  # ms
T_RFC, T_DLY = 2.2, 1.8                 # ms
W_SYN, F_POI = 0.275, 250.0             # mV per synapse, Poisson scaling
DT = 0.1                                # ms (Brian2 default)

# FlyWire v630 IDs used in the official example notebook (right-hemisphere
# sugar GRNs, and MN9). These match the *_630_final files in the repo.
SUGAR_IDS_630 = [
    720575940624963786, 720575940630233916, 720575940637568838,
    720575940638202345, 720575940617000768, 720575940630797113,
    720575940632889389, 720575940621754367, 720575940621502051,
    720575940640649691, 720575940639332736, 720575940616885538,
    720575940639198653, 720575940620900446, 720575940617937543,
    720575940632425919, 720575940633143833, 720575940612670570,
    720575940628853239, 720575940629176663, 720575940611875570,
]
MN9_ID_630 = 720575940660219265


def load_network(data_dir: Path):
    import pandas as pd
    from scipy.sparse import csr_matrix

    comp = data_dir / "2023_03_23_completeness_630_final.csv"
    con = data_dir / "2023_03_23_connectivity_630_final.parquet"
    for p in (comp, con):
        if not p.exists():
            sys.exit(f"Missing {p}. Clone the Shiu repo and pass --data <path>.")
    print("Loading connectome tables…")
    df_comp = pd.read_csv(comp, index_col=0)
    df_con = pd.read_parquet(
        con, columns=["Presynaptic_Index", "Postsynaptic_Index",
                      "Excitatory x Connectivity"])
    n = len(df_comp)
    W = csr_matrix(
        (df_con["Excitatory x Connectivity"].to_numpy(np.float32) * W_SYN,
         (df_con["Presynaptic_Index"].to_numpy(), df_con["Postsynaptic_Index"].to_numpy())),
        shape=(n, n))
    id2idx = {fid: i for i, fid in enumerate(df_comp.index)}
    print(f"  {n:,} neurons, {W.nnz:,} connections")
    return W, id2idx


def run_trial(W, inputs, rate_hz, t_ms, rng, record):
    """One trial. Returns spike counts for `record` neuron indices."""
    n = W.shape[0]
    v = np.full(n, V0, np.float32)
    g = np.zeros(n, np.float32)
    rfc = np.zeros(n, np.int32)                    # refractory steps left
    rfc_steps = int(round(T_RFC / DT))
    dly_steps = int(round(T_DLY / DT))
    ring = [np.empty(0, np.int64) for _ in range(dly_steps)]
    is_input = np.zeros(n, bool)
    is_input[inputs] = True
    counts = np.zeros(len(record), np.int64)
    rec_pos = {r: k for k, r in enumerate(record)}
    p_spike = rate_hz * DT * 1e-3
    a_v, a_g = DT / T_MBR, np.exp(-DT / TAU)
    indptr, indices, data = W.indptr, W.indices, W.data

    for step in range(int(t_ms / DT)):
        # delayed synaptic events arrive (on_pre: g += w)
        arriving = ring[step % dly_steps]
        if arriving.size:
            for s in arriving:
                lo, hi = indptr[s], indptr[s + 1]
                np.add.at(g, indices[lo:hi], data[lo:hi])
        # Poisson drive on sugar neurons (acts directly on v, as in the paper)
        if p_spike > 0:
            hit = inputs[rng.random(len(inputs)) < p_spike]
            v[hit] += W_SYN * F_POI
        # integrate (unless refractory)
        active = rfc <= 0
        v[active] += a_v * (V0 - v[active] + g[active])
        g[active] *= a_g
        rfc[~active] -= 1
        # spikes
        spk = np.flatnonzero(v > V_TH)
        if spk.size:
            v[spk] = V_RST
            g[spk] = 0.0
            rfc[spk] = np.where(is_input[spk], 0, rfc_steps)
            for s in spk:
                k = rec_pos.get(int(s))
                if k is not None:
                    counts[k] += 1
        ring[step % dly_steps] = spk
    return counts


def sigmoid(x, rmax, x0, s):
    return rmax / (1.0 + np.exp(-(x - x0) / s))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", type=Path, required=True,
                    help="path to a clone of philshiu/Drosophila_brain_model")
    ap.add_argument("--rates", type=str, default="0,10,20,40,60,80,100,150,200",
                    help="sugar-neuron drive rates in Hz")
    ap.add_argument("--t", type=float, default=1000.0, help="trial length (ms)")
    ap.add_argument("--trials", type=int, default=3, help="trials per rate")
    ap.add_argument("--out", type=Path,
                    default=Path(__file__).parent / "beesim" / "calibration.json")
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()

    W, id2idx = load_network(args.data)
    inputs = np.array([id2idx[i] for i in SUGAR_IDS_630 if i in id2idx])
    mn9 = id2idx[MN9_ID_630]
    print(f"Driving {len(inputs)} sugar GRNs, recording MN9 (index {mn9})")

    rng = np.random.default_rng(args.seed)
    rates = [float(r) for r in args.rates.split(",")]
    table = []
    for r in rates:
        t0 = time.time()
        hz = [run_trial(W, inputs, r, args.t, rng, [mn9])[0] / (args.t / 1000)
              for _ in range(args.trials)]
        table.append((r, float(np.mean(hz)), float(np.std(hz))))
        print(f"  sugar {r:6.1f} Hz -> MN9 {np.mean(hz):6.1f} ± {np.std(hz):4.1f} Hz"
              f"   ({time.time() - t0:.0f}s)")

    x = np.array([t[0] for t in table])
    y = np.array([t[1] for t in table])
    try:
        from scipy.optimize import curve_fit
        p0 = [max(y.max(), 1.0), float(np.median(x)), 20.0]
        (rmax, x0, s), _ = curve_fit(sigmoid, x, y, p0=p0, maxfev=20000,
                                     bounds=([0.1, -100, 1], [1000, 400, 200]))
    except Exception as e:  # fall back to a crude fit
        print("curve_fit failed:", e)
        rmax, x0, s = float(y.max() or 1), float(np.median(x)), 25.0

    out = {
        "source": "FlyWire v630 whole-brain LIF (Shiu et al. 2024 constants), "
                  "sugar GRNs -> MN9",
        "input_max_hz": max(rates),
        "rmax_hz": float(rmax), "x0_hz": float(x0), "slope_hz": float(s),
        "table": [{"sugar_hz": a, "mn9_hz": b, "sd": c} for a, b, c in table],
        "trials": args.trials, "trial_ms": args.t,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(out, indent=2))
    print(f"\nFit: MN9 = {rmax:.1f} / (1 + exp(-(sugar - {x0:.1f}) / {s:.1f}))")
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
